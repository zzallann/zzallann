import type { Post, User, Poll, Comment } from '../types';
import { messageService } from './messageService';
import { largeDataService } from './largeDataService';

// =============================================================================
// IMPORTANT: MOCK BACKEND SIMULATION
// =============================================================================
// This service simulates a backend server for managing feed posts using a
// hybrid storage approach: localStorage for metadata and IndexedDB for large files.
// =============================================================================

const POSTS_KEY = 'astoria_posts';

const getStoredPosts = (): Post[] => {
    const postsJson = localStorage.getItem(POSTS_KEY);
    if (!postsJson) return [];
    try {
        const posts = JSON.parse(postsJson);
        // Sort by timestamp descending
        return posts.sort((a: Post, b: Post) => b.timestamp - a.timestamp);
    } catch (e) {
        return [];
    }
};

const storePosts = async (posts: Post[]) => {
    let postsToStore = [...posts];
    let stored = false;
    let attempts = 0;
    const maxAttempts = postsToStore.length + 5; // Safety break

    while (!stored && attempts < maxAttempts) {
        attempts++;
        try {
            localStorage.setItem(POSTS_KEY, JSON.stringify(postsToStore));
            stored = true;
        } catch (e: any) {
            if (e.name === 'QuotaExceededError' || (e.code && (e.code === 22 || e.code === 1014))) {
                console.warn('LocalStorage quota exceeded for post metadata. Attempting to free space.');
                
                postsToStore.sort((a, b) => b.timestamp - a.timestamp); // Newest first

                if (postsToStore.length > 0) {
                    const removedPost = postsToStore.pop(); // Remove oldest
                    if (removedPost) {
                        const cleanupPromises: Promise<void>[] = [];
                        // Clean up associated large data from IndexedDB
                        if (removedPost.imageUrl && removedPost.imageUrl.startsWith('idb_key:')) {
                            cleanupPromises.push(largeDataService.deleteItem(removedPost.imageUrl.substring(8)));
                        }
                        if (removedPost.videoUrl && removedPost.videoUrl.startsWith('idb_key:')) {
                            cleanupPromises.push(largeDataService.deleteItem(removedPost.videoUrl.substring(8)));
                        }
                        removedPost.comments.forEach(comment => {
                             if (comment.imageUrl && comment.imageUrl.startsWith('idb_key:')) {
                                cleanupPromises.push(largeDataService.deleteItem(comment.imageUrl.substring(8)));
                            }
                        });
                        await Promise.all(cleanupPromises);
                    }
                } else {
                    throw new Error('Nem sikerült elmenteni a bejegyzést, a böngésző tárolója valószínűleg tele van.');
                }
            } else {
                throw e;
            }
        }
    }
    if (!stored) {
         throw new Error('Nem sikerült elmenteni a bejegyzést a tárhely felszabadítása után sem.');
    }
};


// Helper to read a file as a Base64 string
const fileToBase64 = (file: File): Promise<string> => {
    return new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.readAsDataURL(file);
        reader.onload = () => resolve(reader.result as string);
        reader.onerror = error => reject(error);
    });
};


// Helper to convert and compress an image File to a base64 string
const imageFileToBase64 = (file: File): Promise<string> => {
    return new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.readAsDataURL(file);
        reader.onload = event => {
            if (!event.target?.result) {
                return reject(new Error("FileReader did not return a result."));
            }
            const img = new Image();
            img.src = event.target.result as string;
            img.onload = () => {
                const canvas = document.createElement('canvas');
                const MAX_WIDTH = 800;
                const MAX_HEIGHT = 800;
                let width = img.width;
                let height = img.height;

                if (width > height) {
                    if (width > MAX_WIDTH) {
                        height *= MAX_WIDTH / width;
                        width = MAX_WIDTH;
                    }
                } else {
                    if (height > MAX_HEIGHT) {
                        width *= MAX_HEIGHT / height;
                        height = MAX_HEIGHT;
                    }
                }

                canvas.width = width;
                canvas.height = height;
                const ctx = canvas.getContext('2d');
                if (!ctx) {
                    return reject(new Error('Could not get canvas context'));
                }
                ctx.drawImage(img, 0, 0, width, height);
                
                // Convert to JPEG for smaller file size. Quality 0.9 is a good balance.
                resolve(canvas.toDataURL('image/jpeg', 0.9));
            };
            img.onerror = error => reject(error);
        };
        reader.onerror = error => reject(error);
    });
};

export const driveService = {
    async getPosts(): Promise<Post[]> {
        // Simulate network delay
        await new Promise(res => setTimeout(res, 500));
        return getStoredPosts();
    },

    async createPost(
        author: User, 
        content: string | null, 
        gifUrl: string | null,
        imageFile: File | null,
        videoFile: File | null,
        poll: Poll | null
    ): Promise<Post> {
        const posts = getStoredPosts();
        
        const newPost: Post = {
            id: `post_${Date.now()}`,
            author,
            content,
            gifUrl,
            imageUrl: null,
            videoUrl: null,
            poll,
            timestamp: Date.now(),
            reactions: {},
            comments: [],
        };

        if (imageFile) {
            const base64 = await imageFileToBase64(imageFile);
            const key = `post_media_${newPost.id}`;
            await largeDataService.setItem(key, base64);
            newPost.imageUrl = `idb_key:${key}`;
        }
    
        if (videoFile) {
            const base64 = await fileToBase64(videoFile);
            const key = `post_media_${newPost.id}`;
            await largeDataService.setItem(key, base64);
            newPost.videoUrl = `idb_key:${key}`;
        }

        const updatedPosts = [newPost, ...posts];
        await storePosts(updatedPosts);

        // Simulate network delay
        await new Promise(res => setTimeout(res, 300));

        return newPost;
    },
    
    async deletePost(post: Post, deleter: User): Promise<void> {
        await new Promise(res => setTimeout(res, 300));

        // Permission check
        const canDelete = deleter.id === post.author.id || deleter.status === 'pro_max';
        if (!canDelete) {
            throw new Error('Nincs jogosultságod a bejegyzés törléséhez.');
        }
        
        // Send system message to the author from the police bot if a Pro Max user deletes it
        const POLICE_BOT_ID = 'system_police_bot';
        if (post.author.id !== deleter.id) {
            const postContentPreview = post.content ? `"${post.content.substring(0, 50)}..."` : (post.imageUrl ? "képes posztodat" : (post.gifUrl ? "GIF-es posztodat" : "posztodat"));
            const systemMessage = `A(z) ${postContentPreview} egy Pro Max felhasználó (${deleter.name}) által törölve lett.`;
            const convoId = await messageService.findOrCreateConversation(POLICE_BOT_ID, post.author.id);
            await messageService.sendMessage(POLICE_BOT_ID, convoId, systemMessage, null, null, false);
        }

        // Cleanup from IndexedDB
        if (post.imageUrl && post.imageUrl.startsWith('idb_key:')) {
            await largeDataService.deleteItem(post.imageUrl.substring(8));
        }
        if (post.videoUrl && post.videoUrl.startsWith('idb_key:')) {
            await largeDataService.deleteItem(post.videoUrl.substring(8));
        }

        // Delete the post metadata from localStorage
        let posts = getStoredPosts();
        posts = posts.filter(p => p.id !== post.id);
        await storePosts(posts);
    },

    async toggleReaction(postId: string, reaction: string, userId:string): Promise<Post> {
        // Using a slight delay to feel like a server request
        await new Promise(res => setTimeout(res, 50));
        
        const posts = getStoredPosts();
        const post = posts.find(p => p.id === postId);
        if (!post) throw new Error('A bejegyzés nem található.');

        // Find if the user has any reaction on this post
        let userPreviousReaction: string | null = null;
        for (const reactionKey in post.reactions) {
            if (post.reactions[reactionKey].includes(userId)) {
                userPreviousReaction = reactionKey;
                break;
            }
        }

        // If the user had a previous reaction, it needs to be removed
        if (userPreviousReaction) {
            const userIndex = post.reactions[userPreviousReaction].indexOf(userId);
            post.reactions[userPreviousReaction].splice(userIndex, 1);
            // Clean up empty reaction arrays
            if (post.reactions[userPreviousReaction].length === 0) {
                delete post.reactions[userPreviousReaction];
            }
        }

        // If the clicked reaction is different from the previous one, add the new reaction.
        if (userPreviousReaction !== reaction) {
            if (!post.reactions[reaction]) {
                post.reactions[reaction] = [];
            }
            post.reactions[reaction].push(userId);
        }

        await storePosts(posts);
        return { ...post }; // Return a copy of the updated post
    },
    
    async voteOnPoll(postId: string, optionIndex: number, userId: string): Promise<Post> {
        await new Promise(res => setTimeout(res, 100));
        const posts = getStoredPosts();
        const post = posts.find(p => p.id === postId);

        if (!post || !post.poll) throw new Error('Szavazás nem található.');
        
        // Remove previous vote from this user on this poll
        post.poll.options.forEach(option => {
            const voteIndex = option.votes.indexOf(userId);
            if(voteIndex > -1) {
                option.votes.splice(voteIndex, 1);
            }
        });

        // Add new vote
        post.poll.options[optionIndex].votes.push(userId);
        
        await storePosts(posts);
        return { ...post };
    },

    async addComment(postId: string, author: User, content: string | null, imageFile: File | null, gifUrl: string | null): Promise<Post> {
        await new Promise(res => setTimeout(res, 300));
        const posts = getStoredPosts();
        const post = posts.find(p => p.id === postId);
        if (!post) throw new Error("A bejegyzés nem található.");

        const newComment: Comment = {
            id: `comment_${Date.now()}`,
            author,
            content,
            imageUrl: null,
            gifUrl,
            timestamp: Date.now(),
            reactions: {},
        };

        if (imageFile) {
            const base64 = await imageFileToBase64(imageFile);
            const key = `comment_media_${newComment.id}`;
            await largeDataService.setItem(key, base64);
            newComment.imageUrl = `idb_key:${key}`;
        }

        post.comments.push(newComment);
        await storePosts(posts);
        return { ...post };
    },
    
    async deleteComment(postId: string, commentId: string, deleter: User): Promise<Post> {
        await new Promise(res => setTimeout(res, 300));

        const posts = getStoredPosts();
        const post = posts.find(p => p.id === postId);
        if (!post) throw new Error('A bejegyzés nem található.');

        const commentIndex = post.comments.findIndex(c => c.id === commentId);
        if (commentIndex === -1) throw new Error('A komment nem található.');

        const comment = post.comments[commentIndex];

        // Check permissions
        const canDelete = deleter.id === comment.author.id || deleter.status === 'pro_max';
        if (!canDelete) {
            throw new Error('Nincs jogosultságod a komment törléséhez.');
        }

        // Send notification if a mod deletes it
        const POLICE_BOT_ID = 'system_police_bot';
        if (comment.author.id !== deleter.id) {
            const contentPreview = comment.content ? `"${comment.content.substring(0, 30)}..."` : (comment.imageUrl ? "képes kommentedet" : "GIF-es kommentedet");
            const systemMessage = `Az egyik kommentedet (${contentPreview}) egy Pro Max felhasználó (${deleter.name}) törölte a következő bejegyzés alól: "${post.content?.substring(0, 30)}...".`;
            const convoId = await messageService.findOrCreateConversation(POLICE_BOT_ID, comment.author.id);
            await messageService.sendMessage(POLICE_BOT_ID, convoId, systemMessage, null, null, false);
        }

        // Cleanup from IndexedDB
        if (comment.imageUrl && comment.imageUrl.startsWith('idb_key:')) {
            await largeDataService.deleteItem(comment.imageUrl.substring(8));
        }

        // Delete the comment
        post.comments.splice(commentIndex, 1);
        await storePosts(posts);
        return { ...post };
    },

    async toggleCommentReaction(postId: string, commentId: string, reaction: string, userId: string): Promise<Post> {
        await new Promise(res => setTimeout(res, 50));
        const posts = getStoredPosts();
        const post = posts.find(p => p.id === postId);
        if (!post) throw new Error("A bejegyzés nem található.");
        const comment = post.comments.find(c => c.id === commentId);
        if (!comment) throw new Error("A komment nem található.");
        
        comment.reactions = comment.reactions || {};

        let userPreviousReaction: string | null = null;
        for (const reactionKey in comment.reactions) {
            if (comment.reactions[reactionKey].includes(userId)) {
                userPreviousReaction = reactionKey;
                break;
            }
        }
        
        if (userPreviousReaction) {
            const userIndex = comment.reactions[userPreviousReaction].indexOf(userId);
            comment.reactions[userPreviousReaction].splice(userIndex, 1);
            if (comment.reactions[userPreviousReaction].length === 0) {
                delete comment.reactions[userPreviousReaction];
            }
        }

        if (userPreviousReaction !== reaction) {
            if (!comment.reactions[reaction]) {
                comment.reactions[reaction] = [];
            }
            comment.reactions[reaction].push(userId);
        }

        await storePosts(posts);
        return { ...post };
    }
};
