import type { User, Newspaper, Comment } from '../types';
import { messageService } from './messageService';

const NEWSPAPER_KEY = 'astoria_newspapers';

const getStoredNewspapers = (): Newspaper[] => {
    const newspapersJson = localStorage.getItem(NEWSPAPER_KEY);
    return newspapersJson ? JSON.parse(newspapersJson) : [];
};

const storeNewspapers = (newspapers: Newspaper[]) => {
    let newspapersToStore = [...newspapers];
    let stored = false;

    while (!stored) {
        try {
            localStorage.setItem(NEWSPAPER_KEY, JSON.stringify(newspapersToStore));
            stored = true;
        } catch (e: any) {
            if (e.name === 'QuotaExceededError' || (e.code && (e.code === 22 || e.code === 1014))) {
                console.warn('LocalStorage quota exceeded for newspapers. Removing oldest newspaper.');
                
                newspapersToStore.sort((a, b) => a.uploadedAt - b.uploadedAt);

                if (newspapersToStore.length > 1) {
                    newspapersToStore.shift(); 
                } else {
                    throw new Error('A Helyi Lap képe túl nagy a tároláshoz.');
                }
            } else {
                throw e;
            }
        }
    }
};

const imageFileToBase64 = (file: File): Promise<string> => {
    return new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.readAsDataURL(file);
        reader.onload = event => {
            if (!event.target?.result) {
                return reject(new Error("FileReader did not return a result."));
            }
            const img = new Image();
            img.src = event.target.result as string;
            img.onload = () => {
                const canvas = document.createElement('canvas');
                const MAX_WIDTH = 800;
                const MAX_HEIGHT = 800;
                let width = img.width;
                let height = img.height;

                if (width > height) {
                    if (width > MAX_WIDTH) {
                        height *= MAX_WIDTH / width;
                        width = MAX_WIDTH;
                    }
                } else {
                    if (height > MAX_HEIGHT) {
                        width *= MAX_HEIGHT / height;
                        height = MAX_HEIGHT;
                    }
                }

                canvas.width = width;
                canvas.height = height;
                const ctx = canvas.getContext('2d');
                if (!ctx) {
                    return reject(new Error('Could not get canvas context'));
                }
                ctx.drawImage(img, 0, 0, width, height);
                
                // Convert to JPEG for smaller file size. Quality 0.9 is a good balance.
                resolve(canvas.toDataURL('image/jpeg', 0.9));
            };
            img.onerror = error => reject(error);
        };
        reader.onerror = error => reject(error);
    });
};

const getWeekId = (date: Date): string => {
    const d = new Date(Date.UTC(date.getFullYear(), date.getMonth(), date.getDate()));
    d.setUTCDate(d.getUTCDate() + 4 - (d.getUTCDay() || 7)); // Set to nearest Thursday: current date + 4 - current day number
    const yearStart = new Date(Date.UTC(d.getUTCFullYear(), 0, 1));
    const weekNo = Math.ceil((((d.getTime() - yearStart.getTime()) / 86400000) + 1) / 7);
    return `${d.getUTCFullYear()}-${weekNo}`;
};


export const newspaperService = {
    async uploadNewspaper(issueNumber: number, imageFile: File, uploader: User): Promise<Newspaper> {
        await new Promise(res => setTimeout(res, 1000));
        const allNewspapers = getStoredNewspapers();
        const currentWeekId = getWeekId(new Date());

        const existingIssue = allNewspapers.find(n => n.issueNumber === issueNumber);
        if (existingIssue) {
            throw new Error(`A(z) ${issueNumber}. szám már létezik.`);
        }

        const imageUrl = await imageFileToBase64(imageFile);
        
        const newNewspaper: Newspaper = {
            id: `newspaper_${Date.now()}`,
            weekId: currentWeekId,
            issueNumber,
            imageUrl,
            uploadedAt: Date.now(),
            uploaderId: uploader.id,
            comments: [],
        };
        
        const updatedNewspapers = [...allNewspapers, newNewspaper];
        storeNewspapers(updatedNewspapers);
        
        return newNewspaper;
    },

    async getNewspapers(): Promise<Newspaper[]> {
        await new Promise(res => setTimeout(res, 300));
        const newspapers = getStoredNewspapers();
        // Sort by issue number, descending
        return newspapers.sort((a, b) => b.issueNumber - a.issueNumber);
    },

    async addCommentToNewspaper(newspaperId: string, author: User, content: string | null, imageFile: File | null, gifUrl: string | null): Promise<Newspaper> {
        await new Promise(res => setTimeout(res, 300));
        const newspapers = getStoredNewspapers();
        const newspaper = newspapers.find(p => p.id === newspaperId);
        if (!newspaper) throw new Error("A Helyi Lap nem található.");

        const imageUrl = imageFile ? await imageFileToBase64(imageFile) : null;

        const newComment: Comment = {
            id: `comment_${Date.now()}`,
            author,
            content,
            imageUrl,
            gifUrl,
            timestamp: Date.now(),
            reactions: {},
        };

        newspaper.comments.push(newComment);
        storeNewspapers(newspapers);
        return { ...newspaper };
    },

    async deleteCommentFromNewspaper(newspaperId: string, commentId: string, deleter: User): Promise<Newspaper> {
        await new Promise(res => setTimeout(res, 300));
        const newspapers = getStoredNewspapers();
        const newspaper = newspapers.find(p => p.id === newspaperId);
        if (!newspaper) throw new Error('A Helyi Lap nem található.');

        const commentIndex = newspaper.comments.findIndex(c => c.id === commentId);
        if (commentIndex === -1) throw new Error('A komment nem található.');

        const comment = newspaper.comments[commentIndex];

        const canDelete = deleter.id === comment.author.id || deleter.status === 'pro' || deleter.status === 'pro_max';
        if (!canDelete) {
            throw new Error('Nincs jogosultságod a komment törléséhez.');
        }

        const POLICE_BOT_ID = 'system_police_bot';
        if (comment.author.id !== deleter.id) {
            const contentPreview = comment.content ? `"${comment.content.substring(0, 30)}..."` : (comment.imageUrl ? "képes kommentedet" : "GIF-es kommentedet");
            const systemMessage = `Az egyik kommentedet (${contentPreview}) egy Pro/Pro Max felhasználó (${deleter.name}) törölte a(z) ${newspaper.issueNumber}. számú Helyi Lap alól.`;
            const convoId = await messageService.findOrCreateConversation(POLICE_BOT_ID, comment.author.id);
            await messageService.sendMessage(POLICE_BOT_ID, convoId, systemMessage, null, null, false);
        }

        newspaper.comments.splice(commentIndex, 1);
        storeNewspapers(newspapers);
        return { ...newspaper };
    },

    async toggleCommentReactionOnNewspaper(newspaperId: string, commentId: string, reaction: string, userId: string): Promise<Newspaper> {
        await new Promise(res => setTimeout(res, 50));
        const newspapers = getStoredNewspapers();
        const newspaper = newspapers.find(p => p.id === newspaperId);
        if (!newspaper) throw new Error("A Helyi Lap nem található.");
        const comment = newspaper.comments.find(c => c.id === commentId);
        if (!comment) throw new Error("A komment nem található.");
        
        comment.reactions = comment.reactions || {};

        let userPreviousReaction: string | null = null;
        for (const reactionKey in comment.reactions) {
            if (comment.reactions[reactionKey].includes(userId)) {
                userPreviousReaction = reactionKey;
                break;
            }
        }
        
        if (userPreviousReaction) {
            const userIndex = comment.reactions[userPreviousReaction].indexOf(userId);
            comment.reactions[userPreviousReaction].splice(userIndex, 1);
            if (comment.reactions[userPreviousReaction].length === 0) {
                delete comment.reactions[userPreviousReaction];
            }
        }

        if (userPreviousReaction !== reaction) {
            if (!comment.reactions[reaction]) {
                comment.reactions[reaction] = [];
            }
            comment.reactions[reaction].push(userId);
        }

        storeNewspapers(newspapers);
        return { ...newspaper };
    }
};