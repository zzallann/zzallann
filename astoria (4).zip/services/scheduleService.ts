import type { User, WeeklySchedule } from '../types';

const SCHEDULES_KEY = 'astoria_weekly_schedules';

const getStoredSchedules = (): WeeklySchedule[] => {
    const schedulesJson = localStorage.getItem(SCHEDULES_KEY);
    return schedulesJson ? JSON.parse(schedulesJson) : [];
};

const storeSchedules = (schedules: WeeklySchedule[]) => {
    let schedulesToStore = [...schedules];
    let stored = false;

    while (!stored) {
        try {
            localStorage.setItem(SCHEDULES_KEY, JSON.stringify(schedulesToStore));
            stored = true;
        } catch (e: any) {
            if (e.name === 'QuotaExceededError' || (e.code && (e.code === 22 || e.code === 1014))) {
                console.warn('LocalStorage quota exceeded for schedules. Removing oldest schedule.');
                
                schedulesToStore.sort((a, b) => a.weekId.localeCompare(b.weekId));

                if (schedulesToStore.length > 1) {
                    schedulesToStore.shift(); 
                } else {
                    throw new Error('A beosztás képe túl nagy a tároláshoz.');
                }
            } else {
                throw e;
            }
        }
    }
};

const getWeekIdFromDate = (date: Date): string => {
    const d = new Date(Date.UTC(date.getFullYear(), date.getMonth(), date.getDate()));
    d.setUTCDate(d.getUTCDate() + 4 - (d.getUTCDay() || 7));
    const yearStart = new Date(Date.UTC(d.getUTCFullYear(), 0, 1));
    const weekNo = Math.ceil((((d.getTime() - yearStart.getTime()) / 86400000) + 1) / 7);
    return `${d.getUTCFullYear()}-${weekNo}`;
};


export const scheduleService = {
    async uploadSchedule(user: User, weekId: string, text: string | null, imageUrl: string | null, gifUrl: string | null, proMaxScheduleText?: string | null): Promise<void> {
        await new Promise(res => setTimeout(res, 1000));
        
        let schedules = getStoredSchedules();
        const existingIndex = schedules.findIndex(s => s.weekId === weekId);
        
        // If all content is null, it's a deletion request
        if (text === null && imageUrl === null && gifUrl === null && proMaxScheduleText === null) {
            if (existingIndex > -1) {
                schedules.splice(existingIndex, 1);
                storeSchedules(schedules);
            }
            return;
        }

        const newScheduleData: Partial<WeeklySchedule> = {
            uploadedAt: Date.now(),
            uploaderName: user.name,
        };

        if (text !== undefined) newScheduleData.text = text;
        if (imageUrl !== undefined) newScheduleData.imageUrl = imageUrl;
        if (gifUrl !== undefined) newScheduleData.gifUrl = gifUrl;
        if (proMaxScheduleText !== undefined) newScheduleData.proMaxScheduleText = proMaxScheduleText;
        
        if (existingIndex > -1) {
            // Update existing schedule for the week
            schedules[existingIndex] = { ...schedules[existingIndex], ...newScheduleData };
        } else {
            // Create a new one
            const newSchedule: WeeklySchedule = {
                id: `schedule_${weekId}`,
                weekId,
                text: text,
                imageUrl: imageUrl,
                gifUrl: gifUrl,
                uploadedAt: Date.now(),
                uploaderName: user.name,
                proMaxScheduleText: proMaxScheduleText || null,
            };
            schedules.push(newSchedule);
        }
        
        storeSchedules(schedules);
    },

    async getScheduleForWeek(weekId: string): Promise<WeeklySchedule | null> {
        await new Promise(res => setTimeout(res, 300));
        const schedules = getStoredSchedules();
        return schedules.find(s => s.weekId === weekId) || null;
    },
    
    async calculateMonthlyHours(dateInMonth: Date, allUsers: User[]): Promise<Record<string, number>> {
        await new Promise(res => setTimeout(res, 500));
        const year = dateInMonth.getFullYear();
        const month = dateInMonth.getMonth();
        const allSchedules = getStoredSchedules();

        const relevantSchedules = allSchedules.filter(s => {
            const [sYear, sWeek] = s.weekId.split('-').map(Number);
            if (sYear !== year) return false;
            // This is a simplification; a precise implementation would check which weeks fall into the month.
            // For now, we crudely check if the week number is within a rough range for the month.
            const approxStartWeek = month * 4;
            const approxEndWeek = (month + 1) * 4 + 1;
            return sWeek >= approxStartWeek && sWeek <= approxEndWeek;
        });

        const monthlyHours: Record<string, number> = {};
        const userMapByName = new Map(allUsers.map(u => [u.name.toLowerCase().split('(')[0].trim(), u]));

        const calculateHoursInText = (text: string): Record<string, number> => {
            const hours: Record<string, number> = {};
            const blocks = text.split('---').map(b => b.trim()).filter(Boolean);
            for (const block of blocks) {
                const lines = block.split('\n').map(l => l.trim()).filter(Boolean);
                const userName = lines.shift()?.trim();
                if (!userName) continue;

                const user = userMapByName.get(userName.toLowerCase().split('(')[0].trim());
                if (!user) continue;

                const userHours = lines.reduce((sum, line) => {
                    const timeMatch = line.match(/(\d{1,2}):(\d{2})-(\d{1,2}):(\d{2})/);
                    if (!timeMatch) return sum;
                    let [, startHour, startMin, endHour, endMin] = timeMatch.map(Number);
                    if (endHour < startHour) endHour += 24;
                    const startTotalMinutes = startHour * 60 + startMin;
                    const endTotalMinutes = endHour * 60 + endMin;
                    return sum + (endTotalMinutes - startTotalMinutes) / 60;
                }, 0);
                hours[user.id] = (hours[user.id] || 0) + userHours;
            }
            return hours;
        };

        for (const schedule of relevantSchedules) {
            if (schedule.text) {
                const weekHours = calculateHoursInText(schedule.text);
                for (const userId in weekHours) {
                    monthlyHours[userId] = (monthlyHours[userId] || 0) + weekHours[userId];
                }
            }
        }
        return monthlyHours;
    },
};