import type { AssignedTask, User } from '../types';
import { messageService } from './messageService';
import { authService } from './authService';

const TASKS_KEY = 'astoria_assigned_tasks';

const getStoredTasks = (): AssignedTask[] => {
    const tasksJson = localStorage.getItem(TASKS_KEY);
    let tasks = tasksJson ? JSON.parse(tasksJson) : [];
    
    // Migration logic from old `completed: boolean` to new `status: string`
    let needsUpdate = false;
    tasks.forEach((task: any) => {
        if (typeof task.completed === 'boolean') {
            task.status = task.completed ? 'completed' : 'pending';
            delete task.completed;
            task.isUpdateSeenByAssigner = true; // Don't notify for old migrated tasks
            needsUpdate = true;
        }
    });

    if (needsUpdate) {
        storeTasks(tasks);
    }

    return tasks;
};

const storeTasks = (tasks: AssignedTask[]) => {
    localStorage.setItem(TASKS_KEY, JSON.stringify(tasks));
};

export const taskService = {
    async createTask(description: string, assignedToUserId: string, deadline: number, assigner: User): Promise<AssignedTask> {
        await new Promise(res => setTimeout(res, 300));
        const tasks = getStoredTasks();
        const newTask: AssignedTask = {
            id: `task_${Date.now()}_${Math.random()}`,
            description,
            assignedToUserId,
            deadline,
            status: 'pending',
            assignedById: assigner.id,
            isUpdateSeenByAssigner: true, // No update to see yet
        };
        tasks.push(newTask);
        storeTasks(tasks);
        return newTask;
    },

    async getTasksForUser(userId: string): Promise<AssignedTask[]> {
        await new Promise(res => setTimeout(res, 200));
        const tasks = getStoredTasks();
        return tasks.filter(t => t.assignedToUserId === userId).sort((a,b) => a.deadline - b.deadline);
    },

    async getAllTasks(): Promise<AssignedTask[]> {
        await new Promise(res => setTimeout(res, 200));
        return getStoredTasks().sort((a,b) => b.deadline - a.deadline);
    },

    async getArchivedTasks(): Promise<AssignedTask[]> {
        await new Promise(res => setTimeout(res, 200));
        const tasks = getStoredTasks();
        return tasks
            .filter(t => t.status === 'completed' || t.status === 'rejected' || t.status === 'deleted')
            .sort((a,b) => (b.completedAt || b.deletedAt || b.deadline) - (a.completedAt || a.deletedAt || a.deadline));
    },

    async markTaskAsComplete(taskId: string, completedByUser: User): Promise<AssignedTask> {
        await new Promise(res => setTimeout(res, 200));
        const tasks = getStoredTasks();
        const taskIndex = tasks.findIndex(t => t.id === taskId);
        if (taskIndex === -1) throw new Error('Task not found');
        
        const task = tasks[taskIndex];
        if (task.status === 'completed') return task;

        task.status = 'completed';
        task.completedAt = Date.now();
        task.isUpdateSeenByAssigner = false;
        storeTasks(tasks);

        const POLICE_BOT_ID = 'system_police_bot';
        if (task.assignedById && task.assignedById !== completedByUser.id) {
            const message = `${completedByUser.name} elvégezte a feladatot: "${task.description}"`;
            const convoId = await messageService.findOrCreateConversation(POLICE_BOT_ID, task.assignedById);
            await messageService.sendMessage(POLICE_BOT_ID, convoId, message, null, null, false);
        }
        
        return task;
    },
    
    async rejectTask(taskId: string, user: User): Promise<AssignedTask> {
        await new Promise(res => setTimeout(res, 200));
        const tasks = getStoredTasks();
        const taskIndex = tasks.findIndex(t => t.id === taskId);
        if (taskIndex === -1) throw new Error('Task not found');
        
        const task = tasks[taskIndex];
        task.status = 'rejected';
        task.isUpdateSeenByAssigner = false;
        storeTasks(tasks);

        const POLICE_BOT_ID = 'system_police_bot';
        if (task.assignedById && task.assignedById !== user.id) {
            const message = `${user.name} elutasította a feladatot: "${task.description}"`;
            const convoId = await messageService.findOrCreateConversation(POLICE_BOT_ID, task.assignedById);
            await messageService.sendMessage(POLICE_BOT_ID, convoId, message, null, null, false);
        }
        return task;
    },
    
    async updateTaskDeadline(taskId: string, newDeadline: number): Promise<AssignedTask> {
        await new Promise(res => setTimeout(res, 200));
        const tasks = getStoredTasks();
        const taskIndex = tasks.findIndex(t => t.id === taskId);
        if (taskIndex === -1) throw new Error('Task not found');
        
        const task = tasks[taskIndex];
        
        if (!task.deadlineHistory) {
            task.deadlineHistory = [];
        }
        task.deadlineHistory.push({
            oldDeadline: task.deadline,
            newDeadline: newDeadline,
            changedAt: Date.now(),
        });

        task.deadline = newDeadline;
        storeTasks(tasks);
        
        const assignedUser = authService.getUserById(task.assignedToUserId);
        if (assignedUser) {
             const assigner = authService.getUserById(task.assignedById);
             const message = `${assigner?.name || 'A felettesed'} módosította a határidejét a következő feladatnak: "${task.description}". Az új határidő: ${new Date(newDeadline).toLocaleDateString('hu-HU')}`;
             const POLICE_BOT_ID = 'system_police_bot';
             const convoId = await messageService.findOrCreateConversation(POLICE_BOT_ID, assignedUser.id);
             await messageService.sendMessage(POLICE_BOT_ID, convoId, message, null, null, false);
        }

        return task;
    },

    async markTaskAsDeleted(taskId: string, deleterId: string): Promise<void> {
        await new Promise(res => setTimeout(res, 200));
        let tasks = getStoredTasks();
        const taskIndex = tasks.findIndex(t => t.id === taskId);
        if (taskIndex === -1) throw new Error("A törlendő feladat nem található.");

        const taskToDelete = tasks[taskIndex];
        
        taskToDelete.status = 'deleted';
        taskToDelete.deletedById = deleterId;
        taskToDelete.deletedAt = Date.now();

        const assigner = authService.getUserById(deleterId);
        const assigneeId = taskToDelete.assignedToUserId;
        const POLICE_BOT_ID = 'system_police_bot';
        
        if (assigner && assigneeId && assigneeId !== assigner.id) {
            const messageContent = `Figyelem! A következő, neked kiosztott feladatot a felettesed (${assigner.name}) törölte: "${taskToDelete.description}".`;
            const convoId = await messageService.findOrCreateConversation(POLICE_BOT_ID, assigneeId);
            await messageService.sendMessage(POLICE_BOT_ID, convoId, messageContent, null, null, false);
        }

        storeTasks(tasks);
    },

    async getUnreadTaskUpdateCount(assignerId: string): Promise<number> {
        await new Promise(res => setTimeout(res, 100));
        const tasks = getStoredTasks();
        return tasks.filter(t => t.assignedById === assignerId && !t.isUpdateSeenByAssigner).length;
    },

    async markTaskUpdatesAsSeen(assignerId: string): Promise<void> {
        await new Promise(res => setTimeout(res, 100));
        const tasks = getStoredTasks();
        let changed = false;
        tasks.forEach(task => {
            if (task.assignedById === assignerId && !task.isUpdateSeenByAssigner) {
                task.isUpdateSeenByAssigner = true;
                changed = true;
            }
        });
        if (changed) {
            storeTasks(tasks);
        }
    }
};