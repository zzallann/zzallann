import type { User, Message, Conversation } from '../types';
import { authService } from './authService';
import { groupAvatarIds } from '../components/AvatarSelector';


// =============================================================================
// IMPORTANT: MOCK BACKEND SIMULATION FOR MESSAGING
// =============================================================================
// This service simulates a backend for messaging using localStorage.
// =============================================================================

const MESSAGES_KEY = 'astoria_messages';
const CONVERSATIONS_KEY = 'astoria_conversations';
const MUTED_CONVOS_KEY = 'astoria_muted_convos';
const GROUP_CHAT_CONVO_ID = 'system_group_chat';
const PRO_CHAT_CONVO_ID = 'system_pro_chat';
const PRO_MAX_CHAT_CONVO_ID = 'system_pro_max_chat';
const ULTRA_CHAT_CONVO_ID = 'system_ultra_chat';


interface StoredConversation {
    id: string;
    name?: string;
    imageUrl?: string | null;
    avatarId?: string | null;
    participantIds: string[];
    isSystemConversation: boolean;
    lastMessageTimestamp: number;
    unreadCount: Record<string, number>;
    lastSeenBy: Record<string, number>; // userId -> timestamp
    createdBy?: string;
    nicknames?: Record<string, string>;
}

// Helper to get all stored data
const getStoredMessages = (): Message[] => JSON.parse(localStorage.getItem(MESSAGES_KEY) || '[]');
const getStoredConversations = (): StoredConversation[] => {
    const convos = JSON.parse(localStorage.getItem(CONVERSATIONS_KEY) || '[]') as any[];
    let needsUpdate = false;
    // Migration for old conversations without lastSeenBy
    convos.forEach(c => {
        if (!c.lastSeenBy) {
            c.lastSeenBy = {};
            needsUpdate = true;
        }
    });
    if (needsUpdate) {
        storeConversations(convos as StoredConversation[]);
    }
    return convos as StoredConversation[];
};

// Helper to store data
const storeMessages = (messages: Message[]) => {
    let messagesToStore = [...messages];
    let stored = false;

    while (!stored) {
        try {
            localStorage.setItem(MESSAGES_KEY, JSON.stringify(messagesToStore));
            stored = true;
        } catch (e: any) {
            if (e.name === 'QuotaExceededError' || (e.code && (e.code === 22 || e.code === 1014))) {
                console.warn('LocalStorage quota exceeded for messages. Removing oldest messages.');
                
                messagesToStore.sort((a, b) => a.timestamp - b.timestamp);

                if (messagesToStore.length > 1) {
                    messagesToStore.shift(); 
                } else {
                    throw new Error('Az üzenet (kép) túl nagy a tároláshoz.');
                }
            } else {
                throw e;
            }
        }
    }
};
const storeConversations = (conversations: StoredConversation[]) => localStorage.setItem(CONVERSATIONS_KEY, JSON.stringify(conversations));

const getMutedConversations = (): Record<string, number> => {
    const mutedJson = localStorage.getItem(MUTED_CONVOS_KEY);
    return mutedJson ? JSON.parse(mutedJson) : {};
};

const storeMutedConversations = (muted: Record<string, number>) => {
    localStorage.setItem(MUTED_CONVOS_KEY, JSON.stringify(muted));
};

// --- LAZY INITIALIZATION ---
let isInitialized = false;

const initializeMockData = () => {
    const allUsers = authService.getAllUsers().filter(u => u.approved);
    let conversations = getStoredConversations();
    let needsUpdate = false;

    const specialChats: { id: string; name: string; participants: string[] }[] = [
        { id: GROUP_CHAT_CONVO_ID, name: 'Csoportos Chat', participants: allUsers.map(u => u.id) },
        { id: PRO_CHAT_CONVO_ID, name: 'Pro Chat', participants: allUsers.filter(u => u.status === 'pro').map(u => u.id) },
        { id: PRO_MAX_CHAT_CONVO_ID, name: 'Pro Max Chat', participants: allUsers.filter(u => u.status === 'pro_max').map(u => u.id) },
        { id: ULTRA_CHAT_CONVO_ID, name: 'Ultra Chat', participants: allUsers.filter(u => u.status === 'pro' || u.status === 'pro_max').map(u => u.id) },
    ];

    specialChats.forEach(chatInfo => {
        if (!conversations.find(c => c.id === chatInfo.id)) {
            conversations.push({
                id: chatInfo.id,
                name: chatInfo.name,
                imageUrl: null,
                avatarId: null,
                participantIds: chatInfo.participants,
                isSystemConversation: true,
                lastMessageTimestamp: Date.now(),
                unreadCount: {},
                lastSeenBy: {},
                nicknames: {},
            });
            needsUpdate = true;
        }
    });

    if (conversations.length === 0) { // Fresh start
         storeMessages([]);
    }

    if (needsUpdate || conversations.length === 0) {
        storeConversations(conversations);
    }
};

const ensureInitialized = () => {
    if (!isInitialized) {
        initializeMockData();
        isInitialized = true;
    }
};
// --- END LAZY INITIALIZATION ---


export const messageService = {
    async getConversations(currentUserId: string): Promise<Conversation[]> {
        ensureInitialized();
        await new Promise(res => setTimeout(res, 200)); // Simulate network
        const storedConvos = getStoredConversations();
        const allMessages = getStoredMessages();

        // OPTIMIZATION: Fetch all users once and create a lookup map
        const allUsers = authService.getAllUsers();
        const userMap = new Map<string, User>(allUsers.map(u => [u.id, u]));
        // Add system users to the map as well
        const systemPoliceBot = authService.getUserById('system_police_bot');
        if (systemPoliceBot) userMap.set(systemPoliceBot.id, systemPoliceBot);

        // Create a map of the last message for each conversation for efficient lookup
        const lastMessages: Record<string, Message> = {};
        for (const msg of allMessages) {
            const existing = lastMessages[msg.conversationId];
            if (!existing || msg.timestamp > existing.timestamp) {
                lastMessages[msg.conversationId] = msg;
            }
        }

        const userConversations = storedConvos
            .filter(c => c.participantIds.includes(currentUserId));
            
        const enriched: Conversation[] = userConversations.map(convo => {
            const participants = convo.participantIds
                .map(id => userMap.get(id)) // Use the efficient map lookup
                .filter((u): u is User => !!u);
                
            const lastMessage = lastMessages[convo.id] || null;

            return {
                id: convo.id,
                name: convo.name,
                imageUrl: convo.imageUrl,
                avatarId: convo.avatarId,
                participants,
                lastMessage,
                isSystemConversation: convo.isSystemConversation,
                unreadCount: convo.unreadCount[currentUserId] || 0,
                createdBy: convo.createdBy,
                nicknames: convo.nicknames || {},
            };
        });
        
        // Sort: Group Chat, special chats, then system police, then by last message timestamp
        return enriched.sort((a, b) => {
            const getOrder = (convo: Conversation) => {
                if (convo.id === GROUP_CHAT_CONVO_ID) return 1;
                if (convo.id === PRO_MAX_CHAT_CONVO_ID) return 2;
                if (convo.id === ULTRA_CHAT_CONVO_ID) return 3;
                if (convo.id === PRO_CHAT_CONVO_ID) return 4;
                if (convo.participants.some(p => p.id === 'system_police_bot')) return 5;
                return 6;
            };
            const orderA = getOrder(a);
            const orderB = getOrder(b);
            if (orderA !== orderB) return orderA - orderB;
            return (b.lastMessage?.timestamp || 0) - (a.lastMessage?.timestamp || 0);
        });
    },

    async getMessages(conversationId: string, currentUserId: string, page: number, limit: number): Promise<{ messages: Message[], hasMore: boolean, firstUnreadIndex: number, lastSeenBy: Record<string, number>, nicknames: Record<string, string> }> {
        ensureInitialized();
        await new Promise(res => setTimeout(res, 150));
        
        const allMessages = getStoredMessages();
        const storedConvos = getStoredConversations();
        const convoIndex = storedConvos.findIndex(c => c.id === conversationId);
        
        if (convoIndex === -1) {
            return { messages: [], hasMore: false, firstUnreadIndex: -1, lastSeenBy: {}, nicknames: {} };
        }
        const convo = storedConvos[convoIndex];

        // 1. Update last seen timestamp FOR THIS CONVERSATION
        const now = Date.now();
        convo.lastSeenBy = convo.lastSeenBy || {};
        convo.lastSeenBy[currentUserId] = now;

        const convoMessages = allMessages.filter(m => m.conversationId === conversationId);
        convoMessages.sort((a, b) => a.timestamp - b.timestamp);
        
        // 2. Find first unread BEFORE marking things as read
        let firstUnreadIndex = -1;
        const unreadCount = convo.unreadCount[currentUserId] || 0;
        if (page === 1 && unreadCount > 0) {
            const unreadStartIndex = convoMessages.length - unreadCount;
            if (unreadStartIndex >= 0) {
                firstUnreadIndex = unreadStartIndex;
            }
        }
        
        // 3. Reset the unread count for the current user.
        if (convo.unreadCount[currentUserId] > 0) {
            convo.unreadCount[currentUserId] = 0;
        }

        // 4. Save updated conversation data
        storeConversations(storedConvos);

        // 5. Pagination logic. The old `seenBy` is no longer populated or used.
        const totalMessages = convoMessages.length;
        const startIndex = Math.max(0, totalMessages - (page * limit));
        const endIndex = totalMessages - ((page - 1) * limit);
        const paginatedMessages = convoMessages.slice(startIndex, endIndex);
        const hasMore = startIndex > 0;
        
        // Adjust firstUnreadIndex for pagination
        if (firstUnreadIndex !== -1) {
            const paginatedFirstUnreadIndex = firstUnreadIndex - startIndex;
            firstUnreadIndex = (paginatedFirstUnreadIndex >= 0 && paginatedFirstUnreadIndex < paginatedMessages.length) ? paginatedFirstUnreadIndex : -1;
        }

        return { messages: paginatedMessages, hasMore, lastSeenBy: convo.lastSeenBy, firstUnreadIndex, nicknames: convo.nicknames || {} };
    },

    async sendMessage(
        senderId: string, 
        conversationId: string, 
        content: string, 
        imageUrl: string | null,
        gifUrl: string | null,
        isFeedback: boolean
    ): Promise<Message> {
        ensureInitialized();
        await new Promise(res => setTimeout(res, 300));

        const newMessage: Message = {
            id: `msg_${Date.now()}`,
            conversationId,
            senderId,
            content,
            imageUrl,
            gifUrl,
            timestamp: Date.now(),
            isFeedback,
            reactions: {},
            seenBy: [senderId], // Sender has always seen it
        };

        const allMessages = getStoredMessages();
        allMessages.push(newMessage);
        storeMessages(allMessages);

        // Update conversation metadata
        const conversations = getStoredConversations();
        const convoIndex = conversations.findIndex(c => c.id === conversationId);
        if (convoIndex > -1) {
            const convo = conversations[convoIndex];
            convo.lastMessageTimestamp = newMessage.timestamp;
            // Increment unread count for all other participants
            convo.participantIds.forEach(pid => {
                if (pid !== senderId) {
                    convo.unreadCount[pid] = (convo.unreadCount[pid] || 0) + 1;
                }
            });
            storeConversations(conversations);
        }

        return newMessage;
    },

    async findOrCreateConversation(user1Id: string, user2Id: string): Promise<string> {
        ensureInitialized();
        await new Promise(res => setTimeout(res, 100));
        let conversations = getStoredConversations();
        
        const existingConvo = conversations.find(c => 
            !c.isSystemConversation &&
            !c.name && // Don't match named group chats
            c.participantIds.length === 2 &&
            c.participantIds.includes(user1Id) &&
            c.participantIds.includes(user2Id)
        );

        if (existingConvo) {
            return existingConvo.id;
        }

        const newConvo: StoredConversation = {
            id: `convo_${user1Id}_${user2Id}_${Date.now()}`,
            participantIds: [user1Id, user2Id],
            imageUrl: null,
            avatarId: null,
            isSystemConversation: user1Id.startsWith('system') || user2Id.startsWith('system'),
            lastMessageTimestamp: Date.now(),
            unreadCount: {},
            lastSeenBy: {},
            nicknames: {},
        };

        conversations.push(newConvo);
        storeConversations(conversations);
        return newConvo.id;
    },
    
    async createGroupConversation(creator: User, participantIds: string[], groupName: string): Promise<Conversation> {
        ensureInitialized();
        await new Promise(res => setTimeout(res, 400));
        let conversations = getStoredConversations();
        const allParticipantIds = [...new Set([creator.id, ...participantIds])];

        const randomAvatarId = groupAvatarIds[Math.floor(Math.random() * groupAvatarIds.length)];

        const newConvo: StoredConversation = {
            id: `group_${Date.now()}`,
            name: groupName,
            imageUrl: null,
            avatarId: randomAvatarId,
            participantIds: allParticipantIds,
            isSystemConversation: false,
            lastMessageTimestamp: Date.now(),
            unreadCount: {},
            lastSeenBy: {},
            createdBy: creator.id,
            nicknames: {},
        };

        conversations.push(newConvo);
        storeConversations(conversations);

        // Send an initial system message
        const initialMessageContent = `${creator.name} létrehozta a csoportot.`;
        const initialMessage = await this.sendMessage('system_police_bot', newConvo.id, initialMessageContent, null, null, false);
        
        // Enrich and return the new conversation
        const participants = allParticipantIds
            .map(id => authService.getUserById(id))
            .filter((u): u is User => !!u);

        return {
            id: newConvo.id,
            name: newConvo.name,
            imageUrl: newConvo.imageUrl,
            avatarId: newConvo.avatarId,
            participants,
            lastMessage: initialMessage,
            isSystemConversation: newConvo.isSystemConversation,
            unreadCount: 0,
            createdBy: newConvo.createdBy,
            nicknames: newConvo.nicknames,
        };
    },

    async updateGroupChatImage(conversationId: string, imageUrl: string): Promise<void> {
        ensureInitialized();
        await new Promise(res => setTimeout(res, 300));
        const conversations = getStoredConversations();
        const convoIndex = conversations.findIndex(c => c.id === conversationId);
        if (convoIndex > -1) {
            conversations[convoIndex].imageUrl = imageUrl;
            conversations[convoIndex].avatarId = null; // A custom image overrides the random avatar
            storeConversations(conversations);
        } else {
            throw new Error('Conversation not found.');
        }
    },

    async renameGroupConversation(conversationId: string, newName: string, actor: User): Promise<void> {
        ensureInitialized();
        await new Promise(res => setTimeout(res, 300));
        const conversations = getStoredConversations();
        const convoIndex = conversations.findIndex(c => c.id === conversationId);

        if (convoIndex > -1) {
            const convo = conversations[convoIndex];
            const oldName = convo.name;
            if (oldName !== newName) {
                convo.name = newName;
                storeConversations(conversations);
                
                const message = `${actor.name} megváltoztatta a csoport nevét: "${newName}"`;
                await this.sendMessage('system_police_bot', conversationId, message, null, null, false);
            }
        } else {
            throw new Error('Conversation not found.');
        }
    },

    async setNickname(conversationId: string, targetUserId: string, nickname: string, actor: User): Promise<void> {
        ensureInitialized();
        await new Promise(res => setTimeout(res, 300));
        const conversations = getStoredConversations();
        const convoIndex = conversations.findIndex(c => c.id === conversationId);

        if (convoIndex === -1) throw new Error("A beszélgetés nem található.");

        const convo = conversations[convoIndex];
        convo.nicknames = convo.nicknames || {};

        const targetUser = authService.getUserById(targetUserId);
        if (!targetUser) throw new Error("A célfelhasználó nem található.");

        const oldNickname = convo.nicknames[targetUserId];
        let message = '';

        if (nickname.trim()) {
            if (oldNickname !== nickname.trim()) {
                convo.nicknames[targetUserId] = nickname.trim();
                message = `${actor.name} beállította "${targetUser.name}" becenevét: "${nickname.trim()}"`;
            }
        } else {
            if (oldNickname) {
                delete convo.nicknames[targetUserId];
                message = `${actor.name} eltávolította "${targetUser.name}" becenevét.`;
            }
        }
        
        conversations[convoIndex] = convo;
        storeConversations(conversations);

        if (message) {
            await this.sendMessage('system_police_bot', conversationId, message, null, null, false);
        }
    },

    // --- System Notifications ---
    async sendRegistrationApprovalRequest(newUser: User, proMaxUsers: User[]): Promise<void> {
        ensureInitialized();
        const message = `Új felhasználó (${newUser.name}) regisztrált. Kérlek hagyd jóvá vagy utasítsd el a kérelmét a Kollégák menüpontban.`;
        const systemId = 'system_police_bot';
        for (const proMaxUser of proMaxUsers) {
            const convoId = await this.findOrCreateConversation(systemId, proMaxUser.id);
            await this.sendMessage(systemId, convoId, message, null, null, true);
        }
    },

    async sendLatenessNotification(targetUserId: string, assignerName: string, type: 'warning' | 'strike', strikeCount?: number): Promise<void> {
        ensureInitialized();
        const policeBotId = 'system_police_bot';
        let message = '';
        if (type === 'warning') {
            message = `Figyelmeztetés! ${assignerName} jelezte, hogy ma késtél. A sorozatos késések strigulához vezethetnek.`;
        } else {
            message = `Strigula! ${assignerName} strigulát adott neked késés miatt. Jelenlegi striguláid száma: ${strikeCount}. Minden strigula 100 korona levonással jár.`;
        }
        const convoId = await this.findOrCreateConversation(policeBotId, targetUserId);
        await this.sendMessage(policeBotId, convoId, message, null, null, false);
    },

     async sendStrikeRemovalNotification(targetUserId: string, removerName: string, newStrikeCount: number): Promise<void> {
        ensureInitialized();
        const policeBotId = 'system_police_bot';
        const message = `Jó hír! ${removerName} eltávolított egy strigulát tőled. A jelenlegi striguláid száma: ${newStrikeCount}.`;
        const convoId = await this.findOrCreateConversation(policeBotId, targetUserId);
        await this.sendMessage(policeBotId, convoId, message, null, null, false);
    },
    
    async sendNewScheduleNotification(userIds: string[], uploaderName: string, weekId: string): Promise<void> {
        ensureInitialized();
        const message = `${uploaderName} feltöltötte a(z) ${weekId}. heti beosztást!`;
        const systemId = 'system_police_bot';
        for (const userId of userIds) {
            const convoId = await this.findOrCreateConversation(systemId, userId);
            await this.sendMessage(systemId, convoId, message, null, null, false);
        }
    },

    async sendScheduleUpdateNotification(userId: string, uploaderName: string, weekId: string): Promise<void> {
        ensureInitialized();
        const message = `${uploaderName} módosította a(z) ${weekId}. heti beosztásodat!`;
        const systemId = 'system_police_bot';
        const convoId = await this.findOrCreateConversation(systemId, userId);
        await this.sendMessage(systemId, convoId, message, null, null, false);
    },

    async sendProMaxScheduleUpdateNotification(updaterName: string, weekId: string): Promise<void> {
        ensureInitialized();
        const proMaxUsers = authService.getAllUsers().filter(u => u.status === 'pro_max' && u.name !== updaterName);
        const message = `${updaterName} módosította a Pro Max beosztást a(z) ${weekId}. héten.`;
        const systemId = 'system_police_bot';
        for (const proMaxUser of proMaxUsers) {
             const convoId = await this.findOrCreateConversation(systemId, proMaxUser.id);
             await this.sendMessage(systemId, convoId, message, null, null, false);
        }
    },
    
    async sendLatenessReport(reporter: User, minutes: number, reason: string, day: string, date: string): Promise<void> {
        ensureInitialized();
        const proMaxUsers = authService.getAllUsers().filter(u => u.status === 'pro_max');
        const message = `KÉSÉS JELENTÉS\n\n- Ki: ${reporter.name}\n- Nap: ${day} (${date})\n- Várható késés: ${minutes} perc\n- Indoklás: ${reason || 'Nincs megadva'}`;
        const policeBotId = 'system_police_bot';
        for (const proMaxUser of proMaxUsers) {
            const convoId = await this.findOrCreateConversation(policeBotId, proMaxUser.id);
            await this.sendMessage(policeBotId, convoId, message, null, null, true);
        }
    },
    
    async sendModificationRequest(requester: User, reason: string, day: string, date: string): Promise<void> {
        ensureInitialized();
        const proMaxUsers = authService.getAllUsers().filter(u => u.status === 'pro_max');
        const message = `BEOSZTÁS MÓDOSÍTÁSI KÉRELEM\n\n- Ki: ${requester.name}\n- Nap: ${day} (${date})\n- Indoklás: ${reason}`;
        const policeBotId = 'system_police_bot';
        for (const proMaxUser of proMaxUsers) {
            const convoId = await this.findOrCreateConversation(policeBotId, proMaxUser.id);
            await this.sendMessage(policeBotId, convoId, message, null, null, true);
        }
    },
    
    async sendBroadcastMessage(sender: User, message: string, targetGroups: ('normal' | 'pro' | 'pro_max')[]): Promise<void> {
        ensureInitialized();
        const allUsers = authService.getAllUsers();
        const targetUsers = allUsers.filter(u => u.status !== 'admin' && targetGroups.includes(u.status || 'normal') && u.id !== sender.id);
        const systemId = 'system_police_bot';
        
        for (const targetUser of targetUsers) {
            const convoId = await this.findOrCreateConversation(systemId, targetUser.id);
            await this.sendMessage(systemId, convoId, message, null, null, false);
        }
    },
    
    async sendAwardsNotification(publisherName: string, month: string): Promise<void> {
        ensureInitialized();
        const allUsers = authService.getAllUsers();
        const systemId = 'system_police_bot';
        const message = `${publisherName} közzétette a(z) ${month} havi díjazottak listáját! Nézd meg a Díjazottak menüpontban!`;
        for (const user of allUsers) {
            const convoId = await this.findOrCreateConversation(systemId, user.id);
            await this.sendMessage(systemId, convoId, message, null, null, false);
        }
    },

    async sendNominationNotification(userId: string, category: string): Promise<void> {
        ensureInitialized();
        const systemId = 'system_police_bot';
        const message = `Gratulálunk! Jelölve lettél a(z) ${category} díjra. A végeredményt hamarosan közzé tesszük!`;
        const convoId = await this.findOrCreateConversation(systemId, userId);
        await this.sendMessage(systemId, convoId, message, null, null, false);
    },

     async sendCrownRequestNotification(userId: string, amount: number): Promise<void> {
        ensureInitialized();
        const user = authService.getUserById(userId);
        if (!user) return;
        const systemId = 'system_police_bot';
        const message = `${user.name} jóváírt magának ${amount.toLocaleString('hu-HU')} koronát.`;
        const proMaxUsers = authService.getAllUsers().filter(u => u.status === 'pro_max' && u.id !== userId);
        for (const proMaxUser of proMaxUsers) {
            const convoId = await this.findOrCreateConversation(systemId, proMaxUser.id);
            await this.sendMessage(systemId, convoId, message, null, null, true);
        }
    },
    
    async sendCrownTransferNotification(recipientId: string, senderName: string, amount: number, reason: string): Promise<void> {
        ensureInitialized();
        const systemId = 'system_police_bot';
        const message = `Jó hír! ${senderName} küldött neked ${amount.toLocaleString('hu-HU')} koronát.\nIndoklás: "${reason}"`;
        const convoId = await this.findOrCreateConversation(systemId, recipientId);
        await this.sendMessage(systemId, convoId, message, null, null, false);
    },
    
    // --- Chat Management ---
    async addUserToGroupChat(userId: string): Promise<void> {
        ensureInitialized();
        let conversations = getStoredConversations();
        const groupChat = conversations.find(c => c.id === GROUP_CHAT_CONVO_ID);
        if (groupChat && !groupChat.participantIds.includes(userId)) {
            groupChat.participantIds.push(userId);
            storeConversations(conversations);
        }
    },
    
    async updateUserChatAccess(user: User): Promise<void> {
        ensureInitialized();
        let conversations = getStoredConversations();

        const chatsToUpdate: { id: string; requiredStatus: (User['status'])[] }[] = [
            { id: PRO_CHAT_CONVO_ID, requiredStatus: ['pro'] },
            { id: PRO_MAX_CHAT_CONVO_ID, requiredStatus: ['pro_max'] },
            { id: ULTRA_CHAT_CONVO_ID, requiredStatus: ['pro', 'pro_max'] },
        ];

        chatsToUpdate.forEach(chatInfo => {
            const chat = conversations.find(c => c.id === chatInfo.id);
            if (chat) {
                const userStatus = user.status || 'normal';
                const hasAccess = chatInfo.requiredStatus.includes(userStatus);
                const isParticipant = chat.participantIds.includes(user.id);

                if (hasAccess && !isParticipant) {
                    // Add user to chat
                    chat.participantIds.push(user.id);
                } else if (!hasAccess && isParticipant) {
                    // Remove user from chat
                    chat.participantIds = chat.participantIds.filter(id => id !== user.id);
                }
            }
        });
        
        storeConversations(conversations);
    },

    async removeUserFromSystemChats(userId: string): Promise<void> {
        ensureInitialized();
        let conversations = getStoredConversations();
        conversations.forEach(convo => {
            if (convo.isSystemConversation) {
                convo.participantIds = convo.participantIds.filter(id => id !== userId);
            }
        });
        storeConversations(conversations);
    },
    
    async addUsersToGroup(conversationId: string, userIdsToAdd: string[], actor: User): Promise<void> {
        ensureInitialized();
        await new Promise(res => setTimeout(res, 300));
        const conversations = getStoredConversations();
        const convo = conversations.find(c => c.id === conversationId);
        
        if (convo) {
            const usersAddedNames: string[] = [];
            userIdsToAdd.forEach(userId => {
                if (!convo.participantIds.includes(userId)) {
                    convo.participantIds.push(userId);
                    const user = authService.getUserById(userId);
                    if (user) {
                        usersAddedNames.push(user.name);
                    }
                }
            });

            if (usersAddedNames.length > 0) {
                storeConversations(conversations);
                const message = `${actor.name} hozzáadta a csoporthoz: ${usersAddedNames.join(', ')}.`;
                await this.sendMessage('system_police_bot', conversationId, message, null, null, false);
            }
        }
    },

    async removeUserFromGroup(conversationId: string, userIdToRemove: string, actor: User): Promise<void> {
        ensureInitialized();
        await new Promise(res => setTimeout(res, 300));
        const conversations = getStoredConversations();
        const convo = conversations.find(c => c.id === conversationId);

        if (convo) {
            const userToRemove = authService.getUserById(userIdToRemove);
            convo.participantIds = convo.participantIds.filter(id => id !== userIdToRemove);
            storeConversations(conversations);
            if (userToRemove) {
                 const message = `${actor.name} eltávolította a csoportból: ${userToRemove.name}.`;
                 await this.sendMessage('system_police_bot', conversationId, message, null, null, false);
            }
        }
    },
    
     async toggleMessageReaction(messageId: string, reaction: string, userId: string): Promise<Message> {
        ensureInitialized();
        await new Promise(res => setTimeout(res, 50));
        
        const allMessages = getStoredMessages();
        const msgIndex = allMessages.findIndex(m => m.id === messageId);
        if (msgIndex === -1) throw new Error("Üzenet nem található.");

        const msg = allMessages[msgIndex];
        msg.reactions = msg.reactions || {};

        let userPreviousReaction: string | null = null;
        for (const key in msg.reactions) {
            if (msg.reactions[key].includes(userId)) {
                userPreviousReaction = key;
                break;
            }
        }

        if (userPreviousReaction) {
            msg.reactions[userPreviousReaction] = msg.reactions[userPreviousReaction].filter(id => id !== userId);
            if (msg.reactions[userPreviousReaction].length === 0) {
                delete msg.reactions[userPreviousReaction];
            }
        }

        if (userPreviousReaction !== reaction) {
            if (!msg.reactions[reaction]) msg.reactions[reaction] = [];
            msg.reactions[reaction].push(userId);
        }

        storeMessages(allMessages);
        return msg;
    },

    async muteConversation(conversationId: string, muteUntil: number): Promise<void> {
        ensureInitialized();
        await new Promise(res => setTimeout(res, 100));
        const muted = getMutedConversations();
        muted[conversationId] = muteUntil;
        storeMutedConversations(muted);
    },
};
