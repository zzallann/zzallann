import type { KpiData } from '../types';

const KPI_KEY = 'astoria_kpis';

const getStoredKpis = (): KpiData => {
    const kpisJson = localStorage.getItem(KPI_KEY);
    const defaults: KpiData = {
        nps: '90',
        time: '2:30',
        npsTarget: '92',
        timeTarget: '2:15',
        dailyMenu: 'Whopper',
        customLabel1: 'SOE',
        customValue1: '95',
        customUnit1: '%',
        customLabel2: 'SOECÉL',
        customValue2: '96',
        customUnit2: '%',
        npsLabel: 'NPS',
        timeLabel: 'KISZIDŐ',
        npsTargetLabel: 'NPS Cél',
        timeTargetLabel: 'KISZCÉL',
        dailyMenuLabel: 'Napimenü',
    };
    return kpisJson ? { ...defaults, ...JSON.parse(kpisJson) } : defaults;
};

const storeKpis = (kpis: KpiData) => {
    localStorage.setItem(KPI_KEY, JSON.stringify(kpis));
};

export const kpiService = {
    async getKpis(): Promise<KpiData> {
        await new Promise(res => setTimeout(res, 100));
        return getStoredKpis();
    },

    async updateKpis(updatedKpis: Partial<KpiData>): Promise<KpiData> {
        await new Promise(res => setTimeout(res, 300));
        const currentKpis = getStoredKpis();
        const newKpis = { ...currentKpis, ...updatedKpis };
        storeKpis(newKpis);
        return newKpis;
    },
};