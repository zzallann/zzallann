// =============================================================================
// MOCK BACKEND SIMULATION FOR A GLOBAL SETTING
// =============================================================================
// This service manages a single global setting: the work time request deadline.
// In a real application, this would be stored in a database settings table.
// =============================================================================

const DEADLINE_KEY = 'astoria_work_time_deadline';

export const deadlineService = {
    async setDeadline(deadlineTimestamp: number): Promise<void> {
        await new Promise(res => setTimeout(res, 300));
        localStorage.setItem(DEADLINE_KEY, String(deadlineTimestamp));
    },

    async getDeadline(): Promise<number | null> {
        await new Promise(res => setTimeout(res, 100));
        const deadlineStr = localStorage.getItem(DEADLINE_KEY);
        return deadlineStr ? parseInt(deadlineStr, 10) : null;
    }
};
