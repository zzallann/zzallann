import type { User } from '../types';
import { messageService } from './messageService';

// =============================================================================
// IMPORTANT: MOCK BACKEND SIMULATION
// =============================================================================
// This service simulates user authentication and storage using the browser's
// localStorage. It is intended for demonstration purposes only. In a real
// application, these functions would make API calls to a secure backend server
// that handles user data, password hashing, and session management.
// =============================================================================

const USERS_KEY = 'astoria_users';
const CURRENT_USER_KEY = 'astoria_current_user';
const PASSWORDS_KEY = 'astoria_passwords';

const getStoredUsers = (): User[] => {
    const usersJson = localStorage.getItem(USERS_KEY);
    // FIX: Add type assertion to JSON.parse to ensure the correct type is returned.
    return usersJson ? JSON.parse(usersJson) as User[] : [];
};

const storeUsers = (users: User[]) => {
    localStorage.setItem(USERS_KEY, JSON.stringify(users));
};

const getPasswords = (): Record<string, string> => {
    const passwordsJson = localStorage.getItem(PASSWORDS_KEY);
    // FIX: Add type assertion to JSON.parse to ensure the correct type is returned.
    return passwordsJson ? JSON.parse(passwordsJson) as Record<string, string> : {};
};

const storePasswords = (passwords: Record<string, string>) => {
    localStorage.setItem(PASSWORDS_KEY, JSON.stringify(passwords));
};

// Definition for special, non-stored system users
const systemUsers: Record<string, Omit<User, 'pointsHistory' | 'reactedPostsForPoints' | 'reactedMessagesForPoints' | 'commentedPostsForPoints' | 'reactedCommentsForPoints'>> = {
  'system_police_bot': {
    id: 'system_police_bot',
    identifier: 'system_police_bot',
    name: 'Rendszer Felügyelő',
    fullName: 'Rendszer Felügyelő Bot',
    avatarId: 'police-bear',
    uploadedImage: null,
    points: Infinity,
    registrationDate: 0,
    status: 'pro_max',
    lastSeen: Date.now(),
    strikes: 0,
    approved: true,
  }
};


// Helper to convert a File to a base64 string
const fileToBase64 = (file: File): Promise<string> => {
    return new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.readAsDataURL(file);
        reader.onload = () => resolve(reader.result as string);
        reader.onerror = error => reject(error);
    });
};

// Create a default admin user if none exist, for demo purposes
const initializeDefaultUsers = () => {
    let users = getStoredUsers();
    if (users.length === 0) {
        const registrationTime = Date.now();

        const adminUser: User = {
            id: 'user_admin_0',
            identifier: '19980612',
            name: 'Admin',
            fullName: 'Rendszer Adminisztrátor',
            avatarId: 'burglar',
            uploadedImage: null,
            points: 53000,
            registrationDate: registrationTime,
            reactedPostsForPoints: [],
            reactedMessagesForPoints: [],
            commentedPostsForPoints: [],
            reactedCommentsForPoints: [],
            pointsHistory: [],
            status: 'admin',
            lastSeen: Date.now(),
            strikes: 0,
            approved: true,
        };
        
        const fanncsUser: User = {
            id: 'user_fanncs_1',
            identifier: '01',
            name: 'Fanncs',
            fullName: 'Farkas Fanni',
            avatarId: 'dog',
            uploadedImage: null,
            points: 1000,
            registrationDate: registrationTime,
            reactedPostsForPoints: [],
            reactedMessagesForPoints: [],
            commentedPostsForPoints: [],
            reactedCommentsForPoints: [],
            pointsHistory: [{ reason: 'Regisztráció', points: 1000, date: registrationTime }],
            status: 'pro_max',
            lastSeen: Date.now() - 1000 * 60 * 5, // 5 minutes ago
            strikes: 0,
            approved: true,
        };

        const mateUser: User = {
            id: 'user_mate_1',
            identifier: '02',
            name: 'Máté',
            fullName: 'Nagy Máté',
            avatarId: 'ufo',
            uploadedImage: null,
            points: 1100,
            registrationDate: registrationTime,
            reactedPostsForPoints: [],
            reactedMessagesForPoints: [],
            commentedPostsForPoints: [],
            reactedCommentsForPoints: [],
            pointsHistory: [{ reason: 'Regisztráció', points: 1100, date: registrationTime }],
            status: 'pro',
            lastSeen: Date.now() - 1000 * 60 * 30, // 30 minutes ago
            strikes: 1,
            approved: true,
        };

        const ediUser: User = {
            id: 'user_edi_1',
            identifier: '03',
            name: 'Edi',
            fullName: 'Nagy Edina',
            avatarId: 'pig',
            uploadedImage: null,
            points: 700,
            registrationDate: registrationTime,
            reactedPostsForPoints: [],
            reactedMessagesForPoints: [],
            commentedPostsForPoints: [],
            reactedCommentsForPoints: [],
            pointsHistory: [{ reason: 'Regisztráció', points: 700, date: registrationTime }],
            status: 'normal',
            lastSeen: Date.now() - 1000 * 60 * 60 * 2, // 2 hours ago
            strikes: 2,
            approved: true,
        };

        const bencusUser: User = {
            id: 'user_bencus_1',
            identifier: '04',
            name: 'Bencus',
            fullName: 'Bencsik Dávid',
            avatarId: 'journalist',
            uploadedImage: null,
            points: 1200,
            registrationDate: registrationTime,
            reactedPostsForPoints: [],
            reactedMessagesForPoints: [],
            commentedPostsForPoints: [],
            reactedCommentsForPoints: [],
            pointsHistory: [{ reason: 'Regisztráció', points: 1200, date: registrationTime }],
            status: 'pro',
            lastSeen: Date.now() - 1000 * 60 * 10, // 10 minutes ago
            strikes: 0,
            approved: true,
        };
        
        const zazaUser: User = {
            id: 'user_zaza_1',
            identifier: '05',
            name: 'Zaza',
            fullName: 'Zajzon Zoltán',
            avatarId: 'dwarf',
            uploadedImage: null,
            points: 1000,
            registrationDate: registrationTime,
            reactedPostsForPoints: [],
            reactedMessagesForPoints: [],
            commentedPostsForPoints: [],
            reactedCommentsForPoints: [],
            pointsHistory: [{ reason: 'Regisztráció', points: 1000, date: registrationTime }],
            status: 'pro',
            lastSeen: Date.now(),
            strikes: 0,
            approved: true,
        };
        
        const bambiUser: User = {
            id: 'user_bambi_1',
            identifier: '06',
            name: 'Bambi',
            fullName: 'Balogh Tamás',
            avatarId: 'rabbit',
            uploadedImage: null,
            points: 850,
            registrationDate: registrationTime,
            reactedPostsForPoints: [],
            reactedMessagesForPoints: [],
            commentedPostsForPoints: [],
            reactedCommentsForPoints: [],
            pointsHistory: [{ reason: 'Regisztráció', points: 850, date: registrationTime }],
            status: 'normal',
            lastSeen: Date.now() - 1000 * 60 * 60 * 24, // 1 day ago
            strikes: 0,
            approved: false,
        };

        users.push(adminUser, fanncsUser, mateUser, ediUser, bencusUser, zazaUser, bambiUser);
        storeUsers(users);
        
        const passwords = {
            [adminUser.id]: '19980612',
            [fanncsUser.id]: '123456',
            [mateUser.id]: '123456',
            [ediUser.id]: '123456',
            [bencusUser.id]: '123456',
            [zazaUser.id]: '123456',
            [bambiUser.id]: '123456'
        };
        storePasswords(passwords);
    }
};

// Initialize default users on service load
initializeDefaultUsers();


export const authService = {
  async login(identifier: string, password: string): Promise<User> {
    // Simulate network delay
    await new Promise(res => setTimeout(res, 500));
    
    const users = getStoredUsers();
    const passwords = getPasswords();

    const user = users.find(u => u.identifier === identifier);
    if (!user) {
      throw new Error('Hibás azonosító vagy jelszó.');
    }
    
    const storedPassword = passwords[user.id];
    if (storedPassword !== password) {
      throw new Error('Hibás azonosító vagy jelszó.');
    }
    
    if (!user.approved) {
        throw new Error('A fiókod még jóváhagyásra vár.');
    }

    user.lastSeen = Date.now();
    storeUsers(users);

    localStorage.setItem(CURRENT_USER_KEY, JSON.stringify(user));
    return user;
  },

  async register(identifier: string, name: string, fullName: string, password: string, avatarId: string): Promise<User> {
    await new Promise(res => setTimeout(res, 700));

    const users = getStoredUsers();
    const passwords = getPasswords();

    if (users.some(u => u.identifier === identifier)) {
      throw new Error('Ezzel az azonosítóval már létezik felhasználó.');
    }
    if (users.some(u => u.name.toLowerCase() === name.toLowerCase())) {
      throw new Error('Ez a felhasználónév már foglalt.');
    }

    const newUser: User = {
      id: `user_${Date.now()}`,
      identifier,
      name,
      fullName,
      avatarId,
      uploadedImage: null,
      points: 1000,
      registrationDate: Date.now(),
      reactedPostsForPoints: [],
      reactedMessagesForPoints: [],
      commentedPostsForPoints: [],
      reactedCommentsForPoints: [],
      pointsHistory: [{ reason: 'Regisztráció', points: 1000, date: Date.now() }],
      status: 'normal',
      lastSeen: Date.now(),
      strikes: 0,
      approved: false, // Default to not approved
    };

    users.push(newUser);
    passwords[newUser.id] = password;

    storeUsers(users);
    storePasswords(passwords);
    
    const proMaxUsers = users.filter(u => u.status === 'pro_max' && u.approved);
    await messageService.sendRegistrationApprovalRequest(newUser, proMaxUsers);

    return newUser;
  },

  logout(): void {
    localStorage.removeItem(CURRENT_USER_KEY);
  },

  getCurrentUser(): User | null {
    const userJson = localStorage.getItem(CURRENT_USER_KEY);
    if (!userJson) return null;
    
    const loggedInUser: User = JSON.parse(userJson);
    
    // Refresh user data from "DB" to get latest points, status, etc.
    const users = getStoredUsers();
    const freshUserData = users.find(u => u.id === loggedInUser.id);
    
    if (freshUserData) {
        freshUserData.lastSeen = Date.now();
        storeUsers(users);
        localStorage.setItem(CURRENT_USER_KEY, JSON.stringify(freshUserData));
        return freshUserData;
    }
    
    // If user not found in DB (e.g., deleted), log them out
    this.logout();
    return null;
  },

  getAllUsers(): User[] {
    return getStoredUsers();
  },
  
  getUserById(userId: string): User | null {
    if (systemUsers[userId]) {
      const systemUser = systemUsers[userId];
      return {
        ...systemUser,
        pointsHistory: [],
        reactedPostsForPoints: [],
        reactedMessagesForPoints: [],
        commentedPostsForPoints: [],
        reactedCommentsForPoints: [],
      };
    }
    return getStoredUsers().find(u => u.id === userId) || null;
  },
  
  updateUser(updatedUser: User) {
      const users = getStoredUsers();
      const userIndex = users.findIndex(u => u.id === updatedUser.id);
      if (userIndex > -1) {
          users[userIndex] = updatedUser;
          storeUsers(users);
          
          // Also update current user if they are the one being updated
          const currentUserJson = localStorage.getItem(CURRENT_USER_KEY);
          if (currentUserJson) {
              const currentUser = JSON.parse(currentUserJson);
              if (currentUser.id === updatedUser.id) {
                   localStorage.setItem(CURRENT_USER_KEY, JSON.stringify(updatedUser));
              }
          }
      }
  },

  async isNameTaken(name: string): Promise<boolean> {
      await new Promise(res => setTimeout(res, 200));
      const users = getStoredUsers();
      return users.some(u => u.name.toLowerCase() === name.toLowerCase());
  },
  
  async changePassword(userId: string, currentPass: string, newPass: string): Promise<void> {
    await new Promise(res => setTimeout(res, 500));
    const passwords = getPasswords();
    if (passwords[userId] !== currentPass) {
        throw new Error('A jelenlegi jelszó hibás.');
    }
    passwords[userId] = newPass;
    storePasswords(passwords);
  },
  
  async adminResetPassword(userId: string, newPass: string): Promise<void> {
      await new Promise(res => setTimeout(res, 500));
      const passwords = getPasswords();
      if (!passwords[userId]) {
          throw new Error('A felhasználó nem található.');
      }
      passwords[userId] = newPass;
      storePasswords(passwords);
  },

  async approveUser(userId: string): Promise<void> {
    await new Promise(res => setTimeout(res, 300));
    const users = getStoredUsers();
    const user = users.find(u => u.id === userId);
    if (user) {
        user.approved = true;
        storeUsers(users);
        await messageService.addUserToGroupChat(userId);
    } else {
        throw new Error("Felhasználó nem található.");
    }
  },

  async rejectUser(userId: string): Promise<void> {
      await new Promise(res => setTimeout(res, 300));
      let users = getStoredUsers();
      let passwords = getPasswords();
      
      users = users.filter(u => u.id !== userId);
      delete passwords[userId];

      storeUsers(users);
      storePasswords(passwords);
  },

  async removeStrike(userId: string): Promise<User> {
    await new Promise(res => setTimeout(res, 300));
    const users = getStoredUsers();
    const userIndex = users.findIndex(u => u.id === userId);
    if (userIndex > -1) {
        const user = users[userIndex];
        if (user.strikes > 0) {
            user.strikes -= 1;
            users[userIndex] = user;
            storeUsers(users);
            return user;
        }
    }
    throw new Error("A felhasználónak nincs strigulája.");
  },
  
  async uploadProfileImage(userId: string, imageFile: File): Promise<User> {
      await new Promise(res => setTimeout(res, 1000));
      const base64Image = await fileToBase64(imageFile);
      
      const users = getStoredUsers();
      const userIndex = users.findIndex(u => u.id === userId);
      if (userIndex === -1) {
          throw new Error("User not found");
      }
      
      users[userIndex].uploadedImage = base64Image;
      users[userIndex].avatarId = null; // Custom image overrides avatar
      storeUsers(users);
      
      const updatedUser = users[userIndex];
       // Also update current user in localStorage if they are the one being updated
      const currentUserJson = localStorage.getItem(CURRENT_USER_KEY);
      if (currentUserJson) {
          const currentUser = JSON.parse(currentUserJson);
          if (currentUser.id === updatedUser.id) {
               localStorage.setItem(CURRENT_USER_KEY, JSON.stringify(updatedUser));
          }
      }
      
      return updatedUser;
  },

  async transferCrowns(senderId: string, recipientId: string, amount: number, reason: string): Promise<{sender: User, recipient: User}> {
      await new Promise(res => setTimeout(res, 500));
      const users = getStoredUsers();
      const senderIndex = users.findIndex(u => u.id === senderId);
      const recipientIndex = users.findIndex(u => u.id === recipientId);

      if (senderIndex === -1 || recipientIndex === -1) {
          throw new Error("Felhasználó nem található.");
      }

      const sender = users[senderIndex];
      const recipient = users[recipientIndex];

      if (sender.points < amount) {
          throw new Error("Nincs elég koronád az utaláshoz.");
      }

      sender.points -= amount;
      sender.pointsHistory.unshift({ reason: `Küldés neki: ${recipient.name} (${reason})`, points: -amount, date: Date.now() });

      recipient.points += amount;
      recipient.pointsHistory.unshift({ reason: `Fogadás tőle: ${sender.name} (${reason})`, points: amount, date: Date.now() });

      storeUsers(users);
      return { sender, recipient };
  },

  async deleteUser(userId: string): Promise<void> {
      await new Promise(res => setTimeout(res, 500));
      let users = getStoredUsers();
      let passwords = getPasswords();
      
      const userToDelete = users.find(u => u.id === userId);
      if (!userToDelete) {
          throw new Error("A felhasználó nem található.");
      }
      
      users = users.filter(u => u.id !== userId);
      delete passwords[userId];
      
      storeUsers(users);
      storePasswords(passwords);
      
      // Remove user from system chats
      await messageService.removeUserFromSystemChats(userId);
  }

};