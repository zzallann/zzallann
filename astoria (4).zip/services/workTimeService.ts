import type { User, WorkTimeRequest } from '../types';

const REQUESTS_KEY = 'astoria_work_time_requests';

const getStoredRequests = (): WorkTimeRequest[] => {
    const requestsJson = localStorage.getItem(REQUESTS_KEY);
    return requestsJson ? JSON.parse(requestsJson) : [];
};

const storeRequests = (requests: WorkTimeRequest[]) => {
    localStorage.setItem(REQUESTS_KEY, JSON.stringify(requests));
};

// Helper to get Monday of the week a date is in
const getWeekStart = (date: Date): Date => {
    const d = new Date(date);
    d.setHours(0, 0, 0, 0);
    const day = d.getDay();
    const diff = d.getDate() - day + (day === 0 ? -6 : 1); // adjust when day is sunday
    return new Date(d.setDate(diff));
};

// Helper to determine the start of the next week (Monday)
const getNextWeekStart = (): Date => {
    const today = new Date();
    const currentWeekStart = getWeekStart(today);
    currentWeekStart.setDate(currentWeekStart.getDate() + 7);
    return currentWeekStart;
}

const isRequestForWeek = (req: WorkTimeRequest, weekStartDate: Date): boolean => {
    const weekEndDate = new Date(weekStartDate);
    weekEndDate.setDate(weekStartDate.getDate() + 6);
    weekEndDate.setHours(23, 59, 59, 999);

    if (req.days.length > 0) {
        const firstDayOfRequest = new Date(req.days[0].date);
        return firstDayOfRequest >= weekStartDate && firstDayOfRequest <= weekEndDate;
    }
    
    if (req.message && req.days.length === 0) {
        const submissionWeekStart = getWeekStart(new Date(req.submittedAt));
        const nextWeekFromSubmission = new Date(submissionWeekStart);
        nextWeekFromSubmission.setDate(submissionWeekStart.getDate() + 7);
        return weekStartDate.getTime() === nextWeekFromSubmission.getTime();
    }
    return false;
};


export const workTimeService = {
    async submitRequest(
        user: User,
        selectedDays: { date: Date; type: 'munkanap' | 'szabadság'; from: string; to: string; isFlex: boolean }[],
        message: string | null
    ): Promise<void> {
        await new Promise(res => setTimeout(res, 500));
        
        const allRequests = getStoredRequests();
        const nextMonday = getNextWeekStart();

        const filteredRequests = allRequests.filter(req => {
            if (req.userId !== user.id) return true;
            return !isRequestForWeek(req, nextMonday);
        });

        const newRequest: WorkTimeRequest = {
            id: `req_${user.id}_${Date.now()}`,
            userId: user.id,
            userName: user.name,
            userAvatarId: user.avatarId,
            userUploadedImage: user.uploadedImage,
            days: selectedDays.map(d => ({...d, date: d.date.toISOString()})),
            submittedAt: Date.now(),
            message,
        };

        filteredRequests.push(newRequest);
        storeRequests(filteredRequests);
    },

    async getNextWeeksRequests(): Promise<WorkTimeRequest[]> {
        await new Promise(res => setTimeout(res, 300));
        const requests = getStoredRequests();
        const nextMonday = getNextWeekStart();

        return requests.filter(req => isRequestForWeek(req, nextMonday))
            .sort((a, b) => a.userName.localeCompare(b.userName));
    },

    async getRequestsForWeek(date: Date): Promise<WorkTimeRequest[]> {
        await new Promise(res => setTimeout(res, 300));
        const requests = getStoredRequests();
        const weekStart = getWeekStart(date);
        
        return requests.filter(req => isRequestForWeek(req, weekStart))
            .sort((a, b) => a.userName.localeCompare(b.userName));
    },

    async getNextWeekRequestForUser(userId: string): Promise<WorkTimeRequest | null> {
        await new Promise(res => setTimeout(res, 200));
        const requests = getStoredRequests();
        const nextMonday = getNextWeekStart();

        return requests.find(req => {
            if (req.userId !== userId) return false;
            return isRequestForWeek(req, nextMonday);
        }) || null;
    },
};