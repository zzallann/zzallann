import type { User, WasteLog, WasteMenuItem } from '../types';

const WASTE_LOGS_KEY = 'astoria_waste_logs';
const WASTE_MENU_KEY = 'astoria_waste_menu';

// --- MENU MANAGEMENT ---

const initialWasteMenuData: Record<string, string[]> = {
  'Húsok': [ 'BACON SUTOTT HUTOTT', 'CSIRKE CRISPY', 'CSIRKE ROYALE (LONG CHICKEN)', 'CSIRKEMELL DELUX', 'HUSPOGACSA 4.0 WHOPPER', 'HÚSPOGÁCSA BURGER', 'REBEL WHOPPER',],
  'Szószok': [ 'EPER SZOSZ', 'KETCHUP', 'MAJONÉZ', 'MUSTÁR', 'SZÓSZ BACON MAJONÉZ', 'SZOSZ BKOOL CSOKI FAGYOS', 'SZOSZ CHILI CHEESE', 'SZÓSZ MÁLNÁS SAJT', 'SZÓSZ PISZTÁCIÁS', 'SZÓSZ SÓSKARAMELL FAGYOS', 'SZÓSZ WESTERN BBQ',],
  'Tálkás szószok és öntetek': [ 'JUHARSZIRUP ÖNTET', 'MEZ TASAKOS', 'ONTET CEZAR', 'ONTET JOGHURT', 'ÖNTET BALZSAMECETES', 'SZOSZ BBQ TALKAS', 'SZOSZ CHILI CHEESE TALKAS', 'SZOSZ CURRY MANGO TALKAS', 'SZOSZ EDES SAVANYU TALKAS', 'SZOSZ SALSA TALKAS', 'KETCHUP TÁLKÁS', 'MAJONEZ TALKAS', 'TÁLKÁS SAJTSZÓSZ',],
  'Zöldségek': [ 'BURGONYA EDES', 'BURGONYA HASAB', 'HAGYMA DARABOK', 'JALAPENO PAPRIKA ZOLD', 'JEGSALATA DIREKT', 'KIGYOUBORKA', 'PARADICSOM', 'PARADICSOM KOKTEL', 'SALATAMIX DIREKT', 'UBORKA SZELETELT', 'VOROSHAGYMA EGESZ DIREKT', 'VOROSHAGYMA EGESZ RAKI',],
  'Zsemlék, tortilla': [ 'TORTILLA', 'ZSEMLE BURGER DIREKT 4"', 'ZSEMLE GLUTÉNMENTES', 'ZSEMLE LONG FAGYASZTOTT', 'ZSEMLE SHINY LENGYEL', 'ZSEMLE WHOPPER DIREKT 5"',],
  'Üdítők, egyéb folyadékok és alapanyagjaik': [ 'ALMALÉ HAPPY DAY 1L', 'COLA 0,33', 'COLA ZERO 0,33', 'FAGYLALT 10KG', 'FANTA 0,33', 'FUZETEA CITROM', 'FUZETEA ZÖLD', 'HAPPY DAY NARANCS 0,2L', 'KAVE LAVAZZA', 'KÁVÉTEJSZÍN RIOBA', 'MONSTER', 'MULTIVITAMIN HAPPY DAY 100% 0,2L', 'NATURAQUA MENTES', 'NATURAQUA SAVAS', 'RED BULL', 'SAN BENEDETTO MENTES', 'SIÓ ALMA 0,2L', 'SPRITE 0,33', 'TEA LIPTON', 'TEJ UHT 12L',],
  'Szendvicsek': [ 'BACON KING', 'BACON TOAST', 'BACON TOJÁSOS SZENDVICS', 'CHICKEN BACON KING', 'CHICKEN CHILI CH LOVER', 'CHICKEN ROYALE', 'CHICKEN VALMAR KING', 'CHILI CHEESE BACON KING', 'CHILI CHEESE BURGER', 'CHILI CHEESE CRISPY CHICKEN', 'CHILI CHEESE LOVER', 'CRISPY CHICKEN', 'DUPLA CHILI CHEESE BURGER', 'DUPLA SAJTBURGER', 'DUPLA WHOPPER', 'GLUTÉNMENTES WHOPPER', 'HAMBURGER', 'JUNIOR WHOPPER', 'KING DLX CSIRKE', 'NUGGETS BURGER', 'PLANTB WHOPPER', 'SAJTBURGER', 'SAJTOS TOAST', 'VALMAR KING', 'WESTERN JUNIOR', 'WESTERN WHOPPER', 'WHOPPER', 'WHOPPER JUNIOR SAJT', 'WHOPPER SAJT', 'WHOPPER SAJT BACON', 'WRAP DELUX', 'WRAP SMOKY',],
  'Snackek': [ 'BURGONYA HASÁB', 'ÉDESBURGONYA', 'GOUDA SAJT', 'HAGYMAKARIKA', 'KOSÁR 22 DUPLA', 'KOSÁR DUO', 'KOSÁR GIGA', 'KOSÁR SOLO', 'KOSÁR SPICY SOLO', 'NUGGETS', 'NUGGETS CHILI CHEESE', 'NUGGETS SPICY',],
  'Desszertek': [ 'BROWNIE SAJTTOTA', 'FAGYLALT CSOKI', 'FAGYLALT EPER', 'FAGYLALT SÓSKARAMELL', 'FAGYLALT TÖLCSÉRES ROLETTIVEL', 'FAGYLALT VANÍLIA', 'KING FUSION EPER', 'KING FUSION OREO', 'KING FUSION PISTACHIO', 'SHAKE KÁVÉ', 'SHAKE MÁLNÁS SAJTTORTA', 'SHAKE OREO', 'SHAKE PISTACHIO', 'SHAKE SÓS KARAMELL', 'GOFRI FAGYIVAL', 'GOFRI', 'MINI PALACSINTA', 'ROLETTI', 'TOLCSER FAGYLALTOS', 'OREO KEKSZDARABOK',],
  'Egyéb': [ 'SAJT PARMEZAN SZELETELT', 'SAJT SZELETELT', 'SO BORS MIX',],
};
const kgItems = new Set([ ...initialWasteMenuData['Szószok'], ...initialWasteMenuData['Zöldségek'], 'KAVE LAVAZZA', 'BURGONYA HASÁB', 'ÉDESBURGONYA', 'SO BORS MIX',]);
const literItems = new Set([ 'FAGYLALT 10KG', 'TEJ UHT 12L',]);

const getStoredWasteMenu = (): Record<string, WasteMenuItem[]> => {
    const menuJson = localStorage.getItem(WASTE_MENU_KEY);
    return menuJson ? JSON.parse(menuJson) : {};
};

const storeWasteMenu = (menu: Record<string, WasteMenuItem[]>) => {
    localStorage.setItem(WASTE_MENU_KEY, JSON.stringify(menu));
};

const initializeDefaultWasteMenu = () => {
    const storedMenu = getStoredWasteMenu();
    const categories = Object.keys(storedMenu);
    // Check if menu is uninitialized OR if it is in the old format (lacks 'unit' property)
    const isOldFormat = categories.length > 0 && storedMenu[categories[0]] && storedMenu[categories[0]][0] && typeof (storedMenu[categories[0]][0] as any).unit === 'undefined';

    if (categories.length === 0 || isOldFormat) {
        // If migrating, use the already stored data as the base, otherwise use the hardcoded initial data.
        const sourceData = isOldFormat ? storedMenu : initialWasteMenuData;
        const migratedMenu: Record<string, WasteMenuItem[]> = {};
        for (const category in sourceData) {
            const items = (sourceData as any)[category] as (string | {name: string})[];
            migratedMenu[category] = items.map((itemOrName: string | {name: string}) => {
                const name = typeof itemOrName === 'string' ? itemOrName : itemOrName.name;
                let unit: 'db' | 'kg' | 'l' = 'db';
                if (kgItems.has(name)) unit = 'kg';
                if (literItems.has(name)) unit = 'l';
                return { name, unit };
            });
        }
        storeWasteMenu(migratedMenu);
    }
};
initializeDefaultWasteMenu();

// --- LOGGING ---

const getStoredLogs = (): WasteLog[] => {
    const logsJson = localStorage.getItem(WASTE_LOGS_KEY);
    return logsJson ? JSON.parse(logsJson) : [];
};

const storeLogs = (logs: WasteLog[]) => {
    localStorage.setItem(WASTE_LOGS_KEY, JSON.stringify(logs));
};

export const wasteService = {
    // Menu Functions
    async getMenu(): Promise<Record<string, WasteMenuItem[]>> {
        await new Promise(res => setTimeout(res, 100));
        return getStoredWasteMenu();
    },
    async saveMenu(menu: Record<string, WasteMenuItem[]>): Promise<void> {
        await new Promise(res => setTimeout(res, 300));
        storeWasteMenu(menu);
    },

    // Logging Functions
    async logWaste(
        user: User,
        items: { name: string; quantity: number }[],
    ): Promise<void> {
        await new Promise(res => setTimeout(res, 500));
        const logs = getStoredLogs();

        const newLog: WasteLog = {
            id: `waste_${Date.now()}`,
            userId: user.id,
            userName: user.name,
            items,
            timestamp: Date.now(),
        };
        logs.push(newLog);
        storeLogs(logs);
    },

    async getTodaysLogs(): Promise<WasteLog[]> {
        await new Promise(res => setTimeout(res, 300));
        const logs = getStoredLogs();
        const todayStart = new Date();
        todayStart.setHours(0, 0, 0, 0);

        return logs.filter(log => log.timestamp >= todayStart.getTime())
            .sort((a, b) => b.timestamp - a.timestamp);
    },
};
