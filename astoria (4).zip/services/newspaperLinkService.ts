const NEWSPAPER_LINK_KEY = 'astoria_newspaper_link_text';
const DEFAULT_TEXT = 'Kattints a legfrissebb bulvárhírekért !';

interface NewspaperLinkData {
    text: string;
}

const getStoredNewspaperLink = (): NewspaperLinkData => {
    const linkJson = localStorage.getItem(NEWSPAPER_LINK_KEY);
    return linkJson ? JSON.parse(linkJson) : { text: DEFAULT_TEXT };
};

const storeNewspaperLink = (data: NewspaperLinkData) => {
    localStorage.setItem(NEWSPAPER_LINK_KEY, JSON.stringify(data));
};

export const newspaperLinkService = {
    async getNewspaperLink(): Promise<NewspaperLinkData> {
        await new Promise(res => setTimeout(res, 100));
        return getStoredNewspaperLink();
    },

    async updateNewspaperLink(newText: string): Promise<NewspaperLinkData> {
        await new Promise(res => setTimeout(res, 300));
        const newLinkData = { text: newText };
        storeNewspaperLink(newLinkData);
        return newLinkData;
    },
};