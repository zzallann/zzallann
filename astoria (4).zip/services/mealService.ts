import type { User, MealLog, MealMenuItem } from '../types';

const MEAL_LOGS_KEY = 'astoria_meal_logs';
const MEAL_MENU_KEY = 'astoria_meal_menu';

// --- MENU MANAGEMENT ---

const initialMealMenuData: Record<string, { name: string; price: number }[]> = {
  'Üdítők': [
    { name: 'ALMALÉ 0,3L', price: 140.46 }, { name: 'ALMALÉ 0,4 L', price: 177.40 }, { name: 'COLA 0,33', price: 153.14 },
    { name: 'COLA ZERO 0,33', price: 148.17 }, { name: 'FANTA 0,33', price: 153.12 }, { name: 'FUZETEA CITROM', price: 164.00 },
    { name: 'FUZETEA ZÖLD', price: 156.50 }, { name: 'HAPPY DAY NARANCS 0,2L', price: 155.00 }, { name: 'MONSTER', price: 291.84 },
    { name: 'MULTIVITAMIN HAPPY DAY 100% 0,2L', price: 101.26 }, { name: 'NATURAQUA MENTES', price: 103.96 }, { name: 'NATURAQUA SAVAS', price: 104.53 },
    { name: 'RED BULL', price: 315.48 }, { name: 'REFIL COLA', price: 82.64 }, { name: 'REFIL FANTA', price: 91.47 },
    { name: 'REFIL GYÖMBÉR', price: 95.41 }, { name: 'REFIL JEGES TEA BARACK', price: 57.02 }, { name: 'REFIL JEGES TEA CITROM', price: 63.98 },
    { name: 'REFIL SPRITE', price: 71.23 }, { name: 'REFIL ZERO COLA', price: 71.23 }, { name: 'SAN BENEDETTO MENTES', price: 84.13 },
    { name: 'SIÓ ALMA 0,2L', price: 83.70 }, { name: 'SPRITE 0,33', price: 148.17 },
  ],
  'Kávék': [
    { name: 'LAVAZZA ESPRESSO', price: 126.45 }, { name: 'LAVAZZA DUPLA ESPRESSO', price: 170.10 }, { name: 'LAVAZZA MACCHIATTO', price: 129.87 },
    { name: 'LAVAZZA DUPLA MACCHIATTO', price: 174.45 }, { name: 'LAVAZZA CAPUCCINO', price: 173.82 }, { name: 'LAVAZZA DUPLA CAPUCCINO', price: 234.92 },
    { name: 'LAVAZZA HOSSZÚ KÁVÉ', price: 158.04 }, { name: 'LAVAZZA LATTE', price: 208.73 }, { name: 'TEA NAGY FORRÓ', price: 116.93 },
  ],
  'Shake': [ { name: 'SHAKE KÁVÉ', price: 323.52 }, { name: 'SHAKE MÁLNÁS SAJTTORTA', price: 400.59 }, { name: 'SHAKE OREO', price: 340.51 }, { name: 'SHAKE SÓS KARAMELL', price: 265.36 }, { name: 'SHAKE PISTACHIO', price: 412.20 },],
  'Saláta': [ { name: 'SALÁTA KING ALAP', price: 457.61 }, { name: 'SALÁTA KICSI', price: 206.00 }, ],
  'Reggelik': [ { name: 'BACON TOJÁSOS SZENDVICS', price: 286.99 }, { name: 'BACON TOAST', price: 179.87 }, { name: 'SAJTOS TOAST', price: 99.12 },],
  'Szendvicsek': [
    { name: 'BACON KING', price: 1141.30 }, { name: 'CHICKEN BACON KING', price: 631.91 }, { name: 'CHICKEN ROYALE', price: 361.83 },
    { name: 'CHILI CHEESE BACON KING', price: 1167.90 }, { name: 'CHILI CHEESE BURGER', price: 265.59 }, { name: 'CHILI CHEESE CRISPY CHICKEN', price: 252.60 },
    { name: 'CRISPY CHICKEN', price: 256.83 }, { name: 'DUPLA CHILI CHEESE BURGER', price: 481.29 }, { name: 'DUPLA SAJTBURGER', price: 448.63 },
    { name: 'DUPLA WHOPPER', price: 1001.83 }, { name: 'DUPLA WHOPPER SAJT', price: 1046.85 }, { name: 'GLUTÉNMENTES WHOPPER', price: 811.35 },
    { name: 'HAMBURGER', price: 231.95 }, { name: 'HAMBURGER KIDS', price: 227.42 }, { name: 'NUGGETS BURGER', price: 185.06 },
    { name: 'PLANTB WHOPPER', price: 417.30 }, { name: 'SAJTBURGER', price: 254.46 }, { name: 'SAJTBURGER DUPLA BACON', price: 495.22 },
    { name: 'SAJTBURGER KID\'S', price: 249.93 }, { name: 'SZENDVICS DELUX CSIRKE', price: 520.79 }, { name: 'WESTERN JUNIOR', price: 324.59 },
    { name: 'WESTERN WHOPPER', price: 665.37 }, { name: 'WHOPPER', price: 600.63 }, { name: 'JUNIOR WHOPPER', price: 275.51 },
    { name: 'WHOPPER JUNIOR SAJT', price: 298.44 }, { name: 'WHOPPER SAJT', price: 645.65 }, { name: 'WHOPPER SAJT BACON', price: 707.77 },
  ],
  'Plusz Ízesítők': [
    { name: 'PLUSZ BACON', price: 46.59 }, { name: 'PLUSZ BACON WH', price: 62.12 }, { name: 'PLUSZ HAGYMA', price: 7.06 },
    { name: 'PLUSZ HAGYMA WH', price: 14.13 }, { name: 'PLUSZ JALAPENO', price: 10.43 }, { name: 'PLUSZ JALAPENO WH', price: 20.86 },
    { name: 'PLUSZ KETCHUP', price: 2.01 }, { name: 'PLUSZ KETCHUP WH', price: 2.82 }, { name: 'PLUSZ MAJONÉZ', price: 7.42 },
    { name: 'PLUSZ MAJONÉZ WH', price: 14.16 }, { name: 'PLUSZ PARADICSOM', price: 17.55 }, { name: 'PLUSZ PARADICSOM WH', price: 35.10 },
    { name: 'PLUSZ SAJT', price: 22.51 }, { name: 'PLUSZ SAJT WH', price: 45.02 }, { name: 'PLUSZ SALÁTA', price: 12.66 }, { name: 'PLUSZ SALÁTA WH', price: 24.17 },
  ],
  'Promo': [
    { name: 'CHEDDAR BITES 4', price: 265.26 }, { name: 'CHEDDAR BITES 7', price: 466.24 }, { name: 'CHEDDAR CHEESE', price: 936.50 },
    { name: 'CHICKEN CHEDDAR', price: 873.32 }, { name: 'KING ANDALOUSE', price: 858.63 }, { name: 'KING GRILLED', price: 879.05 },
    { name: 'WRAP DELUX', price: 539.48 }, { name: 'WRAP SMOKY', price: 528.56 },
  ],
  'Sültek': [
    { name: 'NUGGETS CHILI CHEESE 5 DB', price: 177.45 }, { name: 'NUGGETS CHILI CHEESE 7 DB', price: 245.11 }, { name: 'ÉDESBURGONYA', price: 176.15 },
    { name: 'HAGYMAKARIKA', price: 118.82 }, { name: 'HAGYMAKARIKA NAGY', price: 174.08 }, { name: 'KRUMPLI KICSI', price: 58.52 },
    { name: 'KRUMPLI KÖZEPES', price: 89.52 }, { name: 'KRUMPLI XXL', price: 201.46 }, { name: 'NUGGETS 4 DB', price: 141.54 },
    { name: 'NUGGETS 6 DB', price: 215.24 }, { name: 'NUGGETS 9 DB', price: 318.71 }, { name: 'NUGGETS 20 DB', price: 708.10 },
    { name: 'NUGGETS SPICY 4 DB', price: 163.90 }, { name: 'NUGGETS SPICY 6 DB', price: 241.70 }, { name: 'NUGGETS SPICY 9 DB', price: 358.40 },
    { name: 'NUGGETS SPICY 20 DB', price: 796.30 },
  ],
  'Kosarak': [ { name: 'KOSÁR 22 DUPLA', price: 810.87 }, { name: 'KOSÁR DUO', price: 1117.63 }, { name: 'KOSÁR GIGA', price: 2107.46 }, { name: 'KOSÁR SOLO', price: 557.93 }, { name: 'KOSÁR SPICY SOLO', price: 573.04 },],
  'Desszertek': [
    { name: 'BROWNIE', price: 310.06 }, { name: 'GOFRI FAGYIVAL', price: 211.47 }, { name: 'PLUSZ CSOKI ÖNTET GOFRI', price: 20.71 },
    { name: 'PLUSZ EPER ÖNTET GOFRI', price: 14.72 }, { name: 'PLUSZ SÓSKARAMELL ÖNTET GOFRI', price: 15.31 }, { name: 'FAGYLALT CSOKI', price: 143.45 },
    { name: 'FAGYLALT EPER', price: 128.67 }, { name: 'FAGYLALT SÓSKARAMELL', price: 122.98 }, { name: 'FAGYLALT VANÍLIA', price: 92.36 },
    { name: 'FAGYLALT TÖLCSÉRES ROLETTIVEL', price: 75.14 }, { name: 'KING FUSION EPER', price: 187.52 }, { name: 'KING FUSION OREO', price: 177.17 },
    { name: 'PLUSZ CSOKI ÖNTET KING FUSION', price: 33.14 }, { name: 'PLUSZ EPER ÖNTET KING FUSION', price: 23.55 }, { name: 'PLUSZ MÁLNÁS SAJT ÖNTET KING FUSION', price: 84.10 },
    { name: 'PLUSZ SÓSKARAMELL ÖNTET KING FUSION', price: 24.50 }, { name: 'MINI PALACSINTA ÜRES', price: 125.81 }, { name: 'PLUSZ CSOKI ÖNTET', price: 51.08 },
    { name: 'PLUSZ EPER ÖNTET', price: 36.30 }, { name: 'PLUSZ JUHARSZIRUP ÖNTET', price: 41.25 }, { name: 'PLUSZ SÓSKARAMELL ÖNTET', price: 30.62 },
    { name: 'BROWNIE SAJTTOTA', price: 324.71 }, { name: 'KING FUSION PISTACHIO', price: 224.96 },
  ],
  'Szószok': [
    { name: 'ÖNTET CEASAR', price: 116.00 }, { name: 'ÖNTET EZERSZIGET', price: 116.00 }, { name: 'ÖNTET FRANCIA', price: 116.00 },
    { name: 'TÁLKÁS BBQ', price: 36.48 }, { name: 'TÁLKÁS CHILI CHEESE', price: 40.29 }, { name: 'TÁLKÁS CURRY MANGO', price: 45.59 },
    { name: 'TÁLKÁS ÉDES SAVANYÚ', price: 36.38 }, { name: 'TÁLKÁS KETCHUP', price: 31.52 }, { name: 'TÁLKÁS MAJONÉZ', price: 45.95 },
    { name: 'TÁLKÁS SAJTSZÓSZ', price: 58.20 }, { name: 'TÁLKÁS SALSA', price: 27.46 },
  ],
  'Egyéb': [
    { name: 'HÚSPOGÁCSA BURGER', price: 176.36 }, { name: 'HÚSPOGÁCSA CRISPY CHICKEN', price: 163.37 }, { name: 'HÚSPOGÁCSA DELUX CSIRKE', price: 344.42 },
    { name: 'HÚSPOGÁCSA GOURMET', price: 525.38 }, { name: 'HÚSPOGÁCSA REBEL', price: 226.72 }, { name: 'HÚSPOGÁCSA WHOPPER', price: 406.88 },
  ],
  'Loaded fries': [ { name: 'BACON FRIES', price: 264.97 }, { name: 'CHEESY FRIES', price: 192.13 }, { name: 'FULL FRIES', price: 287.21 }, { name: 'HOT FRIES', price: 218.20 },],
};

const getStoredMenu = (): Record<string, MealMenuItem[]> => {
    const menuJson = localStorage.getItem(MEAL_MENU_KEY);
    return menuJson ? JSON.parse(menuJson) : {};
};

const storeMenu = (menu: Record<string, MealMenuItem[]>) => {
    localStorage.setItem(MEAL_MENU_KEY, JSON.stringify(menu));
};

const initializeDefaultMenu = () => {
    const storedMenu = getStoredMenu();
    const categories = Object.keys(storedMenu);
    // Check if menu is uninitialized OR if it is in the old format (lacks 'unit' property)
    const isOldFormat = categories.length > 0 && storedMenu[categories[0]] && storedMenu[categories[0]][0] && typeof (storedMenu[categories[0]][0] as any).unit === 'undefined';

    if (categories.length === 0 || isOldFormat) {
        // If migrating, use the already stored data as the base, otherwise use the hardcoded initial data.
        const sourceData = isOldFormat ? storedMenu : initialMealMenuData;
        const migratedMenu: Record<string, MealMenuItem[]> = {};
        for (const category in sourceData) {
             migratedMenu[category] = (sourceData as any)[category].map((item: {name: string, price: number}) => ({
                name: item.name,
                price: item.price,
                unit: 'db' as 'db' | 'kg' // Default unit for all meals is 'db'
            }));
        }
        storeMenu(migratedMenu);
    }
};

initializeDefaultMenu();

// --- LOGGING ---

const getStoredLogs = (): MealLog[] => {
    const logsJson = localStorage.getItem(MEAL_LOGS_KEY);
    return logsJson ? JSON.parse(logsJson) : [];
};

const storeLogs = (logs: MealLog[]) => {
    localStorage.setItem(MEAL_LOGS_KEY, JSON.stringify(logs));
};

export const mealService = {
    // Menu Functions
    async getMenu(): Promise<Record<string, MealMenuItem[]>> {
        await new Promise(res => setTimeout(res, 100));
        return getStoredMenu();
    },
    async saveMenu(menu: Record<string, MealMenuItem[]>): Promise<void> {
        await new Promise(res => setTimeout(res, 300));
        storeMenu(menu);
    },

    // Logging Functions
    async logMeal(
        userDetails: { id: string; name: string; avatarId: string | null; uploadedImage: string | null },
        items: { name: string; quantity: number; price: number }[],
        totalPrice: number
    ): Promise<void> {
        await new Promise(res => setTimeout(res, 500));
        const logs = getStoredLogs();

        const newLog: MealLog = {
            id: `log_${Date.now()}`,
            userId: userDetails.id,
            userName: userDetails.name,
            userAvatarId: userDetails.avatarId,
            userUploadedImage: userDetails.uploadedImage,
            items,
            totalPrice,
            timestamp: Date.now(),
        };

        logs.push(newLog);
        storeLogs(logs);
    },

    async getTodaysLogs(): Promise<MealLog[]> {
        await new Promise(res => setTimeout(res, 300));
        const logs = getStoredLogs();
        const todayStart = new Date();
        todayStart.setHours(0, 0, 0, 0);

        return logs.filter(log => log.timestamp >= todayStart.getTime())
            .sort((a, b) => b.timestamp - a.timestamp);
    },
};
