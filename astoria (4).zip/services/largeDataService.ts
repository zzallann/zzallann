// services/largeDataService.ts
const DB_NAME = 'AstoriaLargeDataStore';
const STORE_NAME = 'files';
const DB_VERSION = 1;

let dbPromise: Promise<IDBDatabase> | null = null;

const getDb = (): Promise<IDBDatabase> => {
    if (dbPromise) {
        return dbPromise;
    }
    dbPromise = new Promise((resolve, reject) => {
        const request = indexedDB.open(DB_NAME, DB_VERSION);

        request.onerror = () => {
            console.error('IndexedDB error:', request.error);
            reject(request.error);
        };

        request.onsuccess = () => {
            resolve(request.result);
        };

        request.onupgradeneeded = () => {
            const db = request.result;
            if (!db.objectStoreNames.contains(STORE_NAME)) {
                db.createObjectStore(STORE_NAME);
            }
        };
    });
    return dbPromise;
};

export const largeDataService = {
    async setItem(key: string, value: any): Promise<void> {
        const db = await getDb();
        return new Promise((resolve, reject) => {
            const transaction = db.transaction(STORE_NAME, 'readwrite');
            const store = transaction.objectStore(STORE_NAME);
            transaction.oncomplete = () => resolve();
            transaction.onerror = () => reject(transaction.error);
            store.put(value, key);
        });
    },

    async getItem<T>(key: string): Promise<T | null> {
        const db = await getDb();
        return new Promise((resolve, reject) => {
            const transaction = db.transaction(STORE_NAME, 'readonly');
            const store = transaction.objectStore(STORE_NAME);
            const request = store.get(key);
            
            request.onsuccess = () => {
                resolve(request.result ?? null);
            };
            request.onerror = () => reject(request.error);
        });
    },

    async deleteItem(key: string): Promise<void> {
        const db = await getDb();
        return new Promise((resolve, reject) => {
            const transaction = db.transaction(STORE_NAME, 'readwrite');
            const store = transaction.objectStore(STORE_NAME);
            transaction.oncomplete = () => resolve();
            transaction.onerror = () => reject(transaction.error);
            store.delete(key);
        });
    },
};
