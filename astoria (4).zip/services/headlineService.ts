const HEADLINE_KEY = 'astoria_headline';
const DEFAULT_HEADLINE = 'Teremts bizalmat! A vendég az első! Támogasd a fejlődést! Törekedj a kiválóságra ! Győztes Csapat! Keresd a megoldást!';

interface HeadlineData {
    text: string;
}

const getStoredHeadline = (): HeadlineData => {
    const headlineJson = localStorage.getItem(HEADLINE_KEY);
    return headlineJson ? JSON.parse(headlineJson) : { text: DEFAULT_HEADLINE };
};

const storeHeadline = (headline: HeadlineData) => {
    localStorage.setItem(HEADLINE_KEY, JSON.stringify(headline));
};

export const headlineService = {
    async getHeadline(): Promise<HeadlineData> {
        await new Promise(res => setTimeout(res, 100));
        return getStoredHeadline();
    },

    async updateHeadline(newText: string): Promise<HeadlineData> {
        await new Promise(res => setTimeout(res, 300));
        const newHeadline = { text: newText };
        storeHeadline(newHeadline);
        return newHeadline;
    },
};
