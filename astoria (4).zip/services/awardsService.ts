import type { MonthAward, Event, AwardWinner } from '../types';

const AWARDS_KEY = 'astoria_awards';
const EVENTS_KEY = 'astoria_events';

// --- AWARDS SERVICE LOGIC ---

const getStoredAwards = (): MonthAward[] => {
    const awardsJson = localStorage.getItem(AWARDS_KEY);
    return awardsJson ? JSON.parse(awardsJson) : [];
};

const storeAwards = (awards: MonthAward[]) => {
    localStorage.setItem(AWARDS_KEY, JSON.stringify(awards));
};

// --- EVENTS SERVICE LOGIC ---

const getStoredEvents = (): Event[] => {
    const eventsJson = localStorage.getItem(EVENTS_KEY);
    return eventsJson ? JSON.parse(eventsJson) : [];
};

const storeEvents = (events: Event[]) => {
    localStorage.setItem(EVENTS_KEY, JSON.stringify(events));
};


export const awardsService = {
    async getAwardsForMonth(monthId: string): Promise<MonthAward | null> {
        await new Promise(res => setTimeout(res, 200));
        const allAwards = getStoredAwards();
        return allAwards.find(a => a.id === monthId) || null;
    },

    async saveMonthAwards(monthId: string, winners: AwardWinner[], published: boolean): Promise<MonthAward> {
        await new Promise(res => setTimeout(res, 400));
        let allAwards = getStoredAwards();
        const existingIndex = allAwards.findIndex(a => a.id === monthId);

        const newAwardData: MonthAward = { id: monthId, winners, published };

        if (existingIndex > -1) {
            allAwards[existingIndex] = newAwardData;
        } else {
            allAwards.push(newAwardData);
        }
        storeAwards(allAwards);
        return newAwardData;
    },

    async getEvents(): Promise<Event[]> {
        await new Promise(res => setTimeout(res, 200));
        const events = getStoredEvents();
        return events.sort((a, b) => a.date - b.date); // Sort by upcoming date
    },

    async saveEvent(eventData: Omit<Event, 'id' | 'createdAt'>, existingId?: string): Promise<Event> {
        await new Promise(res => setTimeout(res, 400));
        let allEvents = getStoredEvents();
        
        if (existingId) { // Update
            const eventIndex = allEvents.findIndex(e => e.id === existingId);
            if (eventIndex > -1) {
                allEvents[eventIndex] = { ...allEvents[eventIndex], ...eventData };
                storeEvents(allEvents);
                return allEvents[eventIndex];
            }
        }
        
        // Create
        const newEvent: Event = {
            ...eventData,
            id: `event_${Date.now()}`,
            createdAt: Date.now(),
        };
        allEvents.push(newEvent);
        storeEvents(allEvents);
        return newEvent;
    },

    async deleteEvent(eventId: string): Promise<void> {
        await new Promise(res => setTimeout(res, 300));
        let allEvents = getStoredEvents();
        allEvents = allEvents.filter(e => e.id !== eventId);
        storeEvents(allEvents);
    }
};