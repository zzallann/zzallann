import type { GameState, User, GamePlayer, GamePiece } from '../types';

// =============================================================================
// IMPORTANT: MOCK BACKEND SIMULATION
// =============================================================================
// This service simulates a backend for a "Ki nevet a végén?" (Ludo) game
// using the browser's localStorage. In a real application, this logic
// would be on a secure server to prevent cheating and manage multiplayer state.
// =============================================================================

const GAME_STATE_KEY = 'astoria_game_state';

const getStoredGameState = (): GameState | null => {
    const stateJson = localStorage.getItem(GAME_STATE_KEY);
    return stateJson ? JSON.parse(stateJson) : null;
};

const storeGameState = (state: GameState) => {
    localStorage.setItem(GAME_STATE_KEY, JSON.stringify(state));
};

const createNewGameState = (users: User[]): GameState => {
    const colors: Array<'red' | 'blue' | 'green' | 'yellow'> = ['red', 'blue', 'green', 'yellow'];
    const players: GamePlayer[] = users.slice(0, 4).map((user, index) => {
        const pieces: GamePiece[] = Array(4).fill(0).map((_, i) => ({
            id: i,
            position: -1, // -1 means in home base
            state: 'home',
        }));
        return {
            user,
            color: colors[index],
            pieces,
        };
    });

    return {
        id: `game_${Date.now()}`,
        players,
        currentPlayerIndex: 0,
        diceValue: null,
        status: 'playing',
        message: `A játék elkezdődött! ${players[0].user.name} következik.`,
    };
};

// Simplified game logic
// In a real game, this would be much more complex, handling captures, blocks, etc.
const calculateNewPosition = (player: GamePlayer, piece: GamePiece, diceValue: number): number => {
    // This is a very simplified movement logic
    if (piece.state === 'home' && diceValue === 6) {
        // Starting position for each color
        const startPositions = { red: 0, blue: 13, green: 26, yellow: 39 };
        return startPositions[player.color];
    }
    if (piece.state === 'active') {
        return (piece.position + diceValue) % 52;
    }
    return piece.position;
};


export const gameService = {
    async getGameState(currentUser: User): Promise<GameState> {
        // Simulate network delay
        await new Promise(res => setTimeout(res, 200));
        let state = getStoredGameState();
        if (!state) {
            // Create a new game with dummy players for demo purposes
            const now = Date.now();
            const dummyUsers: User[] = [
                currentUser,
// FIX: Added missing 'fullName' and 'approved' properties to dummy users to match the User type.
                { id: 'bot1', name: 'Panda Bot', fullName: 'Panda Bot', identifier: 'bot1', avatarId: 'panda', uploadedImage: null, points: 0, registrationDate: now, pointsHistory: [], reactedPostsForPoints: [], reactedMessagesForPoints: [], commentedPostsForPoints: [], reactedCommentsForPoints: [], status: 'normal', lastSeen: now, strikes: 0, approved: true },
                { id: 'bot2', name: 'Fox Bot', fullName: 'Fox Bot', identifier: 'bot2', avatarId: 'fox', uploadedImage: null, points: 0, registrationDate: now, pointsHistory: [], reactedPostsForPoints: [], reactedMessagesForPoints: [], commentedPostsForPoints: [], reactedCommentsForPoints: [], status: 'normal', lastSeen: now, strikes: 0, approved: true },
                { id: 'bot3', name: 'Bear Bot', fullName: 'Bear Bot', identifier: 'bot3', avatarId: 'bear', uploadedImage: null, points: 0, registrationDate: now, pointsHistory: [], reactedPostsForPoints: [], reactedMessagesForPoints: [], commentedPostsForPoints: [], reactedCommentsForPoints: [], status: 'normal', lastSeen: now, strikes: 0, approved: true },
            ];
            state = createNewGameState(dummyUsers);
            storeGameState(state);
        }
        return state;
    },

    async rollDice(): Promise<GameState> {
        await new Promise(res => setTimeout(res, 300));
        const state = getStoredGameState();
        if (!state || state.status !== 'playing') throw new Error("A játék nem aktív.");

        const diceValue = Math.floor(Math.random() * 6) + 1;
        state.diceValue = diceValue;

        const currentPlayer = state.players[state.currentPlayerIndex];
        const canMove = currentPlayer.pieces.some(p => 
            (p.state === 'home' && diceValue === 6) || p.state === 'active'
        );

        if (!canMove && diceValue !== 6) {
            state.currentPlayerIndex = (state.currentPlayerIndex + 1) % state.players.length;
            const nextPlayer = state.players[state.currentPlayerIndex];
            state.message = `${currentPlayer.user.name} dobott (${diceValue}), de nem tud lépni. ${nextPlayer.user.name} következik.`;
        } else {
            state.message = `${currentPlayer.user.name} dobott (${diceValue})! Válassz egy bábut a lépéshez.`;
        }
        
        storeGameState(state);
        return state;
    },

    async movePiece(pieceId: number): Promise<GameState> {
        await new Promise(res => setTimeout(res, 200));
        const state = getStoredGameState();
        if (!state || !state.diceValue || state.status !== 'playing') {
            throw new Error("Most nem lehet lépni.");
        }

        const player = state.players[state.currentPlayerIndex];
        const piece = player.pieces.find(p => p.id === pieceId);
        
        if (!piece) throw new Error("Érvénytelen bábu.");

        // Basic move validation
        if (piece.state === 'home' && state.diceValue !== 6) {
            state.message = "Csak 6-os dobással léphetsz ki a házból!";
            storeGameState(state);
            return state;
        }

        const newPosition = calculateNewPosition(player, piece, state.diceValue);
        piece.position = newPosition;
        if (piece.state === 'home') {
            piece.state = 'active';
        }
        
        // Very basic win condition check
        const hasWon = player.pieces.every(p => p.state === 'safe');
        if (hasWon) {
            state.status = 'finished';
            state.winner = player.user.name;
            state.message = `Játék vége! ${player.user.name} győzött!`;
        } else {
             // If not a 6, next player's turn
            if (state.diceValue !== 6) {
                state.currentPlayerIndex = (state.currentPlayerIndex + 1) % state.players.length;
            }
            const nextPlayer = state.players[state.currentPlayerIndex];
            state.message = `${nextPlayer.user.name} következik. Dobj a kockával!`;
        }

        state.diceValue = null; // Reset dice after move
        storeGameState(state);
        return state;
    }
};