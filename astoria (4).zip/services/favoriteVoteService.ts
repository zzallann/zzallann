import type { User, MonthlyFavoriteVotes, FavoriteVote } from '../types';
import { messageService } from './messageService';

const FAVORITE_VOTES_KEY = 'astoria_favorite_votes';

const getStoredVotes = (): MonthlyFavoriteVotes[] => {
    const votesJson = localStorage.getItem(FAVORITE_VOTES_KEY);
    return votesJson ? JSON.parse(votesJson) : [];
};

const storeVotes = (votes: MonthlyFavoriteVotes[]) => {
    localStorage.setItem(FAVORITE_VOTES_KEY, JSON.stringify(votes));
};

export const favoriteVoteService = {
    async getVotesForMonth(monthId: string): Promise<MonthlyFavoriteVotes | null> {
        await new Promise(res => setTimeout(res, 100));
        const allVotes = getStoredVotes();
        return allVotes.find(v => v.id === monthId) || null;
    },

    async castVote(voterId: string, category: 'normal' | 'pro' | 'pro_max', votedForId: string): Promise<void> {
        await new Promise(res => setTimeout(res, 400));
        const allVotes = getStoredVotes();
        const monthId = new Date().toISOString().slice(0, 7); // "YYYY-MM"
        
        let monthVotes = allVotes.find(v => v.id === monthId);
        if (!monthVotes) {
            monthVotes = { id: monthId, votes: [] };
            allVotes.push(monthVotes);
        }

        const hasVotedInCategory = monthVotes.votes.some(v => v.voterId === voterId && v.category === category);
        if (hasVotedInCategory) {
            throw new Error('Ebben a kategóriában már szavaztál ebben a hónapban.');
        }

        monthVotes.votes.push({ voterId, category, votedForId });
        storeVotes(allVotes);
    },

    async sendWinnerNotifications(monthId: string, allUsers: User[]): Promise<void> {
        await new Promise(res => setTimeout(res, 500));
        const allVotes = getStoredVotes();
        const monthVotes = allVotes.find(v => v.id === monthId);

        if (!monthVotes || monthVotes.notificationsSent) {
            return; // Already sent or no votes
        }

        const categories: FavoriteVote['category'][] = ['normal', 'pro', 'pro_max'];
        
        for (const category of categories) {
            const votesForCategory = monthVotes.votes.filter(v => v.category === category);
            if (votesForCategory.length === 0) continue;

            const voteCounts = votesForCategory.reduce((acc, vote) => {
                acc[vote.votedForId] = (acc[vote.votedForId] || 0) + 1;
                return acc;
            }, {} as Record<string, number>);

            const winnerId = Object.keys(voteCounts).reduce((a, b) => voteCounts[a] > voteCounts[b] ? a : b);
            
            if (winnerId) {
                const voters = votesForCategory
                    .filter(v => v.votedForId === winnerId)
                    .map(v => allUsers.find(u => u.id === v.voterId)?.name)
                    .filter(Boolean);
                
                const categoryLabels = {
                    normal: 'Hónap Kedvenc Kollégája',
                    pro: 'Hónap Kedvenc Kisvezetője',
                    pro_max: 'Hónap Kedvenc Managere'
                };
                const categoryLabel = categoryLabels[category];

                const message = `Gratulálunk! Te lettél a ${categoryLabel}!\n\nA következő személyek szavaztak rád:\n- ${voters.join('\n- ')}`;

                const systemId = 'system_police_bot';
                const convoId = await messageService.findOrCreateConversation(systemId, winnerId);
                await messageService.sendMessage(systemId, convoId, message, null, null, false);
            }
        }
        
        monthVotes.notificationsSent = true;
        storeVotes(allVotes);
    }
};
