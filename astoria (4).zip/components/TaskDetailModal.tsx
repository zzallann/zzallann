import React from 'react';
import type { AssignedTask, User } from '../types';
import XCircleIcon from './icons/XCircleIcon';

interface TaskDetailModalProps {
  isOpen: boolean;
  onClose: () => void;
  task: AssignedTask | null;
  users: User[];
}

const TaskDetailModal: React.FC<TaskDetailModalProps> = ({ isOpen, onClose, task, users }) => {
  if (!isOpen || !task) return null;

  const assigner = users.find(u => u.id === task.assignedById)?.name || 'Ismeretlen';
  const assignee = users.find(u => u.id === task.assignedToUserId)?.name || 'Ismeretlen';
  const creationTimestamp = parseInt(task.id.split('_')[1], 10);
  const creationDate = new Date(creationTimestamp).toLocaleString('hu-HU');
  const deadlineDate = new Date(task.deadline).toLocaleString('hu-HU');

  return (
    <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex justify-center items-center z-50 animate-fade-in" onClick={onClose}>
      <div className="bg-slate-800 w-full max-w-md rounded-2xl shadow-2xl p-6 text-white" onClick={e => e.stopPropagation()}>
        <div className="flex justify-between items-center mb-4">
            <h3 className="text-2xl font-bold font-lilita">Feladat Részletei</h3>
            <button onClick={onClose} className="p-1 rounded-full hover:bg-slate-700">
                <XCircleIcon className="w-6 h-6 text-slate-400"/>
            </button>
        </div>
        
        <div className="space-y-4">
            <div>
                <label className="block text-sm font-semibold text-slate-400">Feladat</label>
                <p className="text-lg bg-slate-700/50 p-3 rounded-lg whitespace-pre-wrap">{task.description}</p>
            </div>
            
            <div className="grid grid-cols-2 gap-4">
                <div>
                    <label className="block text-sm font-semibold text-slate-400">Kiosztotta</label>
                    <p className="font-semibold">{assigner}</p>
                </div>
                 <div>
                    <label className="block text-sm font-semibold text-slate-400">Megbízott</label>
                    <p className="font-semibold">{assignee}</p>
                </div>
            </div>
            
            <div>
                <label className="block text-sm font-semibold text-slate-400">Létrehozva</label>
                <p>{creationDate}</p>
            </div>

            <div>
                <label className="block text-sm font-semibold text-slate-400">Határidő</label>
                <p className="font-bold text-orange-400">{deadlineDate}</p>
            </div>
        </div>
      </div>
    </div>
  );
};

export default TaskDetailModal;
