import React from 'react';
import type { User } from '../types';
import { avatars } from './AvatarSelector';

interface UserAvatarWithStatusProps {
    user: User | null;
    size?: 'xx-small' | 'x-small' | 'small' | 'medium' | 'large';
    showStatus?: boolean;
}

const UserAvatarWithStatus: React.FC<UserAvatarWithStatusProps> = ({ user, size = 'medium', showStatus = true }) => {
    if (!user) return null;

    const userAvatar = avatars.find(a => a.id === user.avatarId);

    const sizeClasses = {
        'xx-small': 'w-6 h-6',
        'x-small': 'w-8 h-8',
        small: 'w-10 h-10',
        medium: 'w-12 h-12',
        large: 'w-20 h-20',
    };
    const statusSizeClasses = {
        'xx-small': 'w-2.5 h-2.5 -bottom-0.5 -right-0.5',
        'x-small': 'w-3 h-3 -bottom-0 -right-0',
        small: 'w-4 h-4 -bottom-0.5 -right-0.5',
        medium: 'w-4 h-4 bottom-0 right-0',
        large: 'w-5 h-5 bottom-1 right-1',
    };

    const timeSinceSeen = Date.now() - user.lastSeen;
    let statusColorClass = 'bg-gradient-to-br from-gray-500 to-gray-700'; // offline
    
    if (user.id === 'system_police_bot') {
        statusColorClass = 'bg-gradient-to-br from-green-400 to-teal-400';
    } else if (timeSinceSeen < 5 * 60 * 1000) { // < 5 mins
        statusColorClass = 'bg-gradient-to-br from-green-400 to-teal-400'; // online
    } else if (timeSinceSeen < 20 * 60 * 1000) { // < 20 mins
        statusColorClass = 'bg-gradient-to-br from-yellow-400 to-orange-400'; // away
    }

    return (
        <div className={`relative flex-shrink-0 ${sizeClasses[size]}`}>
            <div className="w-full h-full rounded-full overflow-hidden bg-slate-700/50 flex items-center justify-center">
                {user.uploadedImage ? (
                    <img src={user.uploadedImage} alt={user.name} className="w-full h-full object-cover" />
                ) : userAvatar ? (
                    <userAvatar.component />
                ) : (
                    <span className="font-bold text-white">{user.name.charAt(0)}</span>
                )}
            </div>
            {showStatus && (
                 <div className={`absolute rounded-full border-2 border-[var(--component-bg)] ${statusSizeClasses[size]} ${statusColorClass}`} />
            )}
        </div>
    );
};

export default UserAvatarWithStatus;