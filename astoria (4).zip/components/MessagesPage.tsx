import React, { useState, useEffect, useCallback, useRef, useMemo } from 'react';
import type { User, Conversation, Message } from '../types';
import { messageService } from '../services/messageService';
import { useNotification } from '../contexts/NotificationContext';
import ArrowLeftIcon from './icons/ArrowLeftIcon';
import SearchIcon from './icons/SearchIcon';
import SettingsIcon from './icons/SettingsIcon';
import SendIcon from './icons/SendIcon';
import ImageIcon from './icons/ImageIcon';
import GifIcon from './icons/GifIcon';
import EmojiIcon from './icons/EmojiIcon';
import XCircleIcon from './icons/XCircleIcon';
import UserAvatarWithStatus from './UserAvatarWithStatus';
import MessageBubble from './MessageBubble';
import ChatSettingsMenu from './ChatSettingsMenu';
import MuteChatModal from './MuteChatModal';
import ChatParticipantsModal from './ChatParticipantsModal';
import ChatMediaModal from './ChatMediaModal';
import EmojiPicker from './EmojiPicker';
import GifPicker from './GifPicker';
import { authService } from '../services/authService';
import GoldCrownIcon from './icons/GoldCrownIcon';
import SilverCrownIcon from './icons/SilverCrownIcon';
import BronzeCrownIcon from './icons/BronzeCrownIcon';
import UltraChatIcon from './icons/UltraChatIcon';
import UsersIcon from './icons/UsersIcon';
import PlusIcon from './icons/PlusIcon';
import CreateGroupChatPage from './CreateGroupChatPage';
import GroupImageEditorModal from './GroupImageEditorModal';
import { avatars } from './AvatarSelector';
import AddUserToGroupModal from './AddUserToGroupModal';
import RenameGroupModal from './RenameGroupModal';


interface MessagesPageProps {
    currentUser: User;
    onUserUpdate: (user: User) => void;
    onConversationsChange: () => void;
    setChatViewActive: (isActive: boolean) => void;
}

const timeAgo = (timestamp: number): string => {
    const now = Date.now();
    const seconds = Math.floor((now - timestamp) / 1000);
    
    let interval = seconds / 31536000;
    if (interval > 1) return Math.floor(interval) + " éve";
    interval = seconds / 2592000;
    if (interval > 1) return Math.floor(interval) + " hónapja";
    interval = seconds / 86400;
    if (interval > 1) return Math.floor(interval) + " napja";
    interval = seconds / 3600;
    if (interval > 1) return Math.floor(interval) + " órája";
    interval = seconds / 60;
    if (interval > 1) return Math.floor(interval) + " perce";
    return "épp most";
};

const getConversationDetails = (convo: Conversation, currentUser: User) => {
    // 1. Custom uploaded image has the highest priority
    if (convo.imageUrl) {
        return { name: convo.name || 'Csoportos Chat', imageUrl: convo.imageUrl };
    }

    // 2. Handle special system chats by their ID
    if (convo.id === 'system_group_chat') {
        return { name: convo.name || 'Csoportos Chat', avatar: <BronzeCrownIcon className="w-full h-full p-2 text-white/80" /> };
    }
    if (convo.id === 'system_pro_chat') {
        return { name: convo.name || 'Pro Chat', avatar: <SilverCrownIcon className="w-full h-full p-2 text-white/80" /> };
    }
    if (convo.id === 'system_pro_max_chat') {
        return { name: convo.name || 'Pro Max Chat', avatar: <GoldCrownIcon className="w-full h-full p-2 text-white/80" /> };
    }
    if (convo.id === 'system_ultra_chat') {
        return { name: convo.name || 'Ultra Chat', avatar: <UltraChatIcon className="w-full h-full p-2 text-white/80" /> };
    }
    
    // 3. Handle named groups (user-created)
    if (convo.name) {
        // Check for a randomly assigned avatarId
        if (convo.avatarId) {
            const avatar = avatars.find(a => a.id === convo.avatarId);
            if (avatar) {
                return { name: convo.name, avatar: <avatar.component className="w-full h-full p-2 text-white/80" /> };
            }
        }
        // Fallback to the generic UsersIcon if no avatarId is found
        return { name: convo.name, avatar: <UsersIcon className="w-full h-full p-2 text-white/80" /> };
    }

    // 4. Handle 1-on-1 chats and system notifications
    const otherParticipants = convo.participants.filter(p => p.id !== currentUser.id);
    if (otherParticipants.length === 1) {
        const otherUser = otherParticipants[0];
        const nickname = convo.nicknames?.[otherUser.id];
        return { name: nickname || otherUser.name, user: otherUser, isUser: true };
    }
    if (convo.isSystemConversation) {
        const otherUser = convo.participants.find(p => p.id !== currentUser.id);
        return { name: otherUser?.name || 'Rendszer', user: otherUser || null, isUser: true };
    }

    // Fallback for older multi-person DMs without a name
    return { name: otherParticipants.map(p => p.name).join(', '), avatar: <UsersIcon className="w-full h-full p-2 text-white/80" /> };
};


const MessagesPage: React.FC<MessagesPageProps> = ({ currentUser, onUserUpdate, onConversationsChange, setChatViewActive }) => {
    const [conversations, setConversations] = useState<Conversation[]>([]);
    const [selectedConvo, setSelectedConvo] = useState<Conversation | null>(null);
    const [messages, setMessages] = useState<Message[]>([]);
    const [lastSeenBy, setLastSeenBy] = useState<Record<string, number>>({});
    const [nicknames, setNicknames] = useState<Record<string, string>>({});
    const [isLoading, setIsLoading] = useState(true);
    const [isLoadingMore, setIsLoadingMore] = useState(false);
    const [messagePage, setMessagePage] = useState(1);
    const [hasMoreMessages, setHasMoreMessages] = useState(true);
    const [firstUnreadIndex, setFirstUnreadIndex] = useState(-1);

    const [newMessage, setNewMessage] = useState('');
    const [imageFile, setImageFile] = useState<File | null>(null);
    const [gifUrl, setGifUrl] = useState<string | null>(null);
    const [isSending, setIsSending] = useState(false);

    const [showEmojiPicker, setShowEmojiPicker] = useState(false);
    const [showGifPicker, setShowGifPicker] = useState(false);
    const imageInputRef = useRef<HTMLInputElement>(null);
    const textareaRef = useRef<HTMLTextAreaElement>(null);
    
    // For navigation context from KollegakPage
    const [startChatWith, setStartChatWith] = useState<string | null>(null);
    
    // Settings and modals
    const [isSettingsOpen, setIsSettingsOpen] = useState(false);
    const [showMuteModal, setShowMuteModal] = useState(false);
    const [showParticipantsModal, setShowParticipantsModal] = useState(false);
    const [showAddUserModal, setShowAddUserModal] = useState(false);
    const [showMediaModal, setShowMediaModal] = useState(false);
    const [showImageEditor, setShowImageEditor] = useState(false);
    const [showRenameModal, setShowRenameModal] = useState(false);

    const [searchQuery, setSearchQuery] = useState('');
    const [tooltip, setTooltip] = useState<{ content: string; top: number; left: number } | null>(null);
    const tooltipTimeoutRef = useRef<ReturnType<typeof setTimeout> | null>(null);

    const [isCreatingGroup, setIsCreatingGroup] = useState(false);

    const messagesEndRef = useRef<HTMLDivElement>(null);
    const messageListRef = useRef<HTMLDivElement>(null);
    const unreadDividerRef = useRef<HTMLDivElement>(null);

    const { addNotification } = useNotification();

    const isReadOnlySystemChat = useMemo(() => {
        if (!selectedConvo) return false;
        // A chat is read-only if it's a system conversation involving a system bot,
        // and it's a one-on-one chat. This distinguishes it from interactive, 
        // predefined group chats (Group, Pro, Ultra) which are also system 
        // conversations but have many participants.
        const isWithSystemBot = selectedConvo.participants.some(p => p.id.startsWith('system_'));
        const isDirectMessage = selectedConvo.participants.length <= 2;
    
        return selectedConvo.isSystemConversation && isWithSystemBot && isDirectMessage;
    }, [selectedConvo]);

    const handleAvatarClick = (e: React.MouseEvent<HTMLButtonElement>, user: User, timestamp: number) => {
        e.stopPropagation();

        if (tooltipTimeoutRef.current) {
            clearTimeout(tooltipTimeoutRef.current);
        }

        const rect = e.currentTarget.getBoundingClientRect();
        const lastSeenTime = new Date(timestamp).toLocaleTimeString('hu-HU', {
            hour: '2-digit',
            minute: '2-digit',
        });
        
        setTooltip({
            content: `${user.name} ${lastSeenTime}`,
            top: rect.top,
            left: rect.left + rect.width / 2,
        });

        tooltipTimeoutRef.current = setTimeout(() => {
            setTooltip(null);
        }, 1000);
    };


    const fetchConversations = useCallback(async () => {
        try {
            const convos = await messageService.getConversations(currentUser.id);
            setConversations(convos);
        } catch (err) {
            addNotification("Hiba a beszélgetések betöltésekor.", "error");
        } finally {
            setIsLoading(false);
        }
    }, [currentUser.id, addNotification]);
    
     useEffect(() => {
        const context = (window as any).navigationContext;
        if (context?.startChatWith) {
            setStartChatWith(context.startChatWith);
            (window as any).navigationContext = null; // Clear context after use
        }
    }, []);

    useEffect(() => {
        fetchConversations();
        const interval = setInterval(fetchConversations, 5000);
        return () => clearInterval(interval);
    }, [fetchConversations]);

    useEffect(() => {
        if (startChatWith && conversations.length > 0) {
            let convo = conversations.find(c => c.participants.length === 2 && c.participants.some(p => p.id === startChatWith));
            if (convo) {
                handleSelectConvo(convo);
            } else {
                // If convo doesn't exist, create it
                const createAndSelect = async () => {
                    const convoId = await messageService.findOrCreateConversation(currentUser.id, startChatWith);
                    // Refetch conversations to get the new one
                    const newConvos = await messageService.getConversations(currentUser.id);
                    setConversations(newConvos);
                    const newConvo = newConvos.find(c => c.id === convoId);
                    if (newConvo) {
                        handleSelectConvo(newConvo);
                    }
                };
                createAndSelect();
            }
            setStartChatWith(null);
        }
    }, [startChatWith, conversations, currentUser.id]);

    const handleSelectConvo = (convo: Conversation) => {
        setSelectedConvo(convo);
        setMessages([]);
        setLastSeenBy({});
        setNicknames({});
        setMessagePage(1);
        setHasMoreMessages(true);
        setFirstUnreadIndex(-1);
        setChatViewActive(true);
    };

    const handleBackToList = () => {
        setSelectedConvo(null);
        setMessages([]);
        setChatViewActive(false);
        onConversationsChange(); // Refresh unread counts in sidebar
    };

    const fetchMessages = useCallback(async (convoId: string, page: number) => {
        setIsLoadingMore(true);
        try {
            const { messages: newMessages, firstUnreadIndex: unreadIndex, hasMore, lastSeenBy: newLastSeenBy, nicknames: newNicknames } = await messageService.getMessages(convoId, currentUser.id, page, 30);
            
            setMessages(prev => {
                const messageMap = new Map();
                [...newMessages, ...prev].forEach(msg => messageMap.set(msg.id, msg));
                return Array.from(messageMap.values()).sort((a,b) => a.timestamp - b.timestamp);
            });
            
            setLastSeenBy(newLastSeenBy);
            setNicknames(newNicknames);

            if (page === 1 && unreadIndex !== -1) {
                setFirstUnreadIndex(unreadIndex);
            }
            setHasMoreMessages(hasMore);

        } catch (err) {
            addNotification("Hiba az üzenetek betöltésekor.", "error");
        } finally {
            setIsLoadingMore(false);
        }
    }, [currentUser.id, addNotification]);

    useEffect(() => {
        if (selectedConvo) {
            fetchMessages(selectedConvo.id, messagePage);
        }
    }, [selectedConvo, messagePage, fetchMessages]);

     useEffect(() => {
        // On first load, scroll to unread divider or bottom
        if (messagePage === 1 && messages.length > 0 && !isLoadingMore) {
            const timer = setTimeout(() => {
                if (unreadDividerRef.current) {
                    unreadDividerRef.current.scrollIntoView({ behavior: 'smooth', block: 'center' });
                } else {
                    messagesEndRef.current?.scrollIntoView({ behavior: 'auto' });
                }
            }, 100);
            return () => clearTimeout(timer);
        }
    }, [messages, messagePage, isLoadingMore]);
    
    const handleScroll = () => {
        if (messageListRef.current && messageListRef.current.scrollTop === 0 && hasMoreMessages && !isLoadingMore) {
            setMessagePage(p => p + 1);
        }
    };
    
    const imageFileToBase64 = (file: File): Promise<string> => {
        return new Promise((resolve, reject) => {
            const reader = new FileReader();
            reader.readAsDataURL(file);
            reader.onload = () => resolve(reader.result as string);
            reader.onerror = error => reject(error);
        });
    };
    
    const handleSendMessage = async () => {
        if ((!newMessage.trim() && !imageFile && !gifUrl) || !selectedConvo) return;
        setIsSending(true);
        
        const imageUrl = imageFile ? await imageFileToBase64(imageFile) : null;
        
        try {
            await messageService.sendMessage(currentUser.id, selectedConvo.id, newMessage, imageUrl, gifUrl, false);
            
            // Refetch all messages to get the most up-to-date state from the "server"
            // This is more reliable than optimistic updates for the "seen by" feature
            await fetchMessages(selectedConvo.id, 1);
            setMessagePage(1); // Reset to page 1

            setNewMessage('');
            setImageFile(null);
            setGifUrl(null);
            onConversationsChange();

            setTimeout(() => {
                messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
            }, 100);

        } catch (error: any) {
            addNotification(error.message || "Hiba az üzenet küldésekor.", "error");
        } finally {
            setIsSending(false);
            setShowEmojiPicker(false);
            setShowGifPicker(false);
        }
    };

    const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        const file = e.target.files?.[0];
        if (file) {
            setGifUrl(null);
            setImageFile(file);
        }
    };

    const handleSelectGif = async (url: string) => {
        if (!selectedConvo) return;

        setImageFile(null);
        setShowGifPicker(false);
        
        setIsSending(true);
        try {
            await messageService.sendMessage(currentUser.id, selectedConvo.id, '', null, url, false);
            
            // Refetch all messages for consistency
            await fetchMessages(selectedConvo.id, 1);
            setMessagePage(1);
            
            setGifUrl(null);
            onConversationsChange();
            
            setTimeout(() => {
                messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
            }, 100);
        } catch (error: any) {
            addNotification(error.message || "Hiba a GIF küldésekor.", "error");
        } finally {
            setIsSending(false);
        }
    };

    const handleEmojiSelect = (emoji: string) => {
        const textarea = textareaRef.current;
        if (textarea) {
            const start = textarea.selectionStart;
            const end = textarea.selectionEnd;
            const newContent = newMessage.substring(0, start) + emoji + newMessage.substring(end);
            setNewMessage(newContent);
            setTimeout(() => {
                textarea.selectionStart = textarea.selectionEnd = start + emoji.length;
                textarea.focus();
            }, 0);
        }
    };
    
    const handleToggleReaction = async (messageId: string, reaction: string) => {
        if (!selectedConvo) return;
        try {
            const updatedMessage = await messageService.toggleMessageReaction(messageId, reaction, currentUser.id);
            setMessages(prev => prev.map(m => m.id === messageId ? updatedMessage : m));

            const message = messages.find(m => m.id === messageId);
            if (message && message.senderId !== currentUser.id) {
                const reactedMessages = currentUser.reactedMessagesForPoints || [];
                if (!reactedMessages.includes(messageId)) {
                    const updatedUser = {
                        ...currentUser,
                        points: currentUser.points + 2,
                        reactedMessagesForPoints: [...reactedMessages, messageId],
                        pointsHistory: [{ reason: 'Reakció egy üzenetre', points: 2, date: Date.now() }, ...(currentUser.pointsHistory || [])]
                    };
                    authService.updateUser(updatedUser);
                    onUserUpdate(updatedUser);
                    addNotification("Reakcióért 2 koronát kaptál!", "success");
                }
            }
        } catch (error) {
            addNotification("Hiba a reakció küldésekor.", "error");
        }
    };

    const handleSaveGroupImage = async (imageUrl: string) => {
        if (!selectedConvo) return;
        try {
            await messageService.updateGroupChatImage(selectedConvo.id, imageUrl);
            addNotification("Csoportkép sikeresen frissítve!", 'success');
            setShowImageEditor(false);
            await fetchConversations();
            // Also update the selected convo in state to reflect the change immediately
            setSelectedConvo(prev => prev ? { ...prev, imageUrl, avatarId: null } : null);
        } catch (error) {
            addNotification("Hiba a kép mentésekor.", "error");
        }
    };

    const handleAddUsers = async (userIds: string[]) => {
        if (!selectedConvo) return;
        try {
            await messageService.addUsersToGroup(selectedConvo.id, userIds, currentUser);
            addNotification('Tagok hozzáadva.', 'success');
            const updatedConvos = await messageService.getConversations(currentUser.id);
            setConversations(updatedConvos);
            const updatedSelectedConvo = updatedConvos.find(c => c.id === selectedConvo.id);
            if (updatedSelectedConvo) {
                setSelectedConvo(updatedSelectedConvo);
            }
            setShowAddUserModal(false);
            setShowParticipantsModal(true);
        } catch (e) {
            addNotification('Hiba a tagok hozzáadása során.', 'error');
        }
    };

    const handleRemoveUser = async (userId: string) => {
        if (!selectedConvo) return;
        if (window.confirm("Biztosan eltávolítod ezt a tagot?")) {
            try {
                await messageService.removeUserFromGroup(selectedConvo.id, userId, currentUser);
                addNotification('Tag eltávolítva.', 'success');
                const updatedConvos = await messageService.getConversations(currentUser.id);
                setConversations(updatedConvos);
                const updatedSelectedConvo = updatedConvos.find(c => c.id === selectedConvo.id);
                if (updatedSelectedConvo) {
                    setSelectedConvo(updatedSelectedConvo);
                } else {
                    setSelectedConvo(null); // Should not happen if I can't remove myself
                }
            } catch (e) {
                addNotification('Hiba a tag eltávolítása során.', 'error');
            }
        }
    };

    const handleRenameGroup = async (newName: string) => {
        if (!selectedConvo) return;
        try {
            await messageService.renameGroupConversation(selectedConvo.id, newName, currentUser);
            addNotification('Csoportnév frissítve!', 'success');
            setShowRenameModal(false);
            
            // Refresh all data
            const updatedConvos = await messageService.getConversations(currentUser.id);
            setConversations(updatedConvos);
            const updatedSelectedConvo = updatedConvos.find(c => c.id === selectedConvo.id);
            if (updatedSelectedConvo) {
                setSelectedConvo(updatedSelectedConvo);
            }
            // Also refresh messages to see the system message
            fetchMessages(selectedConvo.id, 1);
            setMessagePage(1);

        } catch (e) {
            addNotification('Hiba a csoport átnevezésekor.', 'error');
        }
    };

    const handleSetNickname = async (userId: string, nickname: string) => {
        if (!selectedConvo) return;
        try {
            await messageService.setNickname(selectedConvo.id, userId, nickname, currentUser);
            addNotification("Becenév beállítva!", 'success');
            // Refetch messages to get the system message and updated nicknames
            await fetchMessages(selectedConvo.id, 1);
            setMessagePage(1); // Reset page to get latest state
        } catch (e) {
            addNotification("Hiba a becenév beállításakor.", "error");
        }
    };


    const filteredConversations = useMemo(() => {
        if (!searchQuery.trim()) return conversations;
        const lowerCaseQuery = searchQuery.toLowerCase();
        return conversations.filter(convo => {
            const details = getConversationDetails(convo, currentUser);
            return details.name.toLowerCase().includes(lowerCaseQuery);
        });
    }, [searchQuery, conversations, currentUser]);

    const convoHeaderDetails = useMemo(() => {
        if (!selectedConvo) return { name: '', avatar: null };
        const details = getConversationDetails(selectedConvo, currentUser);
        let avatarComponent;
        
        if (details.imageUrl) {
            avatarComponent = <img src={details.imageUrl} alt={details.name} className="w-12 h-12 rounded-full object-cover bg-slate-700" />;
        } else if (details.isUser) {
            avatarComponent = <UserAvatarWithStatus user={details.user} />;
        } else {
            avatarComponent = <div className="w-12 h-12 rounded-full flex-shrink-0 bg-slate-700">{details.avatar}</div>;
        }
        return { name: details.name, avatar: avatarComponent };
    }, [selectedConvo, currentUser]);
    
    const lastSeenMarkers = useMemo(() => {
        if (!selectedConvo) return {};
        const markers: Record<number, User[]> = {}; // index -> users who saw up to this message
        const otherParticipants = selectedConvo.participants.filter(p => p.id !== currentUser.id);

        otherParticipants.forEach(p => {
            const seenTimestamp = lastSeenBy[p.id];
            if (seenTimestamp) {
                // Find the index of the last message this user has seen
                let lastSeenIndex = -1;
                for (let i = messages.length - 1; i >= 0; i--) {
                    if (messages[i].timestamp <= seenTimestamp) {
                        lastSeenIndex = i;
                        break;
                    }
                }
                if (lastSeenIndex !== -1) {
                    if (!markers[lastSeenIndex]) {
                        markers[lastSeenIndex] = [];
                    }
                    markers[lastSeenIndex].push(p);
                }
            }
        });
        return markers;
    }, [messages, lastSeenBy, selectedConvo, currentUser.id]);
    
    const handleGroupCreated = (newConversation: Conversation) => {
        setIsCreatingGroup(false);
        fetchConversations(); // Refresh the list
        handleSelectConvo(newConversation); // Navigate to the new chat
    };

    const canEditImage = useMemo(() => {
        if (!selectedConvo) return false;

        // The four main system group chats can be edited by any participant.
        const specialEditableSystemChats = [
            'system_group_chat',   // Csoportos
            'system_ultra_chat',   // Ultra
            'system_pro_chat',     // Pro
            'system_pro_max_chat'  // Pro Max
        ];

        if (specialEditableSystemChats.includes(selectedConvo.id)) {
            return true;
        }
    
        // User-created group chats can have their image edited (original logic)
        const isUserCreatedGroup = !!selectedConvo.name && !selectedConvo.isSystemConversation;
        
        // Other system chats (e.g. police bot DMs) can be edited by a Pro Max user (original logic)
        const isOtherSystemChatEditable = selectedConvo.isSystemConversation && currentUser.status === 'pro_max';
        
        return isUserCreatedGroup || isOtherSystemChatEditable;
    }, [selectedConvo, currentUser.status]);

    const canManageMembers = useMemo(() => {
        if (!selectedConvo) return false;
        // Not for system chats or 1-on-1s
        if (selectedConvo.isSystemConversation || !selectedConvo.name) return false;
        
        return currentUser.status === 'pro_max' || selectedConvo.createdBy === currentUser.id;
    }, [selectedConvo, currentUser]);

    const canRename = useMemo(() => {
        if (!selectedConvo) return false;
        // Allow renaming for any conversation that has a name (i.e., is a group chat).
        // This includes system chats and user-created groups.
        // It excludes 1-on-1 chats which don't have a name.
        return !!selectedConvo.name;
    }, [selectedConvo]);

    return (
        <div className="w-full flex-1 flex flex-col bg-[var(--component-bg)] md:rounded-2xl shadow-lg transition-colors duration-300 min-h-0">
             {selectedConvo ? (
                // Chat View
                <>
                    {/* Header */}
                    <div className="flex items-center p-3 border-b border-white/20 flex-shrink-0">
                        <button onClick={handleBackToList} className="p-2 mr-2 rounded-full hover:bg-white/10 md:hidden"><ArrowLeftIcon className="w-6 h-6 text-white"/></button>
                        {convoHeaderDetails.avatar}
                        <h2 className="ml-3 font-bold text-white text-lg">{convoHeaderDetails.name}</h2>
                        { !isReadOnlySystemChat && (
                            <div className="relative ml-auto">
                                <button onClick={() => setIsSettingsOpen(s => !s)} className="p-2 rounded-full hover:bg-white/10"><SettingsIcon className="w-6 h-6 text-white"/></button>
                                <ChatSettingsMenu 
                                    isOpen={isSettingsOpen} 
                                    onClose={() => setIsSettingsOpen(false)} 
                                    onMute={() => { setIsSettingsOpen(false); setShowMuteModal(true); }} 
                                    onViewParticipants={() => { setIsSettingsOpen(false); setShowParticipantsModal(true); }} 
                                    onSearch={() => { /* Implement search in convo */ setIsSettingsOpen(false); }} 
                                    onViewMedia={() => { setIsSettingsOpen(false); setShowMediaModal(true); }}
                                    onEditImage={() => { setIsSettingsOpen(false); setShowImageEditor(true); }}
                                    onRename={() => { setIsSettingsOpen(false); setShowRenameModal(true); }}
                                    isGroupChat={canEditImage}
                                    canRename={canRename}
                                />
                            </div>
                        )}
                    </div>
                    {/* Messages */}
                    <div ref={messageListRef} onScroll={handleScroll} className="flex-1 overflow-y-auto p-4 min-h-0">
                         {isLoadingMore && <p className="text-center text-xs text-white/70 py-2">Korábbi üzenetek betöltése...</p>}
                        <div className="flex flex-col gap-1">
                            {messages.map((msg, index) => {
                                const sender = authService.getUserById(msg.senderId);
                                const isThisGroupChat = selectedConvo.participants.length > 2 || selectedConvo.isSystemConversation;
                                const seenAvatars = lastSeenMarkers[index];

                                return (
                                    <React.Fragment key={msg.id}>
                                        {firstUnreadIndex === index && <div ref={unreadDividerRef} className="text-center text-xs text-orange-400 my-2 py-1 bg-slate-900/50 rounded-full w-fit mx-auto px-3">Új üzenetek</div>}
                                        <MessageBubble message={msg} currentUser={currentUser} sender={sender || null} onToggleReaction={handleToggleReaction} isReactionsDisabled={isReadOnlySystemChat} isGroupChat={isThisGroupChat} participants={selectedConvo.participants} nicknames={nicknames} />
                                        {seenAvatars && (
                                            <div className="flex justify-end items-center gap-1 mt-1 pr-2">
                                                {seenAvatars.map(user => (
                                                    <button key={user.id} onClick={(e) => handleAvatarClick(e, user, lastSeenBy[user.id])} className="focus:outline-none">
                                                        <UserAvatarWithStatus user={user} size="xx-small" showStatus={false} />
                                                    </button>
                                                ))}
                                            </div>
                                        )}
                                    </React.Fragment>
                                );
                            })}
                        </div>
                        <div ref={messagesEndRef} />
                    </div>

                    {/* Input */}
                    { !isReadOnlySystemChat && (
                        <div className="p-2 md:p-4 border-t border-white/20 flex-shrink-0 relative">
                            {showEmojiPicker && (
                                <>
                                <div className="fixed inset-0 z-40" onClick={() => setShowEmojiPicker(false)}></div>
                                <div className="absolute bottom-full right-4 mb-2 z-50">
                                    <EmojiPicker onSelectEmoji={handleEmojiSelect} />
                                </div>
                                </>
                            )}
                            {imageFile && (
                                <div className="mb-2 p-2 bg-slate-700/50 rounded-lg w-fit relative">
                                    <img src={URL.createObjectURL(imageFile)} alt="Preview" className="max-h-24 rounded"/>
                                    <button onClick={() => setImageFile(null)} className="absolute -top-1 -right-1 bg-black/70 rounded-full text-white"><XCircleIcon className="w-5 h-5"/></button>
                                </div>
                            )}
                            <div className="flex items-center gap-2 bg-slate-700/50 rounded-full p-1">
                                <textarea ref={textareaRef} value={newMessage} onChange={e => setNewMessage(e.target.value)} placeholder="Üzenet..." rows={1} className="flex-1 bg-transparent p-2 px-4 text-white placeholder:text-white/60 focus:outline-none resize-none"/>
                                <input type="file" ref={imageInputRef} onChange={handleFileChange} accept="image/*" className="hidden"/>
                                <button onClick={() => imageInputRef.current?.click()} className="p-2 text-white/70 hover:text-white"><ImageIcon className="w-6 h-6"/></button>
                                <button onClick={() => setShowGifPicker(true)} className="p-2 text-white/70 hover:text-white"><GifIcon className="w-6 h-6"/></button>
                                <button onClick={() => setShowEmojiPicker(s => !s)} className="p-2 text-white/70 hover:text-white"><EmojiIcon className="w-6 h-6"/></button>
                                <button onClick={handleSendMessage} disabled={isSending} className="p-2 bg-orange-600 text-white rounded-full disabled:bg-slate-500"><SendIcon className="w-6 h-6"/></button>
                            </div>
                        </div>
                    )}
                </>
            ) : isCreatingGroup ? (
                <CreateGroupChatPage 
                    currentUser={currentUser}
                    onClose={() => setIsCreatingGroup(false)}
                    onGroupCreated={handleGroupCreated}
                />
            ) : (
                // Conversation List View
                <>
                    <div className="p-4 border-b border-white/20 flex-shrink-0">
                        <h1 className="text-2xl font-bold font-lilita text-white">Üzenetek</h1>
                        <div className="relative mt-3 flex items-center gap-2">
                            <div className="relative flex-1">
                                <span className="absolute left-3 top-1/2 -translate-y-1/2"><SearchIcon className="w-5 h-5 text-slate-400"/></span>
                                <input type="text" placeholder="Keresés..." value={searchQuery} onChange={e => setSearchQuery(e.target.value)} className="w-full bg-slate-700/50 text-white pl-10 pr-4 py-2 rounded-full text-sm"/>
                            </div>
                            <button onClick={() => setIsCreatingGroup(true)} title="Új csoportos chat" className="p-2 bg-slate-700/50 rounded-full hover:bg-slate-600/50">
                                <PlusIcon className="w-6 h-6 text-white"/>
                            </button>
                        </div>
                    </div>
                    <div className="flex-1 overflow-y-auto min-h-0">
                        {isLoading ? <p className="text-center text-white/70 p-4">Betöltés...</p> : (
                            <ul>
                                {filteredConversations.map(convo => {
                                    const details = getConversationDetails(convo, currentUser);
                                    
                                    let lastMessageText = '...';
                                    if (convo.lastMessage) {
                                        const prefix = convo.lastMessage.senderId === currentUser.id ? "Te: " : "";
                                        let contentPreview = '';

                                        if (convo.lastMessage.content) {
                                            contentPreview = convo.lastMessage.content;
                                        } else if (convo.lastMessage.imageUrl) {
                                            contentPreview = 'Kép';
                                        } else if (convo.lastMessage.gifUrl) {
                                            contentPreview = 'GIF';
                                        }
                                        
                                        if (contentPreview) {
                                            const availableLength = 27 - prefix.length;
                                            if (contentPreview.length > availableLength) {
                                                lastMessageText = prefix + contentPreview.substring(0, availableLength) + '...';
                                            } else {
                                                lastMessageText = prefix + contentPreview;
                                            }
                                        }
                                    }

                                    return (
                                        <li key={convo.id}>
                                            <button onClick={() => handleSelectConvo(convo)} className="w-full flex items-start gap-3 p-3 text-left hover:bg-white/10 transition-colors">
                                                <div className="flex-shrink-0 pt-1">
                                                    {details.imageUrl ? (
                                                        <img src={details.imageUrl} alt={details.name} className="w-12 h-12 rounded-full object-cover bg-slate-700" />
                                                    ) : details.isUser ? (
                                                        <UserAvatarWithStatus user={details.user} />
                                                    ) : (
                                                        <div className="w-12 h-12 rounded-full bg-slate-700">
                                                            {details.avatar}
                                                        </div>
                                                    )}
                                                </div>
                                                <div className="flex-1 overflow-hidden">
                                                    <div className="flex justify-between items-center">
                                                        <p className="font-bold text-white truncate">{details.name}</p>
                                                        {convo.lastMessage && (
                                                            <p className="text-xs text-white/60 flex-shrink-0 ml-2">
                                                                {timeAgo(convo.lastMessage.timestamp)}
                                                            </p>
                                                        )}
                                                    </div>
                                                    <div className="flex justify-between items-start">
                                                        <p className="text-sm text-white/70 truncate pr-2">{lastMessageText}</p>
                                                        {convo.unreadCount > 0 && (
                                                            <span className="text-xs bg-red-600 text-white rounded-full h-5 w-5 flex items-center justify-center font-bold flex-shrink-0">
                                                                {convo.unreadCount}
                                                            </span>
                                                        )}
                                                    </div>
                                                </div>
                                            </button>
                                        </li>
                                    );
                                })}
                            </ul>
                        )}
                    </div>
                </>
            )}

            {/* Modals and Pickers */}
            {selectedConvo && <MuteChatModal isOpen={showMuteModal} onClose={() => setShowMuteModal(false)} conversationId={selectedConvo.id} />}
            {selectedConvo && <ChatParticipantsModal isOpen={showParticipantsModal} onClose={() => setShowParticipantsModal(false)} participants={selectedConvo.participants} currentUser={currentUser} canManageMembers={canManageMembers} createdBy={selectedConvo.createdBy} onAddUsersClick={() => { setShowParticipantsModal(false); setShowAddUserModal(true); }} onRemoveUser={handleRemoveUser} nicknames={nicknames} onSetNickname={handleSetNickname} />}
            {selectedConvo && <ChatMediaModal isOpen={showMediaModal} onClose={() => setShowMediaModal(false)} messages={messages} />}
            {showGifPicker && <GifPicker onSelectGif={handleSelectGif} onClose={() => setShowGifPicker(false)} />}
            {selectedConvo && <GroupImageEditorModal isOpen={showImageEditor} onClose={() => setShowImageEditor(false)} onSave={handleSaveGroupImage} />}
            <AddUserToGroupModal isOpen={showAddUserModal} onClose={() => setShowAddUserModal(false)} onAddUsers={handleAddUsers} existingParticipantIds={selectedConvo?.participants.map(p => p.id) || []} />
            {selectedConvo && <RenameGroupModal isOpen={showRenameModal} onClose={() => setShowRenameModal(false)} onSave={handleRenameGroup} currentName={selectedConvo.name || ''} />}
            {tooltip && (
                <div 
                    style={{ top: tooltip.top, left: tooltip.left }}
                    className="fixed bg-slate-900/80 backdrop-blur-sm text-white text-sm font-semibold px-3 py-2 rounded-lg shadow-2xl z-50 transform -translate-x-1/2 -translate-y-[calc(100%+4px)] animate-fade-in-up"
                >
                    {tooltip.content}
                </div>
            )}
        </div>
    );
};

export default MessagesPage;