import React, { useState, useEffect, useMemo } from 'react';
import type { User, MonthlyFavoriteVotes, FavoriteVote } from '../types';
import { authService } from '../services/authService';
import { favoriteVoteService } from '../services/favoriteVoteService';
import { useNotification } from '../contexts/NotificationContext';
import UserAvatarWithStatus from './UserAvatarWithStatus';
import GoldCrownIcon from './icons/GoldCrownIcon';

const FavoriteEmployeePage: React.FC<{ currentUser: User }> = ({ currentUser }) => {
    const [allUsers, setAllUsers] = useState<User[]>([]);
    const [monthlyVotes, setMonthlyVotes] = useState<MonthlyFavoriteVotes | null>(null);
    const [previousMonthVotes, setPreviousMonthVotes] = useState<MonthlyFavoriteVotes | null>(null);
    const [isLoading, setIsLoading] = useState(true);
    const [selections, setSelections] = useState<Record<FavoriteVote['category'], string>>({
        normal: '',
        pro: '',
        pro_max: '',
    });

    const { addNotification } = useNotification();

    const now = useMemo(() => new Date(), []);

    const { monthId, votingDeadline, resultsVisibleStart, resultsVisibleEnd, previousMonthId } = useMemo(() => {
        const year = now.getFullYear();
        const month = now.getMonth();
        const id = now.toISOString().slice(0, 7);

        const prevMonthDate = new Date(year, month - 1, 1);
        const prevId = prevMonthDate.toISOString().slice(0, 7);

        const deadline = new Date(year, month + 1, 0, 23, 59, 59, 999);
        const start = new Date(year, month + 1, 1);
        const end = new Date(year, month + 1, 10, 23, 59, 59, 999);

        return { monthId: id, votingDeadline: deadline, resultsVisibleStart: start, resultsVisibleEnd: end, previousMonthId: prevId };
    }, [now]);

    useEffect(() => {
        const fetchData = async () => {
            setIsLoading(true);
            try {
                const [usersData, currentVotesData, prevVotesData] = await Promise.all([
                    authService.getAllUsers(),
                    favoriteVoteService.getVotesForMonth(monthId),
                    favoriteVoteService.getVotesForMonth(previousMonthId),
                ]);

                const approvedUsers = usersData.filter(u => u.approved && u.status !== 'admin');
                setAllUsers(approvedUsers);
                setMonthlyVotes(currentVotesData);
                setPreviousMonthVotes(prevVotesData);

                if (now >= resultsVisibleStart && now <= resultsVisibleEnd && currentVotesData && !currentVotesData.notificationsSent) {
                    await favoriteVoteService.sendWinnerNotifications(monthId, usersData);
                    const updatedVotesData = await favoriteVoteService.getVotesForMonth(monthId);
                    setMonthlyVotes(updatedVotesData);
                }
            } catch (error) {
                addNotification("Hiba az adatok betöltésekor.", "error");
            } finally {
                setIsLoading(false);
            }
        };
        fetchData();
    }, [monthId, previousMonthId, resultsVisibleStart, resultsVisibleEnd, now, addNotification]);

    const userVotes = useMemo(() => {
        const votes: Record<string, string> = {};
        if (monthlyVotes && Array.isArray(monthlyVotes.votes)) {
            monthlyVotes.votes.forEach(vote => {
                if (vote && vote.voterId === currentUser.id) {
                    votes[vote.category] = vote.votedForId;
                }
            });
        }
        return votes;
    }, [monthlyVotes, currentUser.id]);

    const categories: { key: FavoriteVote['category'], label: string }[] = [
        { key: 'normal', label: 'Kedvenc Kolléga' },
        { key: 'pro', label: 'Kedvenc Kisvezető' },
        { key: 'pro_max', label: 'Kedvenc Manager' },
    ];

    const candidates = useMemo(() => ({
        normal: allUsers.filter(u => u.status === 'normal' && u.id !== currentUser.id),
        pro: allUsers.filter(u => u.status === 'pro' && u.id !== currentUser.id),
        pro_max: allUsers.filter(u => u.status === 'pro_max' && u.id !== currentUser.id),
    }), [allUsers, currentUser.id]);

    const calculateResults = (votesData: MonthlyFavoriteVotes | null) => {
        if (!votesData || !Array.isArray(votesData.votes)) {
            return null;
        }
        const results: Record<string, { winnerId: string; voteCounts: Record<string, number> }> = {};
        categories.forEach(({ key }) => {
            const votesForCategory = votesData.votes.filter(v => v && v.category === key);
            if (votesForCategory.length === 0) return;

            const voteCounts = votesForCategory.reduce((acc, vote) => {
                acc[vote.votedForId] = (acc[vote.votedForId] || 0) + 1;
                return acc;
            }, {} as Record<string, number>);

            if (Object.keys(voteCounts).length > 0) {
                const winnerId = Object.keys(voteCounts).reduce((a, b) => voteCounts[a] > voteCounts[b] ? a : b);
                results[key] = { winnerId, voteCounts };
            }
        });
        return results;
    };
    
    const voteResults = useMemo(() => calculateResults(monthlyVotes), [monthlyVotes]);
    const previousMonthResults = useMemo(() => calculateResults(previousMonthVotes), [previousMonthVotes]);
    
    const handleSelectionChange = (category: FavoriteVote['category'], userId: string) => {
        setSelections(prev => ({ ...prev, [category]: userId }));
    };

    const handleBulkSubmit = async () => {
        setIsLoading(true);
        try {
            const votesToCast = Object.entries(selections)
                .filter(([, userId]) => userId) // Filter out empty selections
                .map(([category, userId]) => 
                    favoriteVoteService.castVote(currentUser.id, category as FavoriteVote['category'], userId)
                );

            if (votesToCast.length === 0) {
                addNotification('Válassz ki legalább egy személyt a szavazáshoz.', 'info');
                setIsLoading(false);
                return;
            }

            await Promise.all(votesToCast);
            
            addNotification('Szavazataidat rögzítettük!', 'success');
            
            const votesData = await favoriteVoteService.getVotesForMonth(monthId);
            setMonthlyVotes(votesData);
            setSelections({ normal: '', pro: '', pro_max: '' });
            
        } catch (error) {
            // FIX: Handle unknown error types safely in catch block to prevent runtime errors
            // and satisfy stricter TypeScript rules that treat caught errors as `unknown`.
            const message = error instanceof Error ? error.message : 'Hiba a szavazás során.';
            addNotification(message, 'error');
        } finally {
            setIsLoading(false);
        }
    };

    const WinnerDisplay: React.FC<{ winnerId: string | undefined; categoryLabel: string }> = ({ winnerId, categoryLabel }) => {
        const winner = winnerId ? allUsers.find(u => u.id === winnerId) : null;
    
        if (!winner) {
            return (
                <div className="flex flex-col items-center text-center p-4">
                    <div className="relative w-24 h-24 mb-2">
                        <div className="w-full h-full rounded-full bg-slate-700 flex items-center justify-center">
                            <GoldCrownIcon className="w-16 h-16 text-slate-500 opacity-50" />
                        </div>
                    </div>
                    <p className="font-bold text-lg text-white/70">{categoryLabel}</p>
                    <p className="text-sm text-white/50 italic">Nem volt szavazat</p>
                </div>
            );
        }
    
        return (
            <div className="flex flex-col items-center text-center p-4">
                <div className="relative w-24 h-24 mb-2">
                    <UserAvatarWithStatus user={winner} size="large" showStatus={false} />
                    <GoldCrownIcon className="absolute -top-2 -left-2 w-12 h-12 transform -rotate-12" />
                </div>
                <p className="font-bold text-2xl text-orange-300">{winner.name}</p>
                <p className="font-semibold text-white/80 text-center text-sm">{categoryLabel}</p>
            </div>
        );
    };

    const isVotingOpen = now < votingDeadline;
    const isResultsVisible = now >= resultsVisibleStart && now <= resultsVisibleEnd;

    const renderCurrentMonthContent = () => {
        if (isLoading) {
            return <p className="text-center">Betöltés...</p>;
        }

        if (isVotingOpen) {
            const hasVoted = Object.keys(userVotes).length > 0;

            if (hasVoted) {
                return (
                    <div className="space-y-4">
                        <h3 className="text-xl font-bold font-lilita text-center">Ebben a hónapban már szavaztál.</h3>
                        {categories.map(cat => {
                            const votedForId = userVotes[cat.key];
                            const votedForUser = votedForId ? allUsers.find(u => u.id === votedForId) : null;
                            if (votedForUser) {
                                return (
                                    <div key={cat.key} className="bg-slate-900/40 p-4 rounded-lg text-center">
                                        <h3 className="font-bold text-lg text-white/90">{cat.label}</h3>
                                        <p className="font-bold text-orange-400 text-xl mt-1">{votedForUser.name}</p>
                                    </div>
                                );
                            }
                            return null;
                        })}
                    </div>
                );
            }

            return (
                <div className="space-y-4">
                    {categories.map(cat => {
                        const options = candidates[cat.key];
                        if (options.length === 0) {
                            return (
                                <div key={cat.key} className="bg-slate-900/40 p-4 rounded-lg text-center">
                                    <h3 className="font-bold text-lg text-white/90">{cat.label}</h3>
                                    <p className="text-sm text-white/70 mt-2">Nincs jelölt ebben a kategóriában.</p>
                                </div>
                            );
                        }
                        return (
                            <div key={cat.key} className="bg-slate-900/40 p-4 rounded-lg">
                                <label htmlFor={`vote-select-${cat.key}`} className="font-bold text-lg text-white/90 mb-3 block">{cat.label}</label>
                                <select
                                    id={`vote-select-${cat.key}`}
                                    value={selections[cat.key]}
                                    onChange={e => handleSelectionChange(cat.key, e.target.value)}
                                    className="w-full bg-slate-700 text-white p-3 rounded-lg"
                                >
                                    <option value="">-- Válassz --</option>
                                    {options.map(u => <option key={u.id} value={u.id}>{u.name}</option>)}
                                </select>
                            </div>
                        );
                    })}
                    
                    <button
                        onClick={handleBulkSubmit}
                        disabled={isLoading || Object.values(selections).every(s => s === '')}
                        className="w-full mt-4 px-6 py-3 bg-orange-600 font-bold rounded-lg text-lg shadow-lg disabled:bg-slate-500 disabled:cursor-not-allowed"
                    >
                        Szavazatok Elküldése
                    </button>
                </div>
            );
        }

        if (isResultsVisible) {
            return <ResultsSection />;
        }
        
        return <p className="text-center p-4">A szavazás erre a hónapra lezárult. Az eredmények {resultsVisibleStart.toLocaleDateString('hu-HU', {month: 'long', day: 'numeric'})}-től lesznek láthatóak.</p>;
    };

    const ResultsSection = () => {
        if (!voteResults && !monthlyVotes) {
            return <p className="text-center text-white/70">Nincs megjeleníthető eredmény ebben a hónapban.</p>;
        }

        return (
            <div className="space-y-6">
                {categories.map(({ key, label }) => {
                    const result = voteResults?.[key];
                     return (
                        <div key={key} className="bg-slate-900/40 p-4 rounded-lg">
                            <WinnerDisplay winnerId={result?.winnerId} categoryLabel={label} />
                            
                            {currentUser.status === 'pro_max' && result && (
                                <details className="mt-4">
                                    <summary className="cursor-pointer text-sm text-white/70 font-semibold">Részletes eredmények (anonim)</summary>
                                    <ul className="mt-2 space-y-1 text-sm">
                                        {Object.entries(result.voteCounts).sort((a, b) => Number(b[1]) - Number(a[1])).map(([userId, count]) => {
                                            const user = allUsers.find(u => u.id === userId);
                                            return <li key={userId} className="flex justify-between p-1 bg-slate-800/50 rounded"><span>{user?.name || 'Ismeretlen'}</span> <span className="font-bold">{count} szavazat</span></li>
                                        })}
                                    </ul>
                                </details>
                            )}
                        </div>
                    );
                })}
            </div>
        );
    };

    const PreviousMonthWinners = () => {
        const prevMonthDate = new Date(now.getFullYear(), now.getMonth() - 1, 1);

        if (isLoading || !previousMonthResults || Object.keys(previousMonthResults).length === 0) {
            return null;
        }
        
        return (
            <div className="bg-slate-800/40 backdrop-blur-sm p-6 rounded-2xl shadow-lg">
                <h2 className="text-2xl font-bold font-lilita capitalize text-center mb-4">
                    {prevMonthDate.toLocaleString('hu-HU', { month: 'long', year: 'numeric' })} Győztesei
                </h2>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                     {categories.map(({ key, label }) => {
                        const winnerId = previousMonthResults?.[key]?.winnerId;
                        return <WinnerDisplay key={key} winnerId={winnerId} categoryLabel={label} />;
                    })}
                </div>
            </div>
        );
    };
    
    return (
        <div className="w-full max-w-2xl mx-auto animate-fade-in space-y-6 text-white">
            <h1 className="text-3xl sm:text-4xl font-bold font-lilita tracking-wide text-center">Havi kedvenc</h1>
            <div className="bg-slate-800/40 backdrop-blur-sm p-6 rounded-2xl shadow-lg">
                <p className="text-center text-sm text-white/80 border-b border-white/10 pb-4 mb-4">
                    Szavazni a hónap végéig lehet. Az eredmények a következő hónap 1. és 10. között kerülnek kihirdetésre.
                </p>
                {renderCurrentMonthContent()}
            </div>
            <PreviousMonthWinners />
        </div>
    );
};

export default FavoriteEmployeePage;
