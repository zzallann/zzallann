import React, { useState, useEffect, useMemo } from 'react';
import type { User, MonthAward, AwardWinner, Event } from '../types';
import { awardsService } from '../services/awardsService';
import { authService } from '../services/authService';
import { messageService } from '../services/messageService';
import { useNotification } from '../contexts/NotificationContext';
import { avatars } from './AvatarSelector';
import ChevronLeftIcon from './icons/ChevronLeftIcon';
import ChevronRightIcon from './icons/ChevronRightIcon';
import GoldCrownIcon from './icons/GoldCrownIcon';
import SilverCrownIcon from './icons/SilverCrownIcon';
import BronzeCrownIcon from './icons/BronzeCrownIcon';
import EditIcon from './icons/EditIcon';
import SendIcon from './icons/SendIcon';
import TrashIcon from './icons/TrashIcon';
import PlusIcon from './icons/PlusIcon';
import BurglarIcon from './icons/BurglarIcon';

const awardCategories: { key: AwardWinner['category']; label: string; rank: 1 | 2 | 3 }[] = [
    { key: 'dolgozo_1', label: '1. Hónap Dolgozója', rank: 1 },
    { key: 'konyhas_2', label: '2. Hónap Konyhása', rank: 2 },
    { key: 'kasszas_2', label: '2. Hónap Kasszása', rank: 2 },
    { key: 'kk_3', label: '3. KK Választott', rank: 3 },
];

const quarterlyAwardCategory = { key: 'negyedev_dolgozoja' as const, label: 'Negyedév Dolgozója', rank: 1 as const };


const imageFileToBase64 = (file: File): Promise<string> => {
    return new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.readAsDataURL(file);
        reader.onload = event => {
            if (!event.target?.result) {
                return reject(new Error("FileReader did not return a result."));
            }
            const img = new Image();
            img.src = event.target.result as string;
            img.onload = () => {
                const canvas = document.createElement('canvas');
                const MAX_WIDTH = 800;
                const MAX_HEIGHT = 800;
                let width = img.width;
                let height = img.height;

                if (width > height) {
                    if (width > MAX_WIDTH) {
                        height *= MAX_WIDTH / width;
                        width = MAX_WIDTH;
                    }
                } else {
                    if (height > MAX_HEIGHT) {
                        width *= MAX_HEIGHT / height;
                        height = MAX_HEIGHT;
                    }
                }

                canvas.width = width;
                canvas.height = height;
                const ctx = canvas.getContext('2d');
                if (!ctx) {
                    return reject(new Error('Could not get canvas context'));
                }
                ctx.drawImage(img, 0, 0, width, height);
                
                // Convert to JPEG for smaller file size. Quality 0.9 is a good balance.
                resolve(canvas.toDataURL('image/jpeg', 0.9));
            };
            img.onerror = error => reject(error);
        };
        reader.onerror = error => reject(error);
    });
};

const AwardsPage: React.FC<{ currentUser: User }> = ({ currentUser }) => {
    const [currentDate, setCurrentDate] = useState(new Date());
    const [monthAwards, setMonthAwards] = useState<MonthAward | null>(null);
    const [events, setEvents] = useState<Event[]>([]);
    const [allUsers, setAllUsers] = useState<User[]>([]);
    const [isLoading, setIsLoading] = useState(true);
    const [isEditMode, setIsEditMode] = useState(false);
    
    // Edit state for Pro Max
    const [editableWinners, setEditableWinners] = useState<Record<string, string>>({});
    const [isSaving, setIsSaving] = useState(false);
    const [showEventForm, setShowEventForm] = useState(false);
    const [editingEvent, setEditingEvent] = useState<Event | null>(null);

    const { addNotification } = useNotification();
    const monthId = `${currentDate.getFullYear()}-${String(currentDate.getMonth() + 1).padStart(2, '0')}`;
    const isQuarterlyMonth = useMemo(() => [0, 3, 6, 9].includes(currentDate.getMonth()), [currentDate]);

    // Navigation date limits
    const today = useMemo(() => new Date(), []);
    const minDate = useMemo(() => {
        const date = new Date(today.getFullYear(), today.getMonth() - 5, 1);
        return date;
    }, [today]);
    const maxDate = useMemo(() => {
        const date = new Date(today.getFullYear(), today.getMonth() + 3, 1);
        return date;
    }, [today]);

    const isPrevDisabled = currentDate.getFullYear() < minDate.getFullYear() ||
                           (currentDate.getFullYear() === minDate.getFullYear() && currentDate.getMonth() <= minDate.getMonth());
    const isNextDisabled = currentDate.getFullYear() > maxDate.getFullYear() ||
                           (currentDate.getFullYear() === maxDate.getFullYear() && currentDate.getMonth() >= maxDate.getMonth());


    const fetchData = async () => {
        setIsLoading(true);
        try {
            const [awards, eventsData, usersData] = await Promise.all([
                awardsService.getAwardsForMonth(monthId),
                awardsService.getEvents(),
                authService.getAllUsers()
            ]);
            setMonthAwards(awards);
            setEvents(eventsData.filter(e => e.date >= new Date().setHours(0,0,0,0)));
            setAllUsers(usersData);
            
            const initialWinners: Record<string, string> = {};
            if(awards) {
                awards.winners.forEach(w => initialWinners[w.category] = w.userId);
            }
            setEditableWinners(initialWinners);

        } catch (error) {
            addNotification("Hiba az adatok betöltésekor.", "error");
        } finally {
            setIsLoading(false);
        }
    };

    useEffect(() => {
        fetchData();
    }, [monthId]);

    const handleMonthChange = (direction: 'prev' | 'next') => {
        setCurrentDate(prev => {
            const newDate = new Date(prev);
            newDate.setMonth(newDate.getMonth() + (direction === 'prev' ? -1 : 1));
            return newDate;
        });
    };

    const handleSaveAwards = async () => {
        setIsSaving(true);
        const oldWinnersMap = new Map(monthAwards?.winners.map(w => [w.category, w.userId]));
        
        const winners: AwardWinner[] = Object.entries(editableWinners)
            .filter(([, userId]) => userId)
            .map(([category, userId]) => ({ category: category as AwardWinner['category'], userId: userId as string }));

        try {
            await awardsService.saveMonthAwards(monthId, winners, false);

            const allCategories = [...awardCategories, quarterlyAwardCategory];
            winners.forEach(newWinner => {
                const oldWinnerId = oldWinnersMap.get(newWinner.category);
                if (newWinner.userId && newWinner.userId !== oldWinnerId) {
                    const categoryLabel = allCategories.find(c => c.key === newWinner.category)?.label || 'díjra';
                    messageService.sendNominationNotification(newWinner.userId, categoryLabel);
                }
            });

            addNotification('Díjazottak sikeresen mentve!', 'success');
            setIsEditMode(false);
            fetchData();
        } catch (error) {
            addNotification('Hiba mentés közben.', 'error');
        } finally {
            setIsSaving(false);
        }
    };
    
    const handlePublishAwards = async () => {
        if (!monthAwards || monthAwards.winners.length === 0) {
            addNotification('Nincsenek díjazottak ebben a hónapban a közzétételhez.', 'error');
            return;
        }
        setIsSaving(true);
        try {
            await awardsService.saveMonthAwards(monthId, monthAwards.winners, true);
            const monthFormatted = currentDate.toLocaleString('hu-HU', { month: 'long', year: 'numeric' });
            await messageService.sendAwardsNotification(currentUser.name, monthFormatted);
            addNotification('Eredmények közzétéve és értesítés elküldve!', 'success');
            fetchData(); // Refresh to show published state
        } catch (error) {
            addNotification('Hiba a közzététel során.', 'error');
        } finally {
            setIsSaving(false);
        }
    };
    
    const usersById = useMemo(() => new Map(allUsers.map(u => [u.id, u])), [allUsers]);

    const renderWinner = (category: AwardWinner['category'], rank: number) => {
        const winner = monthAwards?.winners.find(w => w.category === category);
        const user = winner ? usersById.get(winner.userId) : null;
        const Crown = rank === 1 ? GoldCrownIcon : rank === 2 ? SilverCrownIcon : BronzeCrownIcon;

        if (isEditMode) {
            return (
                <select 
                    value={editableWinners[category] || ''}
                    onChange={e => setEditableWinners(p => ({ ...p, [category]: e.target.value }))}
                    className="w-full bg-slate-700 text-white p-2 rounded-lg"
                >
                    <option value="">-- Nincs kiválasztva --</option>
                    {allUsers.map(u => <option key={u.id} value={u.id}>{u.name}</option>)}
                </select>
            );
        }

        if (!user) {
            return (
                <div className="flex flex-col items-center text-center">
                    <div className="relative w-20 h-20 mb-2">
                        <div className="w-full h-full rounded-full overflow-hidden bg-slate-700 p-2">
                            <BurglarIcon />
                        </div>
                    </div>
                    <p className="font-bold text-white/70 italic text-sm">Még ez titkos</p>
                </div>
            );
        }
        
        const avatar = avatars.find(a => a.id === user.avatarId);
        return (
            <div className="flex flex-col items-center text-center">
                 <div className="relative w-20 h-20 mb-2">
                    <div className="w-full h-full rounded-full overflow-hidden bg-slate-700">
                       {user.uploadedImage ? <img src={user.uploadedImage} alt={user.name} className="w-full h-full object-cover"/> : avatar ? <avatar.component/> : null}
                    </div>
                    <Crown className="absolute -top-2 -left-2 w-10 h-10 transform -rotate-12"/>
                </div>
                <p className="font-bold text-white">{user.name}</p>
            </div>
        )
    };
    
    const EventForm = ({ event, onDone }: { event: Event | null, onDone: () => void }) => {
        const [title, setTitle] = useState(event?.title || '');
        const [description, setDescription] = useState(event?.description || '');
        const [date, setDate] = useState(event ? new Date(event.date).toISOString().split('T')[0] : '');
        const [image, setImage] = useState<File | null>(null);

        const handleSave = async (e: React.FormEvent) => {
            e.preventDefault();
            setIsSaving(true);
            const imageUrl = image ? await imageFileToBase64(image) : (event?.imageUrl || null);
            try {
                await awardsService.saveEvent({
                    title, description, date: new Date(date).getTime(), imageUrl, createdBy: currentUser.id
                }, event?.id);
                addNotification('Esemény mentve!', 'success');
                onDone();
            } catch (err) {
                addNotification('Hiba az esemény mentésekor.', 'error');
            } finally {
                setIsSaving(false);
            }
        };

        return (
             <form onSubmit={handleSave} className="p-4 bg-slate-900/50 rounded-lg space-y-3 my-4">
                <h3 className="font-bold text-lg">{event ? 'Esemény szerkesztése' : 'Új esemény'}</h3>
                <input type="text" placeholder="Cím" value={title} onChange={e => setTitle(e.target.value)} required className="w-full bg-slate-700 p-2 rounded"/>
                <textarea placeholder="Leírás" value={description} onChange={e => setDescription(e.target.value)} className="w-full bg-slate-700 p-2 rounded" rows={3}/>
                <input type="date" value={date} onChange={e => setDate(e.target.value)} required className="w-full bg-slate-700 p-2 rounded"/>
                <input type="file" accept="image/*" onChange={e => setImage(e.target.files?.[0] || null)} className="w-full text-sm file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-sm file:font-semibold file:bg-orange-50 file:text-orange-700 hover:file:bg-orange-100"/>
                <div className="flex gap-2">
                    <button type="submit" disabled={isSaving} className="px-4 py-2 bg-orange-600 rounded-full font-bold disabled:bg-slate-500">{isSaving ? 'Mentés...' : 'Mentés'}</button>
                    <button type="button" onClick={onDone} className="px-4 py-2 bg-slate-600 rounded-full">Mégse</button>
                </div>
             </form>
        );
    };

    return (
        <div className="w-full max-w-2xl mx-auto animate-fade-in space-y-8 text-white">
            <h1 className="text-3xl sm:text-4xl font-bold font-lilita tracking-wide text-center">Díjazottak, programok</h1>

            {/* Awards Section */}
            <div className="bg-slate-800/40 backdrop-blur-sm p-6 rounded-2xl shadow-lg">
                <div className="flex justify-between items-center mb-4">
                    <button onClick={() => handleMonthChange('prev')} disabled={isPrevDisabled} className="disabled:opacity-30 disabled:cursor-not-allowed transition-opacity">
                        <ChevronLeftIcon className="w-8 h-8"/>
                    </button>
                    <h2 className="text-2xl font-bold font-lilita capitalize">{currentDate.toLocaleString('hu-HU', { month: 'long', year: 'numeric' })}</h2>
                    <button onClick={() => handleMonthChange('next')} disabled={isNextDisabled} className="disabled:opacity-30 disabled:cursor-not-allowed transition-opacity">
                        <ChevronRightIcon className="w-8 h-8"/>
                    </button>
                </div>
                
                {isLoading ? <p>Töltés...</p> : (
                    <>
                        {isQuarterlyMonth && (
                            <div className="mb-8 p-4 bg-gradient-to-r from-amber-500 to-yellow-400 rounded-lg text-center shadow-lg">
                                <h3 className="text-xl font-bold text-slate-800 mb-2">{quarterlyAwardCategory.label}</h3>
                                {renderWinner(quarterlyAwardCategory.key, quarterlyAwardCategory.rank)}
                            </div>
                        )}
                        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                            {awardCategories.map(cat => (
                                <div key={cat.key} className="flex flex-col items-center">
                                    <h3 className="font-semibold text-white/80 text-center text-sm mb-2">{cat.label}</h3>
                                    {renderWinner(cat.key, cat.rank)}
                                </div>
                            ))}
                        </div>
                        {currentUser.status === 'pro_max' && (
                            <div className="mt-6 pt-4 border-t border-white/20 flex flex-col sm:flex-row gap-3 justify-center">
                                {isEditMode ? (
                                    <>
                                        <button onClick={handleSaveAwards} disabled={isSaving} className="px-4 py-2 bg-green-600 rounded-full font-bold">{isSaving ? 'Mentés...' : 'Mentés'}</button>
                                        <button onClick={() => setIsEditMode(false)} className="px-4 py-2 bg-slate-600 rounded-full">Mégse</button>
                                    </>
                                ) : (
                                    <>
                                        <button onClick={() => setIsEditMode(true)} className="flex items-center gap-2 px-4 py-2 bg-blue-600 rounded-full font-bold"><EditIcon className="w-5 h-5"/> Szerkesztés</button>
                                        <button onClick={handlePublishAwards} disabled={isSaving || monthAwards?.published || !monthAwards || monthAwards.winners.length === 0} className="flex items-center gap-2 px-4 py-2 bg-orange-600 rounded-full font-bold disabled:bg-slate-500">
                                           {isSaving ? 'Küldés...' : monthAwards?.published ? 'Közzétéve' : <><SendIcon className="w-5 h-5"/>Értesítés küldése</>}
                                        </button>
                                    </>
                                )}
                            </div>
                        )}
                    </>
                )}
            </div>
            
             {/* Events Section */}
            <div className="bg-slate-800/40 backdrop-blur-sm p-6 rounded-2xl shadow-lg">
                <div className="flex justify-between items-center mb-4">
                    <h2 className="text-2xl font-bold font-lilita">Programok</h2>
                     {currentUser.status === 'pro_max' && !showEventForm && (
                        <button onClick={() => { setEditingEvent(null); setShowEventForm(true); }} className="flex items-center gap-2 px-4 py-2 bg-green-600 rounded-full font-bold"><PlusIcon className="w-5 h-5"/> Új Esemény</button>
                    )}
                </div>
                {currentUser.status === 'pro_max' && showEventForm && <EventForm event={editingEvent} onDone={() => { setShowEventForm(false); setEditingEvent(null); fetchData(); }}/>}
                
                {isLoading ? <p>Töltés...</p> : events.length > 0 ? (
                    <div className="space-y-4 max-h-96 overflow-y-auto">
                        {events.map(event => (
                            <div key={event.id} className="bg-slate-900/40 p-4 rounded-lg flex flex-col md:flex-row gap-4">
                                {event.imageUrl && <img src={event.imageUrl} alt={event.title} className="w-full md:w-32 h-32 object-cover rounded-md"/>}
                                <div className="flex-1">
                                    <h3 className="font-bold text-lg">{event.title}</h3>
                                    <p className="text-sm text-amber-300 font-semibold mb-1">{new Date(event.date).toLocaleDateString('hu-HU', { year: 'numeric', month: 'long', day: 'numeric'})}</p>
                                    <p className="text-sm text-white/80 whitespace-pre-wrap">{event.description}</p>
                                    {currentUser.status === 'pro_max' && (
                                        <div className="flex gap-2 mt-3">
                                            <button onClick={() => { setEditingEvent(event); setShowEventForm(true); }} className="p-2 text-white/70 hover:text-white"><EditIcon className="w-5 h-5"/></button>
                                            <button onClick={async () => { await awardsService.deleteEvent(event.id); fetchData(); }} className="p-2 text-red-400 hover:text-red-300"><TrashIcon className="w-5 h-5"/></button>
                                        </div>
                                    )}
                                </div>
                            </div>
                        ))}
                    </div>
                ) : (
                    <div className="text-center p-4">
                        <img 
                            src="https://media0.giphy.com/media/v1.Y2lkPTc5MGI3NjExOHhzeGQydGYzdzYyOTY2eTQ3dWFveWdkNWFzbDluMDI2bnNpM3E5MCZlcD12MV9pbnRlcm5hbF9naWZfYnlfaWQmY3Q9Zw/owUYz2BwcUaF5Ot5Cp/giphy.gif" 
                            alt="Hamarosan" 
                            className="mx-auto rounded-lg w-48 h-48 object-cover" 
                        />
                        <h3 className="mt-4 text-2xl font-bold font-lilita text-white/80 tracking-wider">HAMAROSAN</h3>
                    </div>
                )}
            </div>
        </div>
    );
};

export default AwardsPage;