import React, { useState, useEffect } from 'react';
import type { User, AssignedTask } from '../types';
import CheckCircleIcon from './icons/CheckCircleIcon';
import HourglassIcon from './icons/HourglassIcon';
import XCircleIcon from './icons/XCircleIcon';
import EditIcon from './icons/EditIcon';
import WarningIcon from './icons/WarningIcon';
import { taskService } from '../services/taskService';
import { authService } from '../services/authService';
import { useNotification } from '../contexts/NotificationContext';
import SendIcon from './icons/SendIcon';
import TrashIcon from './icons/TrashIcon';
import EditTaskModal from './EditTaskModal';
import FolderIcon from './icons/FolderIcon';
import DeleteTaskModal from './DeleteTaskModal';
import TaskDetailModal from './TaskDetailModal';


interface OktatasomPageProps {
    user: User;
    onNavigate: (view: string) => void;
    onRefreshTaskCount: () => void;
}

const getOneWeekFromToday = () => {
    const today = new Date();
    const oneWeekFromNow = new Date(today.setDate(today.getDate() + 7));
    return oneWeekFromNow.toISOString().split('T')[0]; // Format YYYY-MM-DD
};

interface TaskCreationFormProps {
    usersToList: User[];
    assigner: User;
    onTaskCreated: () => void;
}

const TaskCreationForm: React.FC<TaskCreationFormProps> = ({ usersToList, assigner, onTaskCreated }) => {
    const [description, setDescription] = useState('');
    const [assignedTo, setAssignedTo] = useState<string[]>([]);
    const [deadline, setDeadline] = useState(getOneWeekFromToday());
    const [isSubmitting, setIsSubmitting] = useState(false);
    const { addNotification } = useNotification();

    const handleAssigneeToggle = (userId: string) => {
        setAssignedTo(prev =>
            prev.includes(userId)
                ? prev.filter(id => id !== userId)
                : [...prev, userId]
        );
    };
    
    const handleGroupSelect = (status: User['status'] | 'all') => {
        let userIdsToSelect: string[] = [];
        if (status === 'all') {
            userIdsToSelect = usersToList.map(u => u.id);
        } else {
            userIdsToSelect = usersToList.filter(u => u.status === status).map(u => u.id);
        }

        // If all are already selected, deselect them. Otherwise, select them.
        const allSelected = userIdsToSelect.every(id => assignedTo.includes(id));

        if (allSelected && userIdsToSelect.length > 0) {
            setAssignedTo(prev => prev.filter(id => !userIdsToSelect.includes(id)));
        } else {
            setAssignedTo(prev => [...new Set([...prev, ...userIdsToSelect])]);
        }
    };


    const handleCreateTask = async (e: React.FormEvent) => {
        e.preventDefault();
        if (!description.trim() || assignedTo.length === 0 || !deadline) {
            addNotification("A leírást ki kell tölteni és legalább egy személyt ki kell választani.", "error");
            return;
        }
        setIsSubmitting(true);
        try {
            const deadlineDate = new Date(deadline);
            deadlineDate.setHours(23, 59, 59);

            const taskPromises = assignedTo.map(userId =>
                taskService.createTask(description, userId, deadlineDate.getTime(), assigner)
            );

            await Promise.all(taskPromises);

            addNotification("Feladatok sikeresen létrehozva!", "success");
            setDescription('');
            setAssignedTo([]);
            onTaskCreated();
        } catch (err) {
            addNotification("Hiba a feladat létrehozásakor.", "error");
        } finally {
            setIsSubmitting(false);
        }
    };
    
     const groupButtons: {label: string, status: User['status'] | 'all'}[] = [
        { label: 'Mindenki', status: 'all' },
        { label: 'Normál', status: 'normal' },
    ];

    if (assigner.status === 'pro_max') {
        groupButtons.push({ label: 'Pro', status: 'pro' });
        groupButtons.push({ label: 'Pro Max', status: 'pro_max' });
    }

    return (
        <div className="bg-slate-800/40 backdrop-blur-sm p-6 rounded-2xl shadow-lg">
            <h2 className="text-2xl font-bold font-lilita text-white mb-4 border-b-2 border-slate-600 pb-2">Új feladat létrehozása</h2>
            <form onSubmit={handleCreateTask} className="space-y-4">
                <div>
                    <label htmlFor="task-desc" className="block text-white font-semibold mb-1">Feladat leírása</label>
                    <textarea id="task-desc" value={description} onChange={e => setDescription(e.target.value)} rows={3} className="w-full bg-slate-700 text-white p-2 rounded-lg" required />
                </div>
                <div className="flex flex-col sm:flex-row gap-4">
                    <div className="flex-1">
                        <label className="block text-white font-semibold mb-1">Személyek</label>
                         <div className="flex gap-2 mb-2 flex-wrap">
                            {groupButtons.map(group => (
                                <button type="button" key={group.label} onClick={() => handleGroupSelect(group.status)} className="px-3 py-1 text-xs font-bold text-white bg-slate-600 rounded-full hover:bg-slate-500">
                                    {group.label}
                                </button>
                            ))}
                        </div>
                        <div className="max-h-32 overflow-y-auto space-y-1 rounded-lg bg-slate-700 p-2 border border-slate-600">
                            {usersToList.length > 0 ? usersToList.map(u => (
                                <label key={u.id} className="flex items-center gap-3 p-2 rounded-md hover:bg-slate-600/50 cursor-pointer">
                                    <input
                                        type="checkbox"
                                        checked={assignedTo.includes(u.id)}
                                        onChange={() => handleAssigneeToggle(u.id)}
                                        className="h-5 w-5 rounded bg-slate-800 border-slate-500 text-orange-500 focus:ring-orange-500"
                                    />
                                    <span className="text-white font-semibold">{u.name}</span>
                                </label>
                            )) : <p className="text-white/70 text-center p-2">Nincs kiosztható személy</p>}
                        </div>
                    </div>
                    <div className="flex-1 sm:max-w-xs">
                        <label htmlFor="task-deadline" className="block text-white font-semibold mb-1">Határidő</label>
                        <input type="date" id="task-deadline" value={deadline} onChange={e => setDeadline(e.target.value)} className="w-full bg-slate-700 text-white p-2 rounded-lg" required min={new Date().toISOString().split("T")[0]} />
                    </div>
                </div>
                <button type="submit" disabled={isSubmitting || usersToList.length === 0} className="w-full mt-4 flex items-center justify-center gap-2 px-4 py-3 bg-orange-600 text-white font-bold rounded-full text-lg shadow-lg transform hover:scale-105 disabled:bg-slate-500 disabled:cursor-not-allowed">
                    <SendIcon className="w-5 h-5" />
                    <span>{isSubmitting ? 'Létrehozás...' : 'Feladatok létrehozása'}</span>
                </button>
            </form>
        </div>
    );
};


const OktatasomPage: React.FC<OktatasomPageProps> = ({ user, onNavigate, onRefreshTaskCount }) => {
    // State for Pro Max & Pro
    const [assignableUsers, setAssignableUsers] = useState<User[]>([]);
    const [allTasks, setAllTasks] = useState<AssignedTask[]>([]);
    const [editingTask, setEditingTask] = useState<AssignedTask | null>(null);
    const [taskToDelete, setTaskToDelete] = useState<AssignedTask | null>(null);
    const [selectedTaskDetails, setSelectedTaskDetails] = useState<AssignedTask | null>(null);

    // State for Normal/Pro
    const [myTasks, setMyTasks] = useState<AssignedTask[]>([]);
    const [allUsers, setAllUsers] = useState<User[]>([]);
    
    const [isLoading, setIsLoading] = useState(true);
    const { addNotification } = useNotification();
    
    const fetchAllData = async () => {
        setIsLoading(true);
        try {
            const users = await authService.getAllUsers();
            setAllUsers(users);

            if (user.status === 'pro_max' || user.status === 'pro') {
                await taskService.markTaskUpdatesAsSeen(user.id);
                onRefreshTaskCount();
            }

            if (user.status === 'pro_max') {
                const tasks = await taskService.getAllTasks();
                setAllTasks(tasks.sort((a,b) => a.deadline - b.deadline));
                const assignable = users.filter(u => u.id !== user.id);
                setAssignableUsers(assignable);
            } else if (user.status === 'pro') {
                 const [myAssignedTasks, allSystemTasks] = await Promise.all([
                    taskService.getTasksForUser(user.id),
                    taskService.getAllTasks()
                ]);
                setMyTasks(myAssignedTasks.sort((a, b) => a.deadline - b.deadline));
                setAllTasks(allSystemTasks.sort((a,b) => a.deadline - b.deadline));

                const normalUsers = users.filter(u => u.status === 'normal');
                setAssignableUsers(normalUsers);
            } else {
                const tasks = await taskService.getTasksForUser(user.id);
                setMyTasks(tasks.sort((a, b) => a.deadline - b.deadline));
            }
        } catch (error) {
            console.error("Failed to load data:", error);
            addNotification("Hiba az adatok betöltésekor.", "error");
        } finally {
            setIsLoading(false);
        }
    };

    useEffect(() => {
        fetchAllData();
    }, [user.id, user.status]);

    const handleCompleteTask = async (task: AssignedTask) => {
        try {
            await taskService.markTaskAsComplete(task.id, user);
            addNotification("Feladat elvégezve! Szép munka!", "success");
            setMyTasks(myTasks.map(t => t.id === task.id ? {...t, status: 'completed', completedAt: Date.now()} : t));
        } catch(err) {
             addNotification("Hiba a művelet során.", "error");
        }
    };

    const handleRejectTask = async (task: AssignedTask) => {
        try {
            await taskService.rejectTask(task.id, user);
            addNotification("Feladat elutasítva.", "success");
            setMyTasks(myTasks.map(t => t.id === task.id ? {...t, status: 'rejected'} : t));
        } catch(err) {
             addNotification("Hiba a művelet során.", "error");
        }
    };
    
    const handleConfirmDelete = async (task: AssignedTask) => {
        try {
            await taskService.markTaskAsDeleted(task.id, user.id);
            addNotification("Feladat törölve és archiválva.", "success");
            // Directly update state for immediate UI feedback
            setAllTasks(prev => prev.filter(t => t.id !== task.id));
        } catch (err) {
            addNotification("Hiba a törlés során.", "error");
        } finally {
            setTaskToDelete(null); // Close modal
        }
    };

    const handleTaskUpdated = (updatedTask: AssignedTask) => {
        setAllTasks(allTasks.map(t => t.id === updatedTask.id ? updatedTask : t));
        setMyTasks(myTasks.map(t => t.id === updatedTask.id ? updatedTask : t));
    };
    
    const getUserName = (id: string) => allUsers.find(u => u.id === id)?.name || 'Ismeretlen';

    const MyTasksList = ({ tasks, title }: { tasks: AssignedTask[], title: string }) => (
         <div className="bg-slate-800/40 backdrop-blur-sm p-6 rounded-2xl shadow-lg">
            <h2 className="text-2xl font-bold font-lilita text-white mb-4 border-b-2 border-slate-600 pb-2">{title}</h2>
             {isLoading ? <p className="text-white/70 text-center">Feladatok betöltése...</p> : tasks.length === 0 ? <p className="text-white/70 text-center">Nincs rád kiosztott feladat.</p> : (
                <div className="space-y-4 max-h-96 overflow-y-auto">
                    {tasks.map(task => {
                        const assignerName = allUsers.find(u => u.id === task.assignedById)?.name || 'Ismeretlen';
                        const TWO_DAYS_MS = 2 * 24 * 60 * 60 * 1000;
                        const now = Date.now();
                        const timeLeft = task.deadline - now;
                        const isDueSoon = task.status === 'pending' && timeLeft > 0 && timeLeft < TWO_DAYS_MS;
                        
                        const truncatedDescription = task.description.length > 15 
                            ? `${task.description.substring(0, 15)}...`
                            : task.description;

                        return (
                            <div 
                                key={task.id} 
                                onClick={() => setSelectedTaskDetails(task)}
                                className={`flex flex-col sm:flex-row items-center gap-3 p-3 rounded-lg transition-colors cursor-pointer hover:bg-slate-700/50
                                ${task.status === 'completed' ? 'bg-green-900/40' : task.status === 'rejected' ? 'bg-red-900/40' : 'bg-slate-900/40'}
                                ${isDueSoon ? 'ring-2 ring-red-500' : ''}`}>
                                {isDueSoon && (
                                    <div className="flex-shrink-0">
                                        <WarningIcon className="w-6 h-6 text-red-400" title="A határidő 2 napon belül lejár!"/>
                                    </div>
                                )}
                                <div className="flex-1">
                                    <p className="text-white font-semibold">
                                        {truncatedDescription}
                                    </p>
                                    <p className="text-xs text-white/70">Kiosztotta: {assignerName} | Határidő: {new Date(task.deadline).toLocaleDateString('hu-HU')}</p>
                                </div>
                                {task.status === 'pending' ? (
                                    <div onClick={(e) => e.stopPropagation()} className="flex gap-2 w-full sm:w-auto mt-3 sm:mt-0">
                                        <button onClick={() => handleCompleteTask(task)} className="flex-1 px-3 py-2 bg-orange-600 text-white font-bold rounded-full shadow-lg transform hover:scale-105">Kész</button>
                                        <button onClick={() => handleRejectTask(task)} className="flex-1 px-3 py-2 bg-slate-600 text-white font-bold rounded-full shadow-lg transform hover:scale-105">Elutasít</button>
                                    </div>
                                ) : (
                                    <div className={`w-full sm:w-40 mt-3 sm:mt-0 flex items-center justify-center gap-2 px-3 py-2 font-bold rounded-full ${task.status === 'completed' ? 'bg-green-600' : 'bg-red-600'}`}>
                                        {task.status === 'completed' ? <CheckCircleIcon className="w-5 h-5"/> : <XCircleIcon className="w-5 h-5"/>}
                                        <span>{task.status === 'completed' ? 'Elvégezve' : 'Elutasítva'}</span>
                                    </div>
                                )}
                            </div>
                        );
                    })}
                </div>
             )}
        </div>
    );

    const title = user.status === 'pro_max' ? 'Oktatás leadás' : user.status === 'pro' ? 'Oktatás leadása és kiadása' : 'Oktatásom';

    const StatusIndicator = ({ status }: { status: AssignedTask['status'] }) => {
        const styles = {
            pending: { icon: <HourglassIcon className="w-5 h-5 text-orange-400"/>, text: "Folyamatban", color: "text-orange-400" },
            completed: { icon: <CheckCircleIcon className="w-5 h-5 text-green-400"/>, text: "Elvégezve", color: "text-green-400" },
            rejected: { icon: <XCircleIcon className="w-5 h-5 text-red-400"/>, text: "Elutasítva", color: "text-red-400" },
            deleted: { icon: <TrashIcon className="w-5 h-5 text-gray-400"/>, text: "Törölve", color: "text-gray-400" },
        };
        const current = styles[status];
        return <span className={`flex items-center gap-1 text-xs font-semibold ${current.color}`}>{current.icon} {current.text}</span>;
    };
    
    // PRO MAX VIEW
    if (user.status === 'pro_max') {
        return (
            <>
                <div className="w-full max-w-2xl mx-auto animate-fade-in space-y-6">
                    <h1 className="text-3xl sm:text-4xl font-bold font-lilita tracking-wide text-center text-white">{title}</h1>
                    <TaskCreationForm usersToList={assignableUsers} assigner={user} onTaskCreated={fetchAllData}/>
                    <div className="bg-slate-800/40 backdrop-blur-sm p-6 rounded-2xl shadow-lg">
                        <h2 className="text-2xl font-bold font-lilita text-white mb-4 border-b-2 border-slate-600 pb-2">Összes kiosztott feladat</h2>
                         {isLoading ? <p className="text-white/70 text-center">Betöltés...</p> : allTasks.filter(t => t.status === 'pending').length === 0 ? <p className="text-white/70 text-center">Nincsenek aktív kiosztott feladatok.</p> : (
                            <div className="space-y-3 max-h-96 overflow-y-auto pr-2">
                                {allTasks.filter(t => t.status === 'pending').map(task => {
                                    const TWO_DAYS_MS = 2 * 24 * 60 * 60 * 1000;
                                    const now = Date.now();
                                    const timeLeft = task.deadline - now;
                                    const isDueSoon = task.status === 'pending' && timeLeft > 0 && timeLeft < TWO_DAYS_MS;
                                    
                                    const truncatedText = task.description.length > 15
                                        ? `${task.description.substring(0, 15)}...`
                                        : task.description;

                                    return (
                                    <div 
                                        key={task.id} 
                                        onClick={() => setSelectedTaskDetails(task)}
                                        className={`flex flex-col sm:flex-row items-center gap-3 p-3 rounded-lg bg-slate-900/40 cursor-pointer hover:bg-slate-700/50 ${isDueSoon ? 'ring-2 ring-red-500' : ''}`}>
                                        {isDueSoon && (
                                            <div className="flex-shrink-0">
                                                <WarningIcon className="w-6 h-6 text-red-400" title="A határidő 2 napon belül lejár!"/>
                                            </div>
                                        )}
                                        <div className="flex-1">
                                            <p className="font-semibold text-white">
                                                {truncatedText}
                                            </p>
                                            <p className="text-xs text-white/70">
                                                <span>{getUserName(task.assignedToUserId)}</span> | Határidő: {new Date(task.deadline).toLocaleDateString('hu-HU')}
                                            </p>
                                        </div>
                                        <div onClick={e => e.stopPropagation()} className="flex items-center gap-2">
                                            <StatusIndicator status={task.status} />
                                            {(user.id === task.assignedById || user.status === 'pro_max') &&
                                                <>
                                                    <button onClick={() => setEditingTask(task)} className="p-2 rounded-full text-white/70 hover:bg-slate-700"><EditIcon className="w-5 h-5"/></button>
                                                    <button onClick={() => setTaskToDelete(task)} className="p-2 rounded-full text-red-400 hover:bg-red-500/20"><TrashIcon className="w-5 h-5"/></button>
                                                </>
                                            }
                                        </div>
                                    </div>
                                )})}
                            </div>
                         )}
                    </div>
                     <div className="mt-8 text-center">
                        <button
                            onClick={() => onNavigate('archivum')}
                            className="flex items-center justify-center gap-3 mx-auto px-6 py-3 bg-slate-700/50 text-white font-bold rounded-full shadow-lg transform hover:scale-105 transition-transform"
                        >
                            <FolderIcon className="w-6 h-6" />
                            <span>Feladat Archívum Megtekintése</span>
                        </button>
                    </div>
                </div>
                {editingTask && <EditTaskModal task={editingTask} onClose={() => setEditingTask(null)} onTaskUpdated={handleTaskUpdated} />}
                {taskToDelete && (
                    <DeleteTaskModal
                        task={taskToDelete}
                        assigneeName={getUserName(taskToDelete.assignedToUserId)}
                        onClose={() => setTaskToDelete(null)}
                        onConfirmDelete={() => handleConfirmDelete(taskToDelete)}
                        onExtendDeadline={() => {
                            setEditingTask(taskToDelete);
                            setTaskToDelete(null);
                        }}
                    />
                )}
                <TaskDetailModal
                    isOpen={!!selectedTaskDetails}
                    onClose={() => setSelectedTaskDetails(null)}
                    task={selectedTaskDetails}
                    users={allUsers}
                />
            </>
        )
    }

    // PRO VIEW
    if (user.status === 'pro') {
        const assignedByMeTasks = allTasks.filter(t => t.assignedById === user.id && t.status === 'pending');

         return (
             <>
                <div className="w-full max-w-2xl mx-auto animate-fade-in space-y-6">
                    <h1 className="text-3xl sm:text-4xl font-bold font-lilita tracking-wide text-center text-white">{title}</h1>
                    <MyTasksList tasks={myTasks.filter(t => t.status === 'pending')} title="Rád kiosztott feladatok" />
                    <TaskCreationForm usersToList={assignableUsers} assigner={user} onTaskCreated={fetchAllData}/>
                    <div className="bg-slate-800/40 backdrop-blur-sm p-6 rounded-2xl shadow-lg">
                        <h2 className="text-2xl font-bold font-lilita text-white mb-4 border-b-2 border-slate-600 pb-2">Általad kiosztott feladatok</h2>
                         {isLoading ? <p className="text-white/70 text-center">Betöltés...</p> : assignedByMeTasks.length === 0 ? <p className="text-white/70 text-center">Nem osztottál még ki aktív feladatot.</p> : (
                            <div className="space-y-3 max-h-96 overflow-y-auto pr-2">
                                {assignedByMeTasks.map(task => {
                                    const truncatedText = task.description.length > 15
                                        ? `${task.description.substring(0, 15)}...`
                                        : task.description;
                                    return (
                                        <div 
                                            key={task.id} 
                                            onClick={() => setSelectedTaskDetails(task)}
                                            className="flex flex-col sm:flex-row items-center gap-3 p-3 rounded-lg bg-slate-900/40 cursor-pointer hover:bg-slate-700/50">
                                            <div className="flex-1">
                                                <p className="font-semibold text-white">
                                                    {truncatedText}
                                                </p>
                                                <p className="text-xs text-white/70">
                                                    <span>{getUserName(task.assignedToUserId)}</span> | Határidő: {new Date(task.deadline).toLocaleDateString('hu-HU')}
                                                </p>
                                            </div>
                                            <div onClick={e => e.stopPropagation()} className="flex items-center gap-2">
                                                <StatusIndicator status={task.status} />
                                                <button onClick={() => setEditingTask(task)} className="p-2 rounded-full text-white/70 hover:bg-slate-700"><EditIcon className="w-5 h-5"/></button>
                                                <button onClick={() => setTaskToDelete(task)} className="p-2 rounded-full text-red-400 hover:bg-red-500/20"><TrashIcon className="w-5 h-5"/></button>
                                            </div>
                                        </div>
                                    )
                                })}
                            </div>
                         )}
                    </div>
                     <div className="mt-8 text-center">
                        <button
                            onClick={() => onNavigate('archivum')}
                            className="flex items-center justify-center gap-3 mx-auto px-6 py-3 bg-slate-700/50 text-white font-bold rounded-full shadow-lg transform hover:scale-105 transition-transform"
                        >
                            <FolderIcon className="w-6 h-6" />
                            <span>Feladat Archívum Megtekintése</span>
                        </button>
                    </div>
                </div>
                {editingTask && <EditTaskModal task={editingTask} onClose={() => setEditingTask(null)} onTaskUpdated={handleTaskUpdated} />}
                {taskToDelete && (
                    <DeleteTaskModal
                        task={taskToDelete}
                        assigneeName={getUserName(taskToDelete.assignedToUserId)}
                        onClose={() => setTaskToDelete(null)}
                        onConfirmDelete={() => handleConfirmDelete(taskToDelete)}
                        onExtendDeadline={() => {
                            setEditingTask(taskToDelete);
                            setTaskToDelete(null);
                        }}
                    />
                )}
                 <TaskDetailModal
                    isOpen={!!selectedTaskDetails}
                    onClose={() => setSelectedTaskDetails(null)}
                    task={selectedTaskDetails}
                    users={allUsers}
                />
            </>
         );
    }

    // SHARED BETWEEN ALL
    return (
        <>
            <div className="w-full max-w-2xl mx-auto animate-fade-in space-y-6">
                <h1 className="text-3xl sm:text-4xl font-bold font-lilita tracking-wide text-center text-white">{title}</h1>
                <MyTasksList tasks={myTasks.filter(t => t.status === 'pending')} title="Aktív Feladataim" />
                <div className="mt-8 text-center">
                    <button
                        onClick={() => onNavigate('archivum')}
                        className="flex items-center justify-center gap-3 mx-auto px-6 py-3 bg-slate-700/50 text-white font-bold rounded-full shadow-lg transform hover:scale-105 transition-transform"
                    >
                        <FolderIcon className="w-6 h-6" />
                        <span>Feladat Archívum Megtekintése</span>
                    </button>
                </div>
            </div>
            <TaskDetailModal
                isOpen={!!selectedTaskDetails}
                onClose={() => setSelectedTaskDetails(null)}
                task={selectedTaskDetails}
                users={allUsers}
            />
        </>
    );
};

export default OktatasomPage;