import React, { useState, useEffect, useMemo } from 'react';
import type { User, AssignedTask } from '../types';
import { taskService } from '../services/taskService';
import { authService } from '../services/authService';
import ArrowLeftIcon from './icons/ArrowLeftIcon';
import CheckCircleIcon from './icons/CheckCircleIcon';
import XCircleIcon from './icons/XCircleIcon';
import TrashIcon from './icons/TrashIcon';

interface TaskArchivePageProps {
  currentUser: User;
  onNavigate: (view: string) => void;
}

const getStartOfMonth = () => {
  const now = new Date();
  return new Date(now.getFullYear(), now.getMonth(), 1);
};

const getEndOfMonth = () => {
  const now = new Date();
  return new Date(now.getFullYear(), now.getMonth() + 1, 0, 23, 59, 59);
};

const formatDuration = (ms: number) => {
    if (ms < 0) return 'N/A';
    const seconds = Math.floor(ms / 1000);
    const minutes = Math.floor(seconds / 60);
    const hours = Math.floor(minutes / 60);
    const days = Math.floor(hours / 24);

    if (days > 0) return `${days} nap ${hours % 24} óra`;
    if (hours > 0) return `${hours} óra ${minutes % 60} perc`;
    if (minutes > 0) return `${minutes} perc`;
    return `${seconds} másodperc`;
};


const TaskArchivePage: React.FC<TaskArchivePageProps> = ({ currentUser, onNavigate }) => {
    const [archivedTasks, setArchivedTasks] = useState<AssignedTask[]>([]);
    const [allUsers, setAllUsers] = useState<User[]>([]);
    const [isLoading, setIsLoading] = useState(true);
    
    // Filters
    const [searchTerm, setSearchTerm] = useState('');
    const [userStatusFilter, setUserStatusFilter] = useState<User['status'][]>([]);
    const [taskStatusFilter, setTaskStatusFilter] = useState<AssignedTask['status'][]>([]);
    const [startDate, setStartDate] = useState(getStartOfMonth().toISOString().split('T')[0]);
    const [endDate, setEndDate] = useState(getEndOfMonth().toISOString().split('T')[0]);
    
    // New scope filters
    const [proMaxScopeFilter, setProMaxScopeFilter] = useState<'all' | 'to_me' | 'by_me'>('all');
    const [proScopeFilters, setProScopeFilters] = useState<('to_me' | 'by_me')[]>(['to_me', 'by_me']);

    useEffect(() => {
        const fetchData = async () => {
            setIsLoading(true);
            try {
                const [tasks, users] = await Promise.all([
                    taskService.getArchivedTasks(),
                    authService.getAllUsers()
                ]);
                setArchivedTasks(tasks);
                setAllUsers(users);
            } catch (error) {
                console.error("Failed to load archive data:", error);
            } finally {
                setIsLoading(false);
            }
        };
        fetchData();
    }, []);

    const userMap = useMemo(() => new Map(allUsers.map(u => [u.id, u])), [allUsers]);

    const filteredTasks = useMemo(() => {
        const start = new Date(startDate);
        start.setHours(0,0,0,0);
        const end = new Date(endDate);
        end.setHours(23,59,59,999);

        let baseTasks = archivedTasks;

        // Apply role-based initial filtering (scope)
        if (currentUser.status === 'pro_max') {
            if (proMaxScopeFilter === 'to_me') {
                baseTasks = archivedTasks.filter(task => task.assignedToUserId === currentUser.id);
            } else if (proMaxScopeFilter === 'by_me') {
                baseTasks = archivedTasks.filter(task => task.assignedById === currentUser.id);
            }
        } else if (currentUser.status === 'pro') {
            baseTasks = archivedTasks.filter(task => {
                const isToMe = task.assignedToUserId === currentUser.id;
                const isByMe = task.assignedById === currentUser.id;
                if (proScopeFilters.length === 0) return false;
                if (proScopeFilters.length === 2) return isToMe || isByMe;
                if (proScopeFilters.includes('to_me')) return isToMe;
                if (proScopeFilters.includes('by_me')) return isByMe;
                return false;
            });
        } else { // 'normal'
            baseTasks = archivedTasks.filter(task => task.assignedToUserId === currentUser.id);
        }

        return baseTasks.filter(task => {
            const assignee = userMap.get(task.assignedToUserId);
            
            // Date filter
            const relevantDate = task.completedAt || task.deletedAt || task.deadline;
            if (relevantDate < start.getTime() || relevantDate > end.getTime()) {
                return false;
            }

            // User Status filter (only for pro_max)
            if (currentUser.status === 'pro_max' && assignee && userStatusFilter.length > 0) {
                 const assigneeStatus = assignee.status || 'normal';
                 if (!userStatusFilter.includes(assigneeStatus)) {
                    return false;
                }
            }
            
            // Task Status filter
            if (taskStatusFilter.length > 0 && !taskStatusFilter.includes(task.status)) {
                return false;
            }

            // Enhanced Search term filter
            if (searchTerm) {
                const lowerSearchTerm = searchTerm.toLowerCase();
                const assigneeName = assignee?.name.toLowerCase();
                const assignerName = userMap.get(task.assignedById)?.name.toLowerCase();
                const description = task.description.toLowerCase();

                if (
                    !assigneeName?.includes(lowerSearchTerm) &&
                    !assignerName?.includes(lowerSearchTerm) &&
                    !description.includes(lowerSearchTerm)
                ) {
                     return false;
                }
            }
            
            return true;
        });
    }, [archivedTasks, searchTerm, userStatusFilter, taskStatusFilter, startDate, endDate, userMap, currentUser, proMaxScopeFilter, proScopeFilters]);

    const handleUserStatusFilterChange = (status: User['status']) => {
        setUserStatusFilter(prev => 
            prev.includes(status) ? prev.filter(s => s !== status) : [...prev, status]
        );
    };
    
    const handleProScopeToggle = (filter: 'to_me' | 'by_me') => {
        setProScopeFilters(prev => 
            prev.includes(filter)
                ? prev.filter(f => f !== filter)
                : [...prev, filter]
        );
    };

    const handleTaskStatusFilterChange = (status: AssignedTask['status']) => {
        setTaskStatusFilter(prev => 
            prev.includes(status) ? prev.filter(s => s !== status) : [...prev, status]
        );
    };
    
    const filterableTaskStatuses: AssignedTask['status'][] = ['completed', 'rejected', 'deleted'];

    const renderProMaxFilters = () => (
        <>
            <input
                type="text"
                placeholder="Keresés személyre, leírásra..."
                value={searchTerm}
                onChange={e => setSearchTerm(e.target.value)}
                className="w-full bg-slate-700 text-white p-2 rounded-lg"
            />
            <div className="flex flex-wrap justify-center gap-2 pt-2">
                {(['all', 'to_me', 'by_me'] as const).map(scope => (
                    <button key={scope} onClick={() => setProMaxScopeFilter(scope)}
                        className={`px-3 py-1 text-sm font-bold rounded-full transition-colors ${ proMaxScopeFilter === scope ? 'bg-orange-600 text-white' : 'bg-slate-600 text-white/80 hover:bg-slate-500'}`}>
                        {scope === 'all' ? 'Összes' : scope === 'to_me' ? 'Nekem kiosztott' : 'Általam kiosztott'}
                    </button>
                ))}
            </div>
            <div className="flex flex-wrap items-center justify-center gap-4 pt-2 border-t border-white/10">
                <span className="text-sm font-semibold">Státusz szűrés:</span>
                {(['normal', 'pro', 'pro_max'] as const).map(status => (
                    <label key={status} className="flex items-center gap-2 cursor-pointer">
                        <input type="checkbox" checked={userStatusFilter.includes(status)} onChange={() => handleUserStatusFilterChange(status)}
                            className="h-5 w-5 rounded bg-slate-800 border-slate-500 text-orange-500 focus:ring-orange-500" />
                        <span>{status === 'pro' ? 'Pro' : status === 'pro_max' ? 'Pro Max' : 'Normál'}</span>
                    </label>
                ))}
            </div>
        </>
    );
    
    const renderProFilters = () => (
         <div className="flex flex-col gap-4">
            <input
                type="text"
                placeholder="Keresés leírásra vagy személyre..."
                value={searchTerm}
                onChange={e => setSearchTerm(e.target.value)}
                className="w-full bg-slate-700 text-white p-2 rounded-lg"
            />
            <div className="flex flex-wrap items-center justify-center gap-4">
                <label className="flex items-center gap-2 cursor-pointer">
                    <input type="checkbox" checked={proScopeFilters.includes('to_me')} onChange={() => handleProScopeToggle('to_me')}
                        className="h-5 w-5 rounded bg-slate-800 border-slate-500 text-orange-500 focus:ring-orange-500" />
                    <span>Nekem kiosztott</span>
                </label>
                 <label className="flex items-center gap-2 cursor-pointer">
                    <input type="checkbox" checked={proScopeFilters.includes('by_me')} onChange={() => handleProScopeToggle('by_me')}
                        className="h-5 w-5 rounded bg-slate-800 border-slate-500 text-orange-500 focus:ring-orange-500" />
                    <span>Általam kiosztott</span>
                </label>
            </div>
        </div>
    );
    
    return (
        <div className="w-full max-w-2xl mx-auto animate-fade-in space-y-6 text-white">
            <div className="flex items-center gap-4">
                <button onClick={() => onNavigate('oktatasom')} className="p-2 rounded-full hover:bg-white/10">
                    <ArrowLeftIcon className="w-6 h-6 text-white"/>
                </button>
                <h1 className="text-3xl sm:text-4xl font-bold font-lilita tracking-wide text-center">Feladat Archívum</h1>
            </div>

            {/* Filters */}
            <div className="bg-slate-800/40 backdrop-blur-sm p-4 rounded-2xl space-y-4">
                {currentUser.status === 'pro_max' && renderProMaxFilters()}
                {currentUser.status === 'pro' && renderProFilters()}
                
                <div className="flex flex-col sm:flex-row items-center gap-2">
                    <input type="date" value={startDate} onChange={e => setStartDate(e.target.value)} className="w-full bg-slate-700 text-white p-2 rounded-lg"/>
                    <span className="flex-shrink-0"> - </span>
                    <input type="date" value={endDate} onChange={e => setEndDate(e.target.value)} className="w-full bg-slate-700 text-white p-2 rounded-lg"/>
                </div>
                 <div className="flex flex-wrap justify-center gap-2 pt-2 border-t border-white/10">
                    {filterableTaskStatuses.map(status => (
                        <button
                            key={status}
                            onClick={() => handleTaskStatusFilterChange(status)}
                            className={`px-3 py-1 text-sm font-bold rounded-full transition-colors ${
                                taskStatusFilter.includes(status)
                                    ? 'bg-orange-600 text-white'
                                    : 'bg-slate-600 text-white/80 hover:bg-slate-500'
                            }`}
                        >
                            {status === 'completed' ? 'Elvégzett' : status === 'rejected' ? 'Elutasítva' : 'Törölve'}
                        </button>
                    ))}
                </div>
            </div>

            {/* Results */}
            <div className="bg-slate-800/40 backdrop-blur-sm p-4 rounded-2xl">
                 {isLoading ? <p className="text-center">Betöltés...</p> : filteredTasks.length === 0 ? <p className="text-center text-white/70">Nincs a szűrésnek megfelelő archivált feladat.</p> : (
                    <div className="space-y-3 max-h-[60vh] overflow-y-auto pr-2">
                        {filteredTasks.map(task => {
                            const assigner = userMap.get(task.assignedById);
                            const assignee = userMap.get(task.assignedToUserId);
                            const assignedTimestamp = parseInt(task.id.split('_')[1]);
                            const timeToComplete = task.completedAt ? task.completedAt - assignedTimestamp : -1;
                            const wasOverdue = task.completedAt && task.completedAt > task.deadline;
                            
                            const statusStyles = {
                                completed: { bg: 'bg-green-900/30', badgeBg: 'bg-green-500/50', icon: <CheckCircleIcon className="w-4 h-4"/>, text: 'Elvégezve' },
                                rejected: { bg: 'bg-red-900/30', badgeBg: 'bg-red-500/50', icon: <XCircleIcon className="w-4 h-4"/>, text: 'Elutasítva' },
                                deleted: { bg: 'bg-slate-700/40', badgeBg: 'bg-slate-500/50', icon: <TrashIcon className="w-4 h-4"/>, text: 'Törölve' }
                            };
                            const currentStyle = statusStyles[task.status] || statusStyles.deleted;

                            return (
                                <div key={task.id} className={`p-3 rounded-lg ${currentStyle.bg}`}>
                                    <div className="flex justify-between items-start">
                                        <p className="font-semibold text-white/90 flex-1 pr-4">{task.description}</p>
                                        <div className={`flex items-center gap-2 px-2 py-1 rounded-full text-xs font-bold ${currentStyle.badgeBg}`}>
                                            {currentStyle.icon}
                                            {currentStyle.text}
                                        </div>
                                    </div>
                                    <div className="text-xs text-white/70 mt-2 space-y-1 border-t border-white/10 pt-2">
                                        <p><strong>Kiosztotta:</strong> {assigner?.name || 'Ismeretlen'}</p>
                                        <p><strong>Megbízott:</strong> {assignee?.name || 'Ismeretlen'}</p>
                                        <p><strong>Kiosztva:</strong> {new Date(assignedTimestamp).toLocaleDateString('hu-HU')}</p>
                                        <p><strong>Határidő:</strong> {new Date(task.deadline).toLocaleDateString('hu-HU')}</p>
                                        {task.status === 'completed' && task.completedAt && (
                                            <>
                                            <p><strong>Teljesítve:</strong> {new Date(task.completedAt).toLocaleString('hu-HU')} ({formatDuration(timeToComplete)})</p>
                                            {wasOverdue && <p className="font-bold text-orange-400">Határidőn túl teljesítve!</p>}
                                            </>
                                        )}
                                        {task.status === 'deleted' && task.deletedAt && task.deletedById && (
                                            <p><strong>Törölve:</strong> {new Date(task.deletedAt).toLocaleString('hu-HU')} (<strong>{userMap.get(task.deletedById)?.name || 'Ismeretlen'}</strong> által)</p>
                                        )}
                                        {task.deadlineHistory && task.deadlineHistory.length > 0 && (
                                            <div className="pl-2 border-l-2 border-slate-500 mt-1 pt-1">
                                                <p className="font-semibold">Határidő módosítások:</p>
                                                {task.deadlineHistory.map((h, i) => (
                                                    <p key={i} className="text-slate-400">
                                                        {new Date(h.oldDeadline).toLocaleDateString('hu-HU')} &rarr; {new Date(h.newDeadline).toLocaleDateString('hu-HU')}
                                                    </p>
                                                ))}
                                            </div>
                                        )}
                                    </div>
                                </div>
                            );
                        })}
                    </div>
                 )}
            </div>
        </div>
    );
};

export default TaskArchivePage;