import React, { useState, useEffect } from 'react';
import type { User, Newspaper, Comment } from '../types';
import { newspaperService } from '../services/newspaperService';
import { authService } from '../services/authService';
import { useNotification } from '../contexts/NotificationContext';
import SendIcon from './icons/SendIcon';
import ChevronLeftIcon from './icons/ChevronLeftIcon';
import ChevronRightIcon from './icons/ChevronRightIcon';
import ImageIcon from './icons/ImageIcon';
import CommentCreator from './CommentCreator';
import CommentCard from './CommentCard';

interface HelyiLapPageProps {
    currentUser: User;
    onUserUpdate: (user: User) => void;
}

const HelyiLapPage: React.FC<HelyiLapPageProps> = ({ currentUser, onUserUpdate }) => {
    const [newspapers, setNewspapers] = useState<Newspaper[]>([]);
    const [currentNewspaperIndex, setCurrentNewspaperIndex] = useState(0);
    const [isLoading, setIsLoading] = useState(true);
    const [imageFile, setImageFile] = useState<File | null>(null);
    const [issueNumber, setIssueNumber] = useState('');
    const [isUploading, setIsUploading] = useState(false);
    const { addNotification } = useNotification();
    
    const isJournalist = currentUser.identifier === '04';

    const fetchNewspapers = async () => {
        setIsLoading(true);
        const data = await newspaperService.getNewspapers();
        setNewspapers(data);
        // After fetching, if there are newspapers, set index to the latest one (first in the sorted array)
        setCurrentNewspaperIndex(0);
        setIsLoading(false);
    };

    useEffect(() => {
        fetchNewspapers();
    }, []);

    const handleUpload = async (e: React.FormEvent) => {
        e.preventDefault();
        const numIssue = parseInt(issueNumber, 10);
        if (isNaN(numIssue) || numIssue <= 0) {
            addNotification("Adj meg egy érvényes, pozitív kiadási számot.", "error");
            return;
        }
        if (!imageFile) {
            addNotification("Válassz ki egy képet a feltöltéshez.", "error");
            return;
        }
        setIsUploading(true);
        try {
            await newspaperService.uploadNewspaper(numIssue, imageFile, currentUser);
            addNotification("Helyi Lap sikeresen feltöltve!", "success");
            setImageFile(null);
            setIssueNumber('');
            fetchNewspapers();
        } catch (error: any) {
            addNotification(error.message || "Hiba a feltöltés során.", "error");
        } finally {
            setIsUploading(false);
        }
    };

    const handleAddComment = async (newspaperId: string, content: string | null, imageFile: File | null, gifUrl: string | null) => {
        try {
            await newspaperService.addCommentToNewspaper(newspaperId, currentUser, content, imageFile, gifUrl);
            addNotification('Komment hozzáadva!', 'success');
            fetchNewspapers(); // Refresh to show the new comment
        } catch (err) {
            addNotification('Hiba a komment hozzáadásakor.', 'error');
        }
    };

    const handleDeleteComment = async (newspaperId: string, commentId: string) => {
        try {
            await newspaperService.deleteCommentFromNewspaper(newspaperId, commentId, currentUser);
            addNotification('Komment törölve.', 'success');
            fetchNewspapers();
        } catch (err: any) {
            addNotification(err.message || 'Hiba a komment törlésekor.', 'error');
        }
    };

    const handleToggleCommentReaction = async (newspaperId: string, commentId: string, reaction: string) => {
        try {
            const newspaper = newspapers.find(n => n.id === newspaperId);
            const comment = newspaper?.comments.find(c => c.id === commentId);

            if (comment && comment.author.id !== currentUser.id) {
                const reactedComments = currentUser.reactedCommentsForPoints || [];
                if (!reactedComments.includes(commentId)) {
                    const updatedUser = {
                        ...currentUser,
                        points: currentUser.points + 2,
                        reactedCommentsForPoints: [...reactedComments, commentId],
                        pointsHistory: [
                            { reason: 'Reakció egy kommentre', points: 2, date: Date.now() },
                            ...(currentUser.pointsHistory || [])
                        ]
                    };
                    authService.updateUser(updatedUser);
                    onUserUpdate(updatedUser);
                    addNotification("Kommentreakcióért 2 koronát kaptál!", "success");
                }
            }
            
            await newspaperService.toggleCommentReactionOnNewspaper(newspaperId, commentId, reaction, currentUser.id);
            fetchNewspapers();
        } catch (err) {
            addNotification('Hiba a reagálás közben.', 'error');
        }
    };

    const currentNewspaper = newspapers[currentNewspaperIndex];

    return (
        <div className="w-full max-w-2xl mx-auto animate-fade-in space-y-6 text-white">
            <h1 className="text-3xl sm:text-4xl font-bold font-lilita tracking-wide text-center">Helyi Lap</h1>

            {isJournalist && (
                <div className="bg-slate-800/40 backdrop-blur-sm p-6 rounded-2xl shadow-lg">
                    <h2 className="text-xl font-bold font-lilita mb-4">Új Lap Feltöltése</h2>
                    <form onSubmit={handleUpload} className="space-y-4">
                        <input
                            type="number"
                            placeholder="Kiadási szám"
                            value={issueNumber}
                            onChange={e => setIssueNumber(e.target.value)}
                            className="w-full bg-slate-700 text-white p-2 rounded-lg"
                            required
                            min="1"
                        />
                        <label htmlFor="newspaper-upload" className="w-full cursor-pointer bg-slate-700 rounded-lg p-4 text-center text-orange-400 hover:text-orange-300 hover:bg-slate-600 transition-colors flex flex-col items-center justify-center">
                            <ImageIcon className="h-8 w-8 mb-2"/>
                            <span className="font-medium">{imageFile ? `Kiválasztva: ${imageFile.name}` : 'Kattints a kép kiválasztásához'}</span>
                            <input id="newspaper-upload" type="file" accept="image/*" className="sr-only" onChange={e => setImageFile(e.target.files?.[0] || null)} />
                        </label>
                         <button type="submit" disabled={isUploading || !imageFile} className="w-full flex items-center justify-center gap-2 px-4 py-3 bg-orange-600 font-bold rounded-full shadow-lg transform hover:scale-105 disabled:bg-slate-500 disabled:cursor-not-allowed">
                            <SendIcon className="w-5 h-5" />
                            <span>{isUploading ? 'Feltöltés...' : 'Feltöltés'}</span>
                        </button>
                    </form>
                </div>
            )}
            
            <div className="bg-slate-800/40 backdrop-blur-sm p-4 sm:p-6 rounded-2xl shadow-lg">
                 {isLoading ? <p className="text-center">Betöltés...</p> : 
                    !currentNewspaper ? <p className="text-center text-white/70">Még nem lett feltöltve a Helyi Lap.</p> :
                    (
                        <div>
                            <div className="flex justify-between items-center mb-4">
                                <button onClick={() => setCurrentNewspaperIndex(i => i + 1)} disabled={currentNewspaperIndex >= newspapers.length - 1} className="disabled:opacity-30"><ChevronLeftIcon className="w-8 h-8"/></button>
                                <div className="text-center">
                                    <p className="font-bold text-lg">Kiadási szám: {currentNewspaper.issueNumber}</p>
                                    <p className="text-xs text-white/60">Feltöltve: {new Date(currentNewspaper.uploadedAt).toLocaleDateString('hu-HU')}</p>
                                </div>
                                <button onClick={() => setCurrentNewspaperIndex(i => i - 1)} disabled={currentNewspaperIndex <= 0} className="disabled:opacity-30"><ChevronRightIcon className="w-8 h-8"/></button>
                            </div>
                            <img src={currentNewspaper.imageUrl} alt={`Helyi Lap - ${currentNewspaper.issueNumber}. szám`} className="w-full rounded-lg shadow-md" />
                            
                            <div className="mt-6 pt-4 border-t-2 border-white/20">
                                <h3 className="text-xl font-bold font-lilita mb-4">Kommentek</h3>
                                <div className="space-y-4 mb-6">
                                    {currentNewspaper.comments.length > 0 ? (
                                        currentNewspaper.comments.map(comment => (
                                            <CommentCard
                                                key={comment.id}
                                                comment={comment}
                                                currentUser={currentUser}
                                                onToggleReaction={(reaction) => handleToggleCommentReaction(currentNewspaper.id, comment.id, reaction)}
                                                onDeleteComment={() => handleDeleteComment(currentNewspaper.id, comment.id)}
                                            />
                                        ))
                                    ) : (
                                        <p className="text-center text-white/70">Még nincsenek kommentek.</p>
                                    )}
                                </div>
                                <CommentCreator
                                    user={currentUser}
                                    onAddComment={(content, imageFile, gifUrl) => handleAddComment(currentNewspaper.id, content, imageFile, gifUrl)}
                                />
                            </div>
                        </div>
                    )
                 }
            </div>
        </div>
    );
};

export default HelyiLapPage;