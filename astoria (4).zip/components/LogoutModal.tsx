import React from 'react';

interface LogoutModalProps {
  isOpen: boolean;
  onClose: () => void;
  onConfirm: () => void;
}

const LogoutModal: React.FC<LogoutModalProps> = ({ isOpen, onClose, onConfirm }) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex justify-center items-center z-50 animate-fade-in" onClick={onClose}>
      <div className="bg-[var(--component-bg)] backdrop-blur-md w-full max-w-sm rounded-2xl shadow-2xl p-6 text-[var(--text-primary)] text-center" onClick={e => e.stopPropagation()}>
        <img 
            src="https://media4.giphy.com/media/v1.Y2lkPTc5MGI3NjExajJyb241aGw5NGpscmE1NG5vdDloZzV1dGNjMmNjcjg5N2VyOGxieCZlcD12MV9pbnRlcm5hbF9naWZfYnlfaWQmY3Q9Zw/3o6vXUgk6M0h07MnuM/giphy.gif" 
            alt="Logging out" 
            className="w-full max-w-xs mx-auto rounded-lg mb-4"
        />
        <h3 className="text-xl font-bold font-lilita mb-6">Biztos, hogy ki akarsz lépni?</h3>
        <div className="flex justify-center gap-4">
          <button
            onClick={onConfirm}
            className="px-8 py-2 bg-red-600 text-white font-bold rounded-full shadow-lg transform hover:scale-105 transition-colors"
          >
            Igen
          </button>
          <button
            onClick={onClose}
            className="px-8 py-2 bg-slate-600 text-white font-semibold rounded-full shadow-lg transform hover:scale-105 transition-colors"
          >
            Nem
          </button>
        </div>
      </div>
    </div>
  );
};

export default LogoutModal;