import React from 'react';
import { messageService } from '../services/messageService';
import { useNotification } from '../contexts/NotificationContext';

interface MuteChatModalProps {
    isOpen: boolean;
    onClose: () => void;
    conversationId: string;
}

const MuteChatModal: React.FC<MuteChatModalProps> = ({ isOpen, onClose, conversationId }) => {
    const { addNotification } = useNotification();
    const durations = [
        { label: '1 óráig', hours: 1 },
        { label: '3 óráig', hours: 3 },
        { label: '12 óráig', hours: 12 },
        { label: '24 óráig', hours: 24 },
    ];

    const handleMute = async (hours: number) => {
        const muteUntil = Date.now() + hours * 60 * 60 * 1000;
        await messageService.muteConversation(conversationId, muteUntil);
        addNotification(`Értesítések némítva ${hours} órára.`, 'success');
        onClose();
    };

    if (!isOpen) return null;

    return (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex justify-center items-center animate-fade-in" onClick={onClose}>
            <div className="bg-slate-800 w-full max-w-sm rounded-2xl shadow-2xl p-6 text-white" onClick={e => e.stopPropagation()}>
                <h3 className="text-2xl font-bold font-lilita mb-6 text-center">Értesítések némítása</h3>
                <div className="space-y-3">
                    {durations.map(({ label, hours }) => (
                        <button key={hours} onClick={() => handleMute(hours)} className="w-full p-3 bg-slate-700 font-semibold rounded-lg hover:bg-slate-600 transition-colors">
                            {label}
                        </button>
                    ))}
                </div>
            </div>
        </div>
    );
};

export default MuteChatModal;