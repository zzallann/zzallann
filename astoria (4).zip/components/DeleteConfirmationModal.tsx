import React from 'react';

interface DeleteConfirmationModalProps {
  isOpen: boolean;
  onClose: () => void;
  onConfirm: () => void;
  title?: string;
  message?: string;
  confirmText?: string;
  cancelText?: string;
  confirmButtonClass?: string;
}

const DeleteConfirmationModal: React.FC<DeleteConfirmationModalProps> = ({ isOpen, onClose, onConfirm, title, message, confirmText, cancelText, confirmButtonClass }) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex justify-center items-center z-50 animate-fade-in" onClick={onClose}>
      <div className="bg-[var(--component-bg)] backdrop-blur-md w-full max-w-sm rounded-2xl shadow-2xl p-6 text-[var(--text-primary)] text-center" onClick={e => e.stopPropagation()}>
        <h3 className="text-2xl font-bold font-lilita mb-4">{title || 'Törlés megerösítése'}</h3>
        <p className="text-[var(--text-secondary)] mb-6">{message || 'Biztosan törölni szeretnéd ezt az elemet?'}</p>
        <div className="flex justify-center gap-4">
          <button
            onClick={onClose}
            className="px-6 py-2 bg-slate-600 font-semibold rounded-full shadow-lg transform hover:scale-105 transition-colors"
          >
            {cancelText || 'Mégse'}
          </button>
          <button
            onClick={onConfirm}
            className={`px-6 py-2 font-bold rounded-full shadow-lg transform hover:scale-105 transition-colors ${confirmButtonClass || 'bg-red-600'}`}
          >
            {confirmText || 'Igen, törlöm'}
          </button>
        </div>
      </div>
    </div>
  );
};

export default DeleteConfirmationModal;