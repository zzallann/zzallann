import React, { useState, useEffect } from 'react';
import type { Comment, User } from '../types';
import { avatars } from './AvatarSelector';
import UserStatusBadge from './UserStatusBadge';
import TrashIcon from './icons/TrashIcon';
import DeleteConfirmationModal from './DeleteConfirmationModal';
import { largeDataService } from '../services/largeDataService';

interface CommentCardProps {
    comment: Comment;
    currentUser: User;
    onToggleReaction: (reaction: string) => void;
    onDeleteComment: () => void;
}

const timeAgo = (timestamp: number): string => {
    const now = Date.now();
    const seconds = Math.floor((now - timestamp) / 1000);
    if (seconds < 60) return "épp most";
    const minutes = Math.floor(seconds / 60);
    if (minutes < 60) return `${minutes} perce`;
    const hours = Math.floor(minutes / 60);
    if (hours < 24) return `${hours} órája`;
    const days = Math.floor(hours / 24);
    return `${days} napja`;
};

const availableReactions = ['🔥', '😂', '🤯', '💯', '❤️', '😢'];

const HighlightMentions: React.FC<{ text: string }> = ({ text }) => {
    const parts = text.split(/(@\w+)/g);
    return (
        <>
            {parts.map((part, index) =>
                part.startsWith('@') ? (
                    <span key={index} className="font-bold text-blue-400">{part}</span>
                ) : (
                    part
                )
            )}
        </>
    );
};

const CommentCard: React.FC<CommentCardProps> = ({ comment, currentUser, onToggleReaction, onDeleteComment }) => {
    const { author, content, gifUrl, timestamp } = comment;
    const authorAvatar = avatars.find(a => a.id === author.avatarId);
    const [isReacting, setIsReacting] = useState(false);
    const [showDeleteModal, setShowDeleteModal] = useState(false);
    
    const [localComment, setLocalComment] = useState(comment);
    const [imageUrl, setImageUrl] = useState<string | null>(null);
    const [isLoadingMedia, setIsLoadingMedia] = useState(false);

    useEffect(() => { 
        setLocalComment(comment);
        
        let isMounted = true;
        const loadMedia = async () => {
            if (comment.imageUrl && comment.imageUrl.startsWith('idb_key:')) {
                setIsLoadingMedia(true);
                const data = await largeDataService.getItem<string>(comment.imageUrl.substring(8));
                if (isMounted) {
                    setImageUrl(data);
                    setIsLoadingMedia(false);
                }
            } else {
                setImageUrl(comment.imageUrl || null);
            }
        };
        
        loadMedia();
        return () => { isMounted = false; };
    }, [comment]);
    
    const userReaction = availableReactions.find(r => localComment.reactions[r]?.includes(currentUser.id));
    const canDelete = currentUser.id === author.id || currentUser.status === 'pro_max';

    const handleReactionClick = (reaction: string) => {
        // Optimistic update
        const newComment = JSON.parse(JSON.stringify(localComment)); // Deep copy
        newComment.reactions = newComment.reactions || {};
        
        let userPreviousReaction: string | null = null;
        for (const reactionKey in newComment.reactions) {
            if (newComment.reactions[reactionKey].includes(currentUser.id)) {
                userPreviousReaction = reactionKey;
                break;
            }
        }

        if (userPreviousReaction) {
            const userIndex = newComment.reactions[userPreviousReaction].indexOf(currentUser.id);
            newComment.reactions[userPreviousReaction].splice(userIndex, 1);
            if (newComment.reactions[userPreviousReaction].length === 0) {
                delete newComment.reactions[userPreviousReaction];
            }
        }

        if (userPreviousReaction !== reaction) {
            if (!newComment.reactions[reaction]) {
                newComment.reactions[reaction] = [];
            }
            newComment.reactions[reaction].push(currentUser.id);
        }

        setLocalComment(newComment);
        setIsReacting(false); // Close picker
        
        // Call parent to persist
        onToggleReaction(reaction);
    }

    return (
        <>
        <div className="flex items-start gap-3 animate-fade-in-up">
            <div className="w-10 h-10 rounded-full overflow-hidden flex-shrink-0 bg-slate-700/50">
                {author.uploadedImage ? (
                    <img src={author.uploadedImage} alt="Avatar" className="w-full h-full object-cover" />
                ) : authorAvatar ? (
                    <authorAvatar.component />
                ) : (
                    <div className="w-full h-full flex items-center justify-center text-xl font-bold text-white">
                        {author.name.charAt(0).toUpperCase()}
                    </div>
                )}
            </div>
            <div className="flex-1 relative">
                <div className="bg-slate-700/70 rounded-2xl p-3">
                    <div className="flex items-center gap-2">
                        <p className="font-bold text-white flex items-center text-sm">{author.name} <UserStatusBadge user={author} /></p>
                        <p className="text-xs text-white/60">{timeAgo(timestamp)}</p>
                         {canDelete && (
                             <button onClick={() => setShowDeleteModal(true)} title="Komment törlése" className="ml-auto p-1 rounded-full text-white/50 hover:bg-red-500/50 hover:text-white transition-colors">
                                <TrashIcon className="w-4 h-4" />
                            </button>
                        )}
                    </div>
                    {content && <p className="text-white/90 text-sm mt-1 whitespace-pre-wrap break-words"><HighlightMentions text={content} /></p>}
                    {isLoadingMedia && <div className="mt-2 rounded-lg w-32 h-24 bg-slate-600 animate-pulse" />}
                    {!isLoadingMedia && imageUrl && <img src={imageUrl} alt="Komment kép" className="mt-2 rounded-lg max-w-xs max-h-48" />}
                    {gifUrl && <img src={gifUrl} alt="Komment GIF" className="mt-2 rounded-lg max-w-xs max-h-48" />}
                </div>

                <div className="flex items-center gap-2 mt-1 px-2">
                    <button onClick={() => setIsReacting(!isReacting)} className="text-xs text-white/70 font-semibold hover:underline">Reagálás</button>
                    {localComment.reactions && Object.keys(localComment.reactions).length > 0 && (
                        <div className="flex gap-1">
                            {Object.entries(localComment.reactions).map(([reaction, userIds]) => {
                                const users = userIds as string[];
                                return users.length > 0 ? (
                                <div key={reaction} className="bg-slate-600/50 rounded-full flex items-center px-1.5 py-0.5 text-xs">
                                    <span className="text-sm">{reaction}</span>
                                    <span className="ml-1 text-white text-xs">{users.length}</span>
                                </div>
                                ) : null;
                            })}
                        </div>
                    )}
                </div>
                
                 {isReacting && (
                    <div className="absolute -top-10 z-10 left-0">
                        <div className="bg-slate-600 rounded-full shadow-lg flex p-1" onMouseLeave={() => setIsReacting(false)}>
                            {availableReactions.map(reaction => (
                                <button key={reaction} onClick={() => handleReactionClick(reaction)} className="p-1 text-2xl transform hover:scale-125 transition-transform">
                                    {reaction}
                                </button>
                            ))}
                        </div>
                    </div>
                )}
            </div>
        </div>
        <DeleteConfirmationModal
            isOpen={showDeleteModal}
            onClose={() => setShowDeleteModal(false)}
            onConfirm={() => {
                setShowDeleteModal(false);
                onDeleteComment();
            }}
            message="Biztosan törölni szeretnéd ezt a kommentet? A művelet nem vonható vissza."
        />
        </>
    );
};

export default CommentCard;
