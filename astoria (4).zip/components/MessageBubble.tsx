import React, { useState } from 'react';
import type { Message, User } from '../types';
import UserAvatarWithStatus from './UserAvatarWithStatus';

const availableReactions = ['🔥', '😂', '🤯', '💯', '❤️', '😢'];

interface MessageBubbleProps {
  message: Message;
  currentUser: User;
  sender: User | null;
  onToggleReaction: (messageId: string, reaction: string) => void;
  isReactionsDisabled?: boolean;
  isHighlighted?: boolean;
  isGroupChat: boolean;
  participants: User[];
  nicknames: Record<string, string>;
}

const MessageBubble: React.FC<MessageBubbleProps> = ({ message, currentUser, sender, onToggleReaction, isReactionsDisabled, isHighlighted, isGroupChat, participants, nicknames }) => {
    const [isReacting, setIsReacting] = useState(false);
    const isMyMessage = message.senderId === currentUser.id;
    
    const reactionEntries = Object.entries(message.reactions || {}).filter(([, userIds]) => (userIds as string[]).length > 0);

    return (
        <div id={`message-${message.id}`} className={`transition-all duration-1000 rounded-lg ${isHighlighted ? 'bg-orange-500/20' : ''}`}>
            <div className={`flex flex-col group p-1 ${isMyMessage ? 'items-end' : 'items-start'}`}>
                <div className={`flex items-end gap-2 ${isMyMessage ? 'flex-row-reverse' : ''}`}>
                    {!isMyMessage && sender && (
                        <UserAvatarWithStatus user={sender} size="x-small" />
                    )}
                    <div 
                        onDoubleClick={!isReactionsDisabled ? () => onToggleReaction(message.id, '❤️') : undefined}
                        className={`max-w-xs md:max-w-md p-3 rounded-2xl relative ${!isReactionsDisabled ? 'cursor-pointer': ''} ${isMyMessage ? 'bg-orange-600 text-white rounded-br-none' : 'bg-slate-600 text-white rounded-bl-none'}`}
                    >
                        {!isMyMessage && sender && isGroupChat && <p className="text-xs font-bold text-orange-300">{nicknames[sender.id] || sender.name}</p>}
                        {message.content && <p className="whitespace-pre-wrap break-words">{message.content}</p>}
                        {message.imageUrl && <img src={message.imageUrl} alt="Kép" className="mt-2 rounded-lg max-h-48" />}
                        {message.gifUrl && <img src={message.gifUrl} alt="GIF" className="mt-2 rounded-lg max-h-48" />}
                         {reactionEntries.length > 0 && (
                            <div className={`absolute -bottom-3 flex gap-1 ${isMyMessage ? 'left-1' : 'right-1'}`}>
                                {reactionEntries.map(([reaction, userIds]) => (
                                    <div key={reaction} className="bg-slate-700/80 backdrop-blur-sm rounded-full flex items-center px-1.5 py-0.5 text-xs shadow-md">
                                        <span className="text-sm">{reaction}</span>
                                        <span className="ml-1 text-white text-xs">{(userIds as string[]).length}</span>
                                    </div>
                                ))}
                            </div>
                        )}
                    </div>
                    {!isReactionsDisabled && (
                        <button onClick={() => setIsReacting(v => !v)} className="opacity-0 group-hover:opacity-100 transition-opacity text-white/50 text-xs self-center">
                            +
                        </button>
                    )}
                </div>
                
                {isReacting && (
                    <div className={`relative z-10 mt-1 ${isMyMessage ? 'mr-10' : 'ml-10'}`} onMouseLeave={() => setIsReacting(false)}>
                        <div className="bg-slate-800 rounded-full shadow-lg flex p-1 animate-fade-in">
                            {availableReactions.map(reaction => (
                                <button key={reaction} onClick={() => { onToggleReaction(message.id, reaction); setIsReacting(false); }} className="p-1 text-2xl transform hover:scale-125 transition-transform">
                                    {reaction}
                                </button>
                            ))}
                        </div>
                    </div>
                )}
            </div>
        </div>
    );
};

export default MessageBubble;