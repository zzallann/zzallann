import React, { useState, useEffect, useMemo } from 'react';
import type { User, Conversation } from '../types';
import { messageService } from '../services/messageService';
import { authService } from '../services/authService';
import { useNotification } from '../contexts/NotificationContext';
import ArrowLeftIcon from './icons/ArrowLeftIcon';
import SearchIcon from './icons/SearchIcon';
import UserAvatarWithStatus from './UserAvatarWithStatus';
import SendIcon from './icons/SendIcon';

interface CreateGroupChatPageProps {
    currentUser: User;
    onClose: () => void;
    onGroupCreated: (conversation: Conversation) => void;
}

const CreateGroupChatPage: React.FC<CreateGroupChatPageProps> = ({ currentUser, onClose, onGroupCreated }) => {
    const [allUsers, setAllUsers] = useState<User[]>([]);
    const [groupName, setGroupName] = useState('');
    const [selectedUserIds, setSelectedUserIds] = useState<string[]>([]);
    const [searchTerm, setSearchTerm] = useState('');
    const [isLoading, setIsLoading] = useState(false);
    const { addNotification } = useNotification();

    useEffect(() => {
        const users = authService.getAllUsers().filter(u => u.id !== currentUser.id && u.approved);
        setAllUsers(users.sort((a,b) => a.name.localeCompare(b.name)));
    }, [currentUser.id]);
    
    const filteredUsers = useMemo(() => {
        if (!searchTerm.trim()) return allUsers;
        const lowerCaseSearch = searchTerm.toLowerCase();
        return allUsers.filter(u => u.name.toLowerCase().includes(lowerCaseSearch) || u.fullName.toLowerCase().includes(lowerCaseSearch));
    }, [searchTerm, allUsers]);

    const handleUserToggle = (userId: string) => {
        setSelectedUserIds(prev =>
            prev.includes(userId)
                ? prev.filter(id => id !== userId)
                : [...prev, userId]
        );
    };

    const handleCreateGroup = async () => {
        if (!groupName.trim()) {
            addNotification("A csoport nevét meg kell adni.", 'error');
            return;
        }
        if (selectedUserIds.length < 1) { // A group needs at least one other person besides the creator
            addNotification("Legalább egy személyt ki kell választanod.", 'error');
            return;
        }
        
        setIsLoading(true);
        try {
            const newConversation = await messageService.createGroupConversation(currentUser, selectedUserIds, groupName.trim());
            addNotification("Csoport sikeresen létrehozva!", 'success');
            onGroupCreated(newConversation);
        } catch (error) {
            addNotification("Hiba a csoport létrehozásakor.", 'error');
        } finally {
            setIsLoading(false);
        }
    };
    
    return (
        <div className="w-full h-full flex flex-col bg-slate-800/60 backdrop-blur-md md:rounded-2xl">
            {/* Header */}
            <div className="flex items-center p-3 border-b border-white/20 flex-shrink-0">
                <button onClick={onClose} className="p-2 mr-2 rounded-full hover:bg-white/10">
                    <ArrowLeftIcon className="w-6 h-6 text-white"/>
                </button>
                <h2 className="font-bold text-white text-lg">Új csoportos chat</h2>
            </div>
            
            {/* Content */}
            <div className="flex-1 overflow-y-auto p-4 space-y-4">
                <div>
                    <label htmlFor="group-name" className="block font-semibold text-white mb-1">Csoport neve</label>
                    <input
                        id="group-name"
                        type="text"
                        value={groupName}
                        onChange={(e) => setGroupName(e.target.value)}
                        placeholder="Pl. Hétvégi műszak"
                        className="w-full bg-slate-700 text-white p-2 rounded-lg"
                    />
                </div>
                
                <div>
                     <label className="block font-semibold text-white mb-1">Résztvevők</label>
                     <div className="relative">
                        <span className="absolute left-3 top-1/2 -translate-y-1/2">
                            <SearchIcon className="w-5 h-5 text-slate-400"/>
                        </span>
                        <input
                            type="text"
                            value={searchTerm}
                            onChange={(e) => setSearchTerm(e.target.value)}
                            placeholder="Keresés a kollégák között..."
                            className="w-full bg-slate-700 text-white pl-10 pr-4 py-2 rounded-full text-sm"
                        />
                     </div>
                </div>

                <div className="bg-slate-900/40 rounded-lg p-2 max-h-64 overflow-y-auto">
                    {filteredUsers.map(user => (
                        <label key={user.id} className="flex items-center gap-3 p-2 rounded-md hover:bg-slate-600/50 cursor-pointer">
                            <input
                                type="checkbox"
                                checked={selectedUserIds.includes(user.id)}
                                onChange={() => handleUserToggle(user.id)}
                                className="h-5 w-5 rounded bg-slate-800 border-slate-500 text-orange-500 focus:ring-orange-500 flex-shrink-0"
                            />
                            <UserAvatarWithStatus user={user} size="small" />
                            <span className="font-semibold text-white">{user.name}</span>
                        </label>
                    ))}
                </div>
            </div>
            
            {/* Footer */}
            <div className="p-4 border-t border-white/20">
                <button
                    onClick={handleCreateGroup}
                    disabled={isLoading || !groupName.trim() || selectedUserIds.length < 1}
                    className="w-full flex items-center justify-center gap-2 px-4 py-3 bg-orange-600 text-white font-bold rounded-full text-lg shadow-lg disabled:bg-slate-500"
                >
                    <SendIcon className="w-5 h-5" />
                    <span>Chat létrehozása ({selectedUserIds.length} fő)</span>
                </button>
            </div>
        </div>
    );
};

export default CreateGroupChatPage;