import React, { useState, useEffect, useMemo } from 'react';
import type { User, WasteLog, WasteMenuItem } from '../types';
import AccordionItem from './AccordionItem';
import SendIcon from './icons/SendIcon';
import PlusIcon from './icons/PlusIcon';
import MinusIcon from './icons/MinusIcon';
import { useNotification } from '../contexts/NotificationContext';
import { wasteService } from '../services/wasteService';
import { mealService } from '../services/mealService';
import SearchIcon from './icons/SearchIcon';
import ArrowLeftIcon from './icons/ArrowLeftIcon';
import PencilIcon from './icons/PencilIcon';
import TrashIcon from './icons/TrashIcon';
import SaveIcon from './icons/SaveIcon';

interface SelectedItem {
    name: string;
    quantity: number;
    unit: 'db' | 'kg' | 'l';
}

const SortingView = ({ onBack }: { onBack: () => void }) => {
    const [sortedItems, setSortedItems] = useState<{ name: string; quantity: number; unit: 'db' | 'kg' | 'l' }[]>([]);
    const [isLoading, setIsLoading] = useState(true);
    const [masterWasteMenu, setMasterWasteMenu] = useState<Record<string, WasteMenuItem[]>>({});

    useEffect(() => {
        const fetchAndSortData = async () => {
            setIsLoading(true);
            const [wasteMenu, wasteLogs, mealLogs] = await Promise.all([
                wasteService.getMenu(),
                wasteService.getTodaysLogs(),
                mealService.getTodaysLogs()
            ]);
            setMasterWasteMenu(wasteMenu);
            const masterItemList = Object.values(wasteMenu).flat().map(i => i.name);

            const allItems: { name: string; quantity: number }[] = [];
            wasteLogs.forEach(log => allItems.push(...log.items));
            mealLogs.forEach(log => {
                log.items.forEach(item => {
                    const lowerCaseName = item.name.toLowerCase();
                    if (!lowerCaseName.includes('hozzájárulás') && !lowerCaseName.includes('műszak')) {
                         allItems.push({ name: item.name, quantity: item.quantity });
                    }
                });
            });

            const groupedItems: Record<string, number> = allItems.reduce((acc, item) => {
                acc[item.name] = (acc[item.name] || 0) + item.quantity;
                return acc;
            }, {} as Record<string, number>);

            const allWasteItemsMap = new Map(Object.values(wasteMenu).flat().map(i => [i.name, i.unit]));

            const sorted = Object.entries(groupedItems)
                .map(([name, quantity]) => ({ name, quantity, unit: allWasteItemsMap.get(name) || 'db' }))
                .sort((a, b) => {
                    const indexA = masterItemList.indexOf(a.name);
                    const indexB = masterItemList.indexOf(b.name);
                    if (indexA === -1 && indexB === -1) return a.name.localeCompare(b.name);
                    if (indexA === -1) return 1;
                    if (indexB === -1) return -1;
                    return indexA - indexB;
                });
            
            setSortedItems(sorted);
            setIsLoading(false);
        };

        fetchAndSortData();
    }, []);

    if (isLoading) {
        return <div className="text-center text-white">Adatok rendezése...</div>;
    }

    return (
        <div className="w-full max-w-2xl mx-auto animate-fade-in space-y-6 text-white">
            <div className="flex items-center gap-4">
                <button onClick={onBack} className="p-2 rounded-full hover:bg-white/10">
                    <ArrowLeftIcon className="w-6 h-6 text-white"/>
                </button>
                <h1 className="text-3xl sm:text-4xl font-bold font-lilita tracking-wide">Rendezett Lista</h1>
            </div>
            <div className="bg-slate-800/40 backdrop-blur-sm p-4 rounded-2xl">
                {sortedItems.length === 0 ? (
                    <p className="text-center text-white/70">Ma még nem volt selejt vagy fogyasztás rögzítve.</p>
                ) : (
                    <ul className="space-y-2 max-h-[70vh] overflow-y-auto pr-2">
                        {sortedItems.map(item => (
                            <li key={item.name} className="flex justify-between items-center p-3 bg-slate-900/40 rounded-lg">
                                <span className="font-semibold">{item.name}</span>
                                <span className="font-bold text-lg text-amber-400">{item.quantity} {item.unit}</span>
                            </li>
                        ))}
                    </ul>
                )}
            </div>
        </div>
    );
};


const WasteLoggingPage: React.FC<{ user: User }> = ({ user }) => {
    const [view, setView] = useState<'logging' | 'sorting'>('logging');
    const [openAccordion, setOpenAccordion] = useState<string | null>(null);
    const [selectedItems, setSelectedItems] = useState<Record<string, SelectedItem>>({});
    const [isSubmitting, setIsSubmitting] = useState(false);
    const [todaysLogs, setTodaysLogs] = useState<WasteLog[]>([]);
    const [isLoadingLogs, setIsLoadingLogs] = useState(true);
    const [searchTerm, setSearchTerm] = useState('');
    const { addNotification } = useNotification();

    const [menuData, setMenuData] = useState<Record<string, WasteMenuItem[]>>({});
    const [isLoadingMenu, setIsLoadingMenu] = useState(true);
    const [isEditMode, setIsEditMode] = useState(false);
    
    const [isModalOpen, setIsModalOpen] = useState(false);
    const [editingItem, setEditingItem] = useState<{item: WasteMenuItem, category: string, isNew: boolean} | null>(null);
    const [modalData, setModalData] = useState<{name: string, unit: 'db' | 'kg' | 'l'}>({name: '', unit: 'db'});

    const isProUser = user.status === 'pro' || user.status === 'pro_max';

    const fetchMenu = async () => {
        setIsLoadingMenu(true);
        const menu = await wasteService.getMenu();
        setMenuData(menu);
        setIsLoadingMenu(false);
    };

    useEffect(() => {
        fetchMenu();
    }, []);

    const filteredMenuData = useMemo(() => {
        if (!searchTerm.trim()) return menuData;
        const lowercasedFilter = searchTerm.toLowerCase();
        const filtered: Record<string, WasteMenuItem[]> = {};
        for (const category in menuData) {
            const matchingItems = menuData[category].filter(item => item.name.toLowerCase().includes(lowercasedFilter));
            if (matchingItems.length > 0) filtered[category] = matchingItems;
        }
        return filtered;
    }, [searchTerm, menuData]);

    const fetchLogs = async () => {
        setIsLoadingLogs(true);
        const logs = await wasteService.getTodaysLogs();
        setTodaysLogs(logs);
        setIsLoadingLogs(false);
    };

    useEffect(() => {
        fetchLogs();
    }, []);

    const handleToggleAccordion = (title: string) => {
        setOpenAccordion(openAccordion === title ? null : title);
    };

    const handleQuantityChange = (item: WasteMenuItem, change: 1 | -1) => {
        setSelectedItems(prev => {
            const existingItem = prev[item.name];
            const newQuantity = (existingItem?.quantity || 0) + change;
            const newItems = { ...prev };
            if (newQuantity <= 0) delete newItems[item.name];
            else newItems[item.name] = { ...item, quantity: newQuantity };
            return newItems;
        });
    };
    
    const handleDecimalQuantityChange = (item: WasteMenuItem, value: string) => {
        const newQuantity = parseFloat(value);
        setSelectedItems(prev => {
            const newItems = { ...prev };
            if (isNaN(newQuantity) || newQuantity <= 0) delete newItems[item.name];
            else newItems[item.name] = { ...item, quantity: newQuantity };
            return newItems;
        });
    };

    const totalItemsCount = Object.keys(selectedItems).length;

    const handleSubmit = async () => {
        if (totalItemsCount === 0) {
            addNotification('Nincs tétel kiválasztva.', 'error');
            return;
        }
        setIsSubmitting(true);
        try {
            const itemsArray = Object.values(selectedItems).map(({ name, quantity }) => ({ name, quantity }));
            await wasteService.logWaste(user, itemsArray);
            addNotification('Selejt sikeresen rögzítve!', 'success');
            setSelectedItems({});
            fetchLogs();
        } catch (error) { addNotification('Hiba a rögzítéskor.', 'error'); } 
        finally { setIsSubmitting(false); }
    };
    
    const handleOpenModal = (item: WasteMenuItem | null, category: string) => {
        if (item) {
            setEditingItem({ item, category, isNew: false });
            setModalData({ name: item.name, unit: item.unit });
        } else {
            setEditingItem({ item: { name: '', unit: 'db' }, category, isNew: true });
            setModalData({ name: '', unit: 'db' });
        }
        setIsModalOpen(true);
    };

    const handleCloseModal = () => {
        setIsModalOpen(false);
        setEditingItem(null);
    };

    const handleSaveItem = () => {
        if (!editingItem) return;
        if (!modalData.name.trim()) {
            addNotification('A név nem lehet üres.', 'error');
            return;
        }
        const oldName = editingItem.isNew ? null : editingItem.item.name;
        const newItem: WasteMenuItem = { name: modalData.name.trim(), unit: modalData.unit };

        setMenuData(prevMenu => {
            const newMenu = JSON.parse(JSON.stringify(prevMenu));
            const targetCategory = editingItem.category;
            
            if (oldName && oldName !== newItem.name) {
                 const itemExists = Object.values(newMenu).flat().some((i: any) => i.name === newItem.name);
                if (itemExists) {
                    addNotification('Már létezik ilyen nevű tétel.', 'error');
                    return prevMenu;
                }
            }

            if (oldName) {
                const categoryItems = newMenu[targetCategory] as WasteMenuItem[];
                const itemIndex = categoryItems.findIndex(i => i.name === oldName);
                if (itemIndex > -1) categoryItems.splice(itemIndex, 1);
            }
            if (!newMenu[targetCategory]) newMenu[targetCategory] = [];
            newMenu[targetCategory].push(newItem);
            newMenu[targetCategory].sort((a: WasteMenuItem, b: WasteMenuItem) => a.name.localeCompare(b.name));
            return newMenu;
        });
        handleCloseModal();
    };

    const handleDeleteItem = (itemToDelete: WasteMenuItem, category: string) => {
        if (window.confirm(`Biztosan törlöd a következőt: ${itemToDelete.name}? A művelet nem vonható vissza.`)) {
            setMenuData(prevMenu => {
                // FIX: Corrected variable name from 'prev' to 'prevMenu'.
                const newMenu = { ...prevMenu };
                newMenu[category] = newMenu[category].filter(i => i.name !== itemToDelete.name);
                return newMenu;
            });
        }
    };
    
    const handleSaveMenu = async () => {
        await wasteService.saveMenu(menuData);
        addNotification("Selejt menü sikeresen elmentve!", "success");
        setIsEditMode(false);
    };


    if (view === 'sorting') {
        return <SortingView onBack={() => setView('logging')} />;
    }
    
    const pageTitle = isEditMode ? "Selejt Menü Szerkesztése" : "Selejt Rögzítése";

    return (
        <div className="w-full max-w-2xl mx-auto animate-fade-in space-y-6 text-white">
            <div className="flex justify-center items-center gap-4">
                <h1 className="text-3xl font-bold font-lilita tracking-wide text-center">{pageTitle}</h1>
                {isProUser && (
                    <button onClick={() => setIsEditMode(prev => !prev)} title="Szerkesztés mód" className={`p-2 rounded-full text-white transition-colors ${isEditMode ? 'bg-orange-600' : 'bg-slate-700/50 hover:bg-slate-600/50'}`}>
                        <PencilIcon className="w-6 h-6" />
                    </button>
                )}
            </div>
            <div className="bg-slate-800/30 backdrop-blur-sm rounded-2xl shadow-lg p-6">
                <h2 className="text-2xl font-bold font-lilita mb-4 border-b-2 border-slate-600 pb-2">Termékek</h2>
                {isEditMode && (
                     <div className="flex justify-between items-center mb-4 p-2 bg-slate-900/30 rounded-lg">
                        <button onClick={() => handleOpenModal(null, Object.keys(menuData)[0] || 'Egyéb')} className="flex items-center gap-2 px-4 py-2 bg-green-600 text-white font-bold rounded-full text-sm">
                            <PlusIcon className="w-5 h-5"/> Új tétel
                        </button>
                        <button onClick={handleSaveMenu} className="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white font-bold rounded-full text-sm">
                            <SaveIcon className="w-5 h-5"/> Változtatások mentése
                        </button>
                     </div>
                )}
                <div className="mb-4 relative">
                    <input type="text" placeholder="Keresés a tételek között..." value={searchTerm} onChange={(e) => setSearchTerm(e.target.value)} className="w-full bg-slate-700 text-white p-2 rounded-lg pl-10"/>
                    <SearchIcon className="w-5 h-5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2"/>
                </div>

                <div className="bg-slate-900/30 rounded-lg overflow-hidden">
                    {isLoadingMenu ? <p className="text-center p-4">Menü betöltése...</p> : Object.keys(filteredMenuData).map(category => (
                        <AccordionItem key={category} title={category} isOpen={openAccordion === category || !!searchTerm.trim() || isEditMode} onClick={() => handleToggleAccordion(category)}>
                           <div className="space-y-3 max-h-[30vh] overflow-y-auto pr-2">
                                {isEditMode && (<button onClick={() => handleOpenModal(null, category)} className="text-sm text-green-400 font-semibold flex items-center gap-1"><PlusIcon className="w-4 h-4"/> Új tétel ebben a kategóriában</button>)}
                                {filteredMenuData[category].map(item => {
                                    const selectedQuantity = selectedItems[item.name]?.quantity || 0;
                                    return (
                                        <div key={item.name} className="flex items-center justify-between p-2 rounded-md hover:bg-white/10 transition-colors">
                                            <p className="font-semibold text-white">{item.name}</p>
                                            {isEditMode ? (
                                                <div className="flex items-center gap-2"><button onClick={() => handleOpenModal(item, category)} className="p-2 text-blue-400 hover:text-blue-300"><PencilIcon className="w-5 h-5"/></button><button onClick={() => handleDeleteItem(item, category)} className="p-2 text-red-400 hover:text-red-300"><TrashIcon className="w-5 h-5"/></button></div>
                                            ) : item.unit === 'db' ? (
                                                <div className="flex items-center gap-2"><button onClick={() => handleQuantityChange(item, -1)} className="p-1 rounded-full bg-orange-600/80 text-white hover:bg-orange-600 disabled:bg-gray-500" disabled={selectedQuantity === 0}><MinusIcon className="w-5 h-5"/></button><span className="w-8 text-center font-bold text-white text-lg">{selectedQuantity}</span><button onClick={() => handleQuantityChange(item, 1)} className="p-1 rounded-full bg-orange-600/80 text-white hover:bg-orange-600"><PlusIcon className="w-5 h-5"/></button></div>
                                            ) : (
                                                <div className="flex items-center gap-2"><input type="number" step="0.01" min="0" value={selectedQuantity === 0 ? '' : String(selectedQuantity)} onChange={(e) => handleDecimalQuantityChange(item, e.target.value)} className="w-24 bg-slate-800 text-white text-center rounded-md p-1 [appearance:textfield] [&::-webkit-outer-spin-button]:appearance-none [&::-webkit-inner-spin-button]:appearance-none" placeholder="0.00"/><span className="font-bold text-white/80 w-4 text-left">{item.unit}</span></div>
                                            )}
                                        </div>
                                    );
                                })}
                            </div>
                        </AccordionItem>
                    ))}
                </div>
                 <div className="mt-6 pt-4 border-t-2 border-white/20">
                    <p className="text-white font-bold mb-4">{totalItemsCount} tétel kiválasztva</p>
                    <button onClick={handleSubmit} disabled={isSubmitting || totalItemsCount === 0 || isEditMode} className="w-full flex items-center justify-center gap-2 px-4 py-3 bg-orange-600 text-white font-bold rounded-full text-lg shadow-lg transform hover:scale-105 transition-transform duration-200 disabled:bg-slate-500 disabled:cursor-not-allowed">
                        <SendIcon className="w-5 h-5" />
                        <span>{isSubmitting ? 'Rögzítés...' : 'Tételek Rögzítése'}</span>
                    </button>
                </div>
            </div>

             <div className="bg-slate-800/30 backdrop-blur-sm rounded-2xl shadow-lg p-6">
                 <div className="flex justify-between items-center mb-4 border-b-2 border-slate-600 pb-2">
                    <h2 className="text-2xl font-bold font-lilita">Mai selejt összegző</h2>
                    <button onClick={() => setView('sorting')} className="px-3 py-1 bg-blue-600 text-white font-bold text-sm rounded-full shadow-lg transform hover:scale-105 transition-transform">Rendezett Lista</button>
                </div>
                {isLoadingLogs ? <p>Betöltés...</p> : todaysLogs.length === 0 ? <p>Ma még nem volt selejt rögzítve.</p> : (
                    <div className="space-y-3 max-h-60 overflow-y-auto pr-2">
                        {todaysLogs.map(log => (
                            <div key={log.id} className="bg-slate-900/40 p-3 rounded-lg text-sm">
                                <ul className="list-disc list-inside">
                                    {log.items.map(item => (
                                        <li key={item.name}>{item.name} <span className="text-white/70">x{item.quantity} {menuData[Object.keys(menuData).find(cat => menuData[cat].some(i => i.name === item.name)) || '']?.find(i => i.name === item.name)?.unit || 'db'}</span></li>
                                    ))}
                                </ul>
                                <p className="text-xs text-right text-white/60 mt-1">Rögzítette: {log.userName} ({new Date(log.timestamp).toLocaleTimeString('hu-HU', { hour: '2-digit', minute: '2-digit' })})</p>
                            </div>
                        ))}
                    </div>
                )}
            </div>

            {isModalOpen && editingItem && (
                 <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex justify-center items-center z-50" onClick={handleCloseModal}>
                    <div className="bg-slate-800 w-full max-w-md rounded-2xl p-6 text-white" onClick={e => e.stopPropagation()}>
                        <h3 className="text-2xl font-bold font-lilita mb-4">{editingItem.isNew ? 'Új selejt tétel' : 'Tétel szerkesztése'}</h3>
                        <div className="space-y-4">
                            <div><label className="font-semibold">Név</label><input type="text" value={modalData.name} onChange={e => setModalData(d => ({...d, name: e.target.value}))} className="w-full bg-slate-700 p-2 rounded mt-1"/></div>
                            <div>
                                <label className="font-semibold">Mértékegység</label>
                                <div className="flex gap-4 mt-2">
                                    <label className="flex items-center gap-2"><input type="radio" name="unit" value="db" checked={modalData.unit === 'db'} onChange={() => setModalData(d => ({...d, unit: 'db'}))} className="accent-orange-500"/> db</label>
                                    <label className="flex items-center gap-2"><input type="radio" name="unit" value="kg" checked={modalData.unit === 'kg'} onChange={() => setModalData(d => ({...d, unit: 'kg'}))} className="accent-orange-500"/> kg</label>
                                    <label className="flex items-center gap-2"><input type="radio" name="unit" value="l" checked={modalData.unit === 'l'} onChange={() => setModalData(d => ({...d, unit: 'l'}))} className="accent-orange-500"/> l</label>
                                </div>
                            </div>
                        </div>
                        <div className="flex gap-4 mt-6">
                            <button onClick={handleSaveItem} className="flex-1 py-2 bg-green-600 rounded-full font-bold">Mentés</button>
                            <button onClick={handleCloseModal} className="flex-1 py-2 bg-slate-600 rounded-full">Mégse</button>
                        </div>
                    </div>
                 </div>
            )}
        </div>
    );
};

export default WasteLoggingPage;