import React from 'react';

interface PlaceholderPageProps {
    title: string;
}

const PlaceholderPage: React.FC<PlaceholderPageProps> = ({ title }) => {
    return (
        <div className="flex-1 flex flex-col items-center justify-center text-center p-4">
            <div className="bg-[var(--component-bg)] backdrop-blur-sm p-8 sm:p-12 rounded-2xl animate-fade-in">
                <h1 className="text-3xl sm:text-4xl font-bold text-[var(--text-primary)] font-lilita tracking-wide mb-4">{title}</h1>
                <p className="text-[var(--text-secondary)] text-lg">Ez az oldal fejlesztés alatt áll.</p>
            </div>
        </div>
    );
};

export default PlaceholderPage;