import React, { useState, useRef } from 'react';
import type { User, Poll } from '../types';
import { avatars } from './AvatarSelector';
import GifIcon from './icons/GifIcon';
import SendIcon from './icons/SendIcon';
import ImageIcon from './icons/ImageIcon';
import VideoIcon from './icons/VideoIcon';
import PollIcon from './icons/PollIcon';
import TrashIcon from './icons/TrashIcon';
import EmojiIcon from './icons/EmojiIcon';
import EmojiPicker from './EmojiPicker';
import { useNotification } from '../contexts/NotificationContext';

interface PostCreatorProps {
  user: User;
  onCreatePost: (
      content: string | null, 
      gifUrl: string | null, 
      imageFile: File | null,
      videoFile: File | null,
      poll: Poll | null
  ) => Promise<void>;
}

const PostCreator: React.FC<PostCreatorProps> = ({ user, onCreatePost }) => {
  const [content, setContent] = useState('');
  const [selectedGif, setSelectedGif] = useState<string | null>(null);
  const [imageFile, setImageFile] = useState<File | null>(null);
  const [videoFile, setVideoFile] = useState<File | null>(null);
  const [poll, setPoll] = useState<Poll | null>(null);

  const [showGifInput, setShowGifInput] = useState(false);
  const [showEmojiPicker, setShowEmojiPicker] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  
  const imageInputRef = useRef<HTMLInputElement>(null);
  const videoInputRef = useRef<HTMLInputElement>(null);
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const selectedAvatar = avatars.find((a) => a.id === user.avatarId);
  const { addNotification } = useNotification();

  const clearAttachments = () => {
    setSelectedGif(null);
    setImageFile(null);
    setVideoFile(null);
    setPoll(null);
    setShowGifInput(false);
    if(imageInputRef.current) imageInputRef.current.value = '';
    if(videoInputRef.current) videoInputRef.current.value = '';
  }

  const handleSubmit = async () => {
    if (!content.trim() && !selectedGif && !imageFile && !videoFile && !poll) return;

    // Auto-detect GIF url from content
    const gifUrlRegex = /(https?:\/\/\S+?\.gif)/;
    const match = content.match(gifUrlRegex);
    const finalGifUrl = selectedGif || (match ? match[0] : null);
    const finalContent = finalGifUrl ? content.replace(finalGifUrl, '') : content;

    setIsSubmitting(true);
    await onCreatePost(finalContent || null, finalGifUrl, imageFile, videoFile, poll);
    
    setContent('');
    clearAttachments();
    setIsSubmitting(false);
  };
  
  const handleSelectGifUrl = (url: string) => {
    clearAttachments();
    setSelectedGif(url);
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
      const file = e.target.files?.[0];
      if (!file) return;
      
      clearAttachments();
      setImageFile(file);
  }

  const handleVideoFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const MAX_SIZE = 20 * 1024 * 1024; // 20 MB
    const MAX_DURATION = 15; // 15 seconds

    if (file.size > MAX_SIZE) {
        addNotification(`A videó mérete nem haladhatja meg a 20 MB-ot.`, 'error');
        if (videoInputRef.current) videoInputRef.current.value = '';
        return;
    }

    const video = document.createElement('video');
    video.preload = 'metadata';
    video.onloadedmetadata = function() {
        window.URL.revokeObjectURL(video.src);
        if (video.duration > MAX_DURATION) {
            addNotification(`A videó hossza nem haladhatja meg a 15 másodpercet.`, 'error');
            if (videoInputRef.current) videoInputRef.current.value = '';
        } else {
            clearAttachments();
            setVideoFile(file);
        }
    }
    video.onerror = function() {
        addNotification('Nem sikerült beolvasni a videófájlt.', 'error');
        if (videoInputRef.current) videoInputRef.current.value = '';
    };
    video.src = URL.createObjectURL(file);
  };

  const handleCreatePoll = () => {
    clearAttachments();
    setPoll({ question: '', options: [{text: '', votes:[]}, {text: '', votes:[]}] });
  }

  const handlePollChange = (field: 'question' | 'option', value: string, optionIndex?: number) => {
      if(!poll) return;
      if (field === 'question') {
          setPoll({ ...poll, question: value });
      }
      if (field === 'option' && optionIndex !== undefined) {
          const newOptions = [...poll.options];
          newOptions[optionIndex] = {...newOptions[optionIndex], text: value};
          setPoll({ ...poll, options: newOptions });
      }
  }

  const addPollOption = () => {
      if(poll && poll.options.length < 4) {
          setPoll({ ...poll, options: [...poll.options, {text: '', votes:[]}] });
      }
  }
  
  const removePollOption = (index: number) => {
      if(poll && poll.options.length > 2) {
          const newOptions = poll.options.filter((_, i) => i !== index);
          setPoll({...poll, options: newOptions});
      }
  }

  const handleEmojiSelect = (emoji: string) => {
    const textarea = textareaRef.current;
    if (textarea) {
        const start = textarea.selectionStart;
        const end = textarea.selectionEnd;
        const newContent = content.substring(0, start) + emoji + content.substring(end);
        setContent(newContent);
        // Move cursor after the inserted emoji
        setTimeout(() => {
            textarea.selectionStart = textarea.selectionEnd = start + emoji.length;
            textarea.focus();
        }, 0);
    }
  };

  const canPost = content.trim() || selectedGif || imageFile || videoFile || poll;
  const attachmentType = selectedGif ? 'gif' : imageFile ? 'image' : videoFile ? 'video' : poll ? 'poll' : null;

  return (
    <div className="relative bg-[var(--component-bg)] backdrop-blur-sm p-4 rounded-2xl shadow-lg w-full animate-fade-in-down z-10">
      <div className="flex gap-4">
        <div className="w-12 h-12 rounded-full overflow-hidden flex-shrink-0 bg-slate-700/50">
          {user.uploadedImage ? (
            <img src={user.uploadedImage} alt="Avatar" className="w-full h-full object-cover" />
          ) : selectedAvatar ? (
            <selectedAvatar.component />
          ) : (
            <div className="w-full h-full flex items-center justify-center text-2xl font-bold text-[var(--text-primary)]">
              {user.name.charAt(0).toUpperCase()}
            </div>
          )}
        </div>
        <div className="flex-1 relative">
          <textarea
            ref={textareaRef}
            value={content}
            onChange={(e) => setContent(e.target.value)}
            placeholder={`Mi jár a fejedben, ${user.name}?`}
            className="w-full bg-[var(--input-bg)] text-[var(--text-primary)] placeholder:text-[var(--text-tertiary)] p-3 pr-12 rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500 transition resize-none"
            rows={3}
            disabled={isSubmitting}
          />
           <div className="absolute bottom-2 right-2">
              <button onClick={() => setShowEmojiPicker(v => !v)} disabled={isSubmitting} className="p-2 rounded-full hover:bg-black/20 transition-colors" title="Emoji beszúrása">
                  <EmojiIcon className="w-6 h-6 text-[var(--text-primary)] opacity-50 hover:opacity-100"/>
              </button>
              {showEmojiPicker && (
                <>
                  <div className="fixed inset-0 z-[90]" onClick={() => setShowEmojiPicker(false)}></div>
                  <div className="absolute top-full right-0 mt-2 z-[100]">
                    <EmojiPicker onSelectEmoji={handleEmojiSelect} />
                  </div>
                </>
              )}
            </div>
        </div>
      </div>

      {/* Attachment Previews */}
      <div className="pl-16 mt-2 space-y-2">
          {imageFile && <p className="text-[var(--text-primary)] text-sm">Kép: {imageFile.name}</p>}
          {videoFile && <p className="text-[var(--text-primary)] text-sm">Videó: {videoFile.name}</p>}
          {selectedGif && (
              <div className="relative w-48">
                  <img src={selectedGif} alt="Kiválasztott GIF" className="rounded-lg w-full h-auto" />
                  <button onClick={clearAttachments} className="absolute -top-2 -right-2 bg-orange-600 text-white rounded-full w-6 h-6 flex items-center justify-center font-bold text-sm">&times;</button>
              </div>
          )}
          {poll && (
              <div className="space-y-2 p-3 bg-slate-700/50 rounded-lg">
                  <input type="text" placeholder="Szavazás kérdése..." value={poll.question} onChange={e => handlePollChange('question', e.target.value)} className="w-full bg-[var(--input-bg)] text-[var(--text-primary)] p-2 rounded-md" />
                  {poll.options.map((opt, index) => (
                      <div key={index} className="flex items-center gap-2">
                         <input type="text" placeholder={`Opció ${index + 1}`} value={opt.text} onChange={e => handlePollChange('option', e.target.value, index)} className="flex-1 bg-[var(--input-bg)] text-[var(--text-primary)] p-2 rounded-md" />
                         {poll.options.length > 2 && <button onClick={() => removePollOption(index)}><TrashIcon className="w-5 h-5 text-red-400"/></button>}
                      </div>
                  ))}
                  {poll.options.length < 4 && <button onClick={addPollOption} className="text-sm text-orange-400 hover:underline">Opció hozzáadása</button>}
              </div>
          )}
          {showGifInput && (
            <div className="mt-2">
                <input
                    type="url"
                    placeholder="GIF URL beillesztése..."
                    value={selectedGif || ''}
                    onChange={(e) => handleSelectGifUrl(e.target.value)}
                    className="w-full bg-[var(--input-bg)] text-[var(--text-primary)] placeholder:text-[var(--text-tertiary)] p-3 rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500 transition"
                    autoFocus
                />
            </div>
          )}
      </div>

      <div className="flex justify-between items-center mt-3">
          <div className="flex items-center gap-1">
            <input type="file" accept="image/*" ref={imageInputRef} onChange={handleFileChange} className="hidden" />
            <input type="file" accept="video/*" ref={videoInputRef} onChange={handleVideoFileChange} className="hidden" />
            
            <button onClick={() => imageInputRef.current?.click()} disabled={isSubmitting || !!attachmentType} className="p-2 rounded-full hover:bg-[var(--component-bg-hover)] transition-colors disabled:opacity-50" title="Kép hozzáadása">
                <ImageIcon className="w-6 h-6 text-[var(--text-primary)]"/>
            </button>
            <button onClick={() => videoInputRef.current?.click()} disabled={isSubmitting || !!attachmentType} className="p-2 rounded-full hover:bg-[var(--component-bg-hover)] transition-colors disabled:opacity-50" title="Videó hozzáadása">
                <VideoIcon className="w-6 h-6 text-[var(--text-primary)]"/>
            </button>
            <button onClick={() => setShowGifInput(v => !v)} disabled={isSubmitting || !!attachmentType} className="p-2 rounded-full hover:bg-[var(--component-bg-hover)] transition-colors disabled:opacity-50" title="GIF hozzáadása URL-ből">
                <GifIcon className="w-6 h-6 text-[var(--text-primary)]"/>
            </button>
            <button onClick={handleCreatePoll} disabled={isSubmitting || !!attachmentType} className="p-2 rounded-full hover:bg-[var(--component-bg-hover)] transition-colors disabled:opacity-50" title="Szavazás létrehozása">
                <PollIcon className="w-6 h-6 text-[var(--text-primary)]"/>
            </button>
          </div>
          <button
              onClick={handleSubmit}
              disabled={isSubmitting || !canPost}
              className="flex items-center gap-2 px-4 py-2 bg-orange-600 text-white font-bold rounded-full shadow-lg transform hover:scale-105 transition-transform duration-200 disabled:bg-orange-400 disabled:scale-100 disabled:cursor-not-allowed"
          >
              <SendIcon className="w-5 h-5" />
              <span>{isSubmitting ? 'Küldés...' : 'Közzététel'}</span>
          </button>
      </div>
      
    </div>
  );
};

export default PostCreator;
