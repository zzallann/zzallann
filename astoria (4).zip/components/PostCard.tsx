import React, { useState, useEffect } from 'react';
import type { Post, User, PollOption } from '../types';
import { avatars } from './AvatarSelector';
import LinkPreview from './LinkPreview';
import TrashIcon from './icons/TrashIcon';
import UserStatusBadge from './UserStatusBadge';
import DeleteConfirmationModal from './DeleteConfirmationModal';
import { largeDataService } from '../services/largeDataService';

interface PostCardProps {
    post: Post;
    currentUser: User;
    onToggleReaction: (postId: string, reaction: string) => void;
    onVoteOnPoll: (postId: string, optionIndex: number) => void;
    onDeletePost?: (post: Post) => void;
    onViewPost?: (post: Post) => void;
}

const timeAgo = (timestamp: number): string => {
    const now = Date.now();
    const seconds = Math.floor((now - timestamp) / 1000);
    
    let interval = seconds / 31536000;
    if (interval > 1) return Math.floor(interval) + " éve";
    interval = seconds / 2592000;
    if (interval > 1) return Math.floor(interval) + " hónapja";
    interval = seconds / 86400;
    if (interval > 1) return Math.floor(interval) + " napja";
    interval = seconds / 3600;
    if (interval > 1) return Math.floor(interval) + " órája";
    interval = seconds / 60;
    if (interval > 1) return Math.floor(interval) + " perce";
    return "épp most";
};

const availableReactions = ['🔥', '😂', '🤯', '💯', '❤️', '😢'];

const urlRegex = /(https?:\/\/(?:www\.)?(?:youtu\.be\/[a-zA-Z0-9_-]{11}|youtube\.com\/watch\?v=[a-zA-Z0-9_-]{11}|tiktok\.com\/[@a-zA-Z0-9_.-]+\/video\/\d+)[^\s]*)/;
const gifUrlRegex = /(https?:\/\/\S+?\.gif)/;

const extractUrl = (text: string | null): string | null => {
    if (!text) return null;
    const match = text.match(urlRegex);
    return match ? match[0] : null;
};

const extractGifUrl = (text: string | null): string | null => {
    if (!text) return null;
    const match = text.match(gifUrlRegex);
    return match ? match[0] : null;
}

const PollComponent: React.FC<{ poll: NonNullable<Post['poll']>, postId: string, currentUser: User, onVote: (postId: string, optionIndex: number) => void }> = ({ poll, postId, currentUser, onVote }) => {
    const totalVotes = poll.options.reduce((sum, option) => sum + option.votes.length, 0);
    const userVoteIndex = poll.options.findIndex(option => option.votes.includes(currentUser.id));

    return (
        <div className="space-y-2 mt-4 text-[var(--text-primary)]">
            <h3 className="font-bold text-lg">{poll.question}</h3>
            {poll.options.map((option, index) => {
                const isUserChoice = userVoteIndex === index;
                const votes = option.votes.length;
                const percentage = totalVotes > 0 ? Math.round((votes / totalVotes) * 100) : 0;
                return (
                     <button key={index} onClick={() => onVote(postId, index)} disabled={userVoteIndex !== -1} className="w-full text-left relative p-3 rounded-lg border-2 border-slate-600 hover:border-orange-500 transition-colors disabled:cursor-not-allowed">
                        {userVoteIndex !== -1 && (
                             <div className="absolute inset-0 bg-orange-500/30 rounded-md" style={{ width: `${percentage}%` }}></div>
                        )}
                        <div className="relative flex justify-between font-semibold">
                            <span>{option.text}</span>
                            {userVoteIndex !== -1 && <span>{percentage}%</span>}
                        </div>
                        {isUserChoice && <span className="text-xs text-orange-300">Te szavazatod</span>}
                    </button>
                )
            })}
             {totalVotes > 0 && <p className="text-xs text-[var(--text-tertiary)] text-right">{totalVotes} szavazat</p>}
        </div>
    )
}

const MediaLoader: React.FC<{ post: Post }> = ({ post }) => {
    const [imageUrl, setImageUrl] = useState<string | null>(null);
    const [videoUrl, setVideoUrl] = useState<string | null>(null);
    const [isLoadingMedia, setIsLoadingMedia] = useState(false);

    useEffect(() => {
        let isMounted = true;
        const loadMedia = async () => {
            setIsLoadingMedia(true);
            let imgUrl = post.imageUrl || null;
            let vidUrl = post.videoUrl || null;

            if (post.imageUrl && post.imageUrl.startsWith('idb_key:')) {
                const data = await largeDataService.getItem<string>(post.imageUrl.substring(8));
                if (isMounted) imgUrl = data;
            }
            if (post.videoUrl && post.videoUrl.startsWith('idb_key:')) {
                const data = await largeDataService.getItem<string>(post.videoUrl.substring(8));
                if (isMounted) vidUrl = data;
            }
            
            if(isMounted) {
                setImageUrl(imgUrl);
                setVideoUrl(vidUrl);
                setIsLoadingMedia(false);
            }
        };

        if ((post.imageUrl && post.imageUrl.startsWith('idb_key:')) || (post.videoUrl && post.videoUrl.startsWith('idb_key:'))) {
            loadMedia();
        } else {
            setImageUrl(post.imageUrl || null);
            setVideoUrl(post.videoUrl || null);
        }
        
        return () => { isMounted = false; };
    }, [post.imageUrl, post.videoUrl]);
    
    if (isLoadingMedia) {
        return <div className="aspect-video w-full max-w-xl mx-auto rounded-lg bg-slate-700 animate-pulse"></div>;
    }

    return (
        <>
            {imageUrl && (
                <img src={imageUrl} alt="Bejegyzés Kép" className="max-w-full rounded-lg mx-auto" />
            )}
            {videoUrl && (
                <video
                    src={videoUrl}
                    controls
                    className="max-w-full rounded-lg mx-auto max-h-[60vh] mt-4"
                    playsInline
                >
                    A böngésződ nem támogatja a videólejátszást.
                </video>
            )}
        </>
    );
};


const PostCard: React.FC<PostCardProps> = ({ post, currentUser, onToggleReaction, onVoteOnPoll, onDeletePost, onViewPost }) => {
    const { author, content, gifUrl, poll, timestamp } = post;
    const authorAvatar = avatars.find(a => a.id === author.avatarId);
    
    const [showDeleteModal, setShowDeleteModal] = useState(false);
    const [isDeleting, setIsDeleting] = useState(false);

    const gifUrlFromContent = extractGifUrl(content);
    const hasGif = gifUrl || gifUrlFromContent;
    const linkUrl = !hasGif ? extractUrl(content) : null;

    const userReaction = availableReactions.find(r => post.reactions[r]?.includes(currentUser.id));
    const canDelete = currentUser.id === post.author.id || currentUser.status === 'pro_max';

    const handleDeleteClick = () => {
        setShowDeleteModal(true);
    };

    const handleConfirmDelete = () => {
        setShowDeleteModal(false);
        setIsDeleting(true);
        // Wait for animation to finish before calling the parent's delete function
        setTimeout(() => {
            if (onDeletePost) {
                onDeletePost(post);
            }
        }, 400); // Duration should match the fade-out animation
    };

    return (
        <>
        <div className={`bg-[var(--component-bg)] backdrop-blur-sm p-4 rounded-2xl shadow-lg w-full flex flex-col transition-all duration-400 ${isDeleting ? 'animate-fade-out-right' : 'animate-fade-in-up'}`}>
            <div className="flex items-start gap-3 mb-3">
                <div className="w-10 h-10 rounded-full overflow-hidden flex-shrink-0 bg-slate-700/50">
                    {author.uploadedImage ? (
                        <img src={author.uploadedImage} alt="Avatar" className="w-full h-full object-cover" />
                    ) : authorAvatar ? (
                        <authorAvatar.component />
                    ) : (
                        <div className="w-full h-full flex items-center justify-center text-xl font-bold text-[var(--text-primary)]">
                            {author.name.charAt(0).toUpperCase()}
                        </div>
                    )}
                </div>
                <div className="flex-1">
                    <p className="font-bold text-[var(--text-primary)] flex items-center">{author.name} <UserStatusBadge user={author} /></p>
                    <p className="text-xs text-[var(--text-tertiary)]">{timeAgo(timestamp)}</p>
                </div>

                {canDelete && (
                     <button onClick={handleDeleteClick} title="Bejegyzés törlése" className="p-2 rounded-full text-[var(--text-tertiary)] hover:bg-red-500/50 hover:text-[var(--text-primary)] transition-colors">
                        <TrashIcon className="w-5 h-5" />
                    </button>
                )}
            </div>
            
            <div 
                className={`space-y-4 flex-1 ${onViewPost ? 'cursor-pointer' : ''}`}
                onClick={() => onViewPost && onViewPost(post)}
            >
                {content && <p className="text-[var(--text-primary)] whitespace-pre-wrap break-words">{content.replace(gifUrlRegex, '').replace(urlRegex, '').trim()}</p>}
                
                {linkUrl && <div className="mt-4"><LinkPreview url={linkUrl} /></div>}
                
                {hasGif && (
                    <img src={hasGif} alt="Bejegyzés GIF" className="max-w-full rounded-lg mx-auto" />
                )}
                
                <MediaLoader post={post} />

                {poll && <PollComponent poll={poll} postId={post.id} currentUser={currentUser} onVote={onVoteOnPoll} />}
            </div>
            
            <div className="mt-4 pt-3 border-t border-[var(--border-color)]">
                <div className="flex justify-around items-center">
                    {availableReactions.map(reaction => {
                        const count = post.reactions[reaction]?.length || 0;
                        const isSelected = userReaction === reaction;

                        return (
                             <div key={reaction} className="group relative flex justify-center">
                                <button
                                    onClick={(e) => { e.stopPropagation(); onToggleReaction(post.id, reaction); }}
                                    className={`p-2 rounded-full transition-all duration-200 ${isSelected ? 'bg-orange-500/50' : 'bg-slate-700/50 hover:bg-slate-600/50'}`}
                                    aria-label={`Reagálás: ${reaction}`}
                                >
                                    <span className="text-xl block group-hover:scale-125 transition-transform duration-200">{reaction}</span>
                                </button>
                                <span className="absolute -top-12 left-1/2 -translate-x-1/2 z-20 origin-bottom scale-0 px-3 py-1.5 rounded-lg border border-[var(--border-color)] bg-[var(--component-bg)] text-sm font-bold shadow-md transition-all duration-300 ease-in-out group-hover:scale-100 whitespace-nowrap">
                                    {reaction} {count > 0 && count}
                                </span>
                            </div>
                        );
                    })}
                     <div className="group relative flex justify-center">
                        <button
                            onClick={() => onViewPost && onViewPost(post)}
                            className="p-2"
                            aria-label="Kommentek"
                        >
                             <svg
                                strokeLinejoin="round"
                                strokeLinecap="round"
                                stroke="currentColor"
                                strokeWidth="2"
                                viewBox="0 0 24 24"
                                height="32"
                                width="32"
                                xmlns="http://www.w3.org/2000/svg"
                                className="text-[var(--text-secondary)] group-hover:scale-125 group-hover:text-orange-500 transition-all duration-200"
                                fill="none"
                            >
                                <path fill="none" d="M0 0h24v24H0z" stroke="none"></path>
                                <path d="M8 9h8"></path>
                                <path d="M8 13h6"></path>
                                <path d="M18 4a3 3 0 0 1 3 3v8a3 3 0 0 1 -3 3h-5l-5 3v-3h-2a3 3 0 0 1 -3 -3v-8a3 3 0 0 1 3 -3h12z"></path>
                            </svg>
                        </button>
                        <span className="absolute -top-12 left-1/2 -translate-x-1/2 z-20 origin-bottom scale-0 px-3 py-1.5 rounded-lg border border-[var(--border-color)] bg-[var(--component-bg)] text-sm font-bold shadow-md transition-all duration-300 ease-in-out group-hover:scale-100 whitespace-nowrap">
                            Komment {post.comments?.length > 0 && post.comments.length}
                        </span>
                    </div>
                </div>
            </div>
        </div>
        <DeleteConfirmationModal
            isOpen={showDeleteModal}
            onClose={() => setShowDeleteModal(false)}
            onConfirm={handleConfirmDelete}
            message="Biztosan törölni szeretnéd ezt a bejegyzést? A művelet nem vonható vissza."
        />
        </>
    );
};

export default PostCard;