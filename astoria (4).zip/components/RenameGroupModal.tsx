import React, { useState, useEffect } from 'react';
import { useNotification } from '../contexts/NotificationContext';

interface RenameGroupModalProps {
    isOpen: boolean;
    onClose: () => void;
    onSave: (newName: string) => Promise<void>;
    currentName: string;
}

const RenameGroupModal: React.FC<RenameGroupModalProps> = ({ isOpen, onClose, onSave, currentName }) => {
    const [newName, setNewName] = useState(currentName);
    const [isLoading, setIsLoading] = useState(false);
    const { addNotification } = useNotification();

    useEffect(() => {
        if (isOpen) {
            setNewName(currentName);
        }
    }, [isOpen, currentName]);

    const handleSave = async () => {
        if (!newName.trim()) {
            addNotification("A csoportnév nem lehet üres.", "error");
            return;
        }
        if (newName.trim() === currentName) {
            onClose();
            return;
        }
        setIsLoading(true);
        await onSave(newName.trim());
        setIsLoading(false);
    };

    if (!isOpen) return null;

    return (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex justify-center items-center animate-fade-in" onClick={onClose}>
            <div className="bg-slate-800 w-full max-w-sm rounded-2xl shadow-2xl p-6 text-white" onClick={e => e.stopPropagation()}>
                <h3 className="text-2xl font-bold font-lilita mb-4 text-center">Csoport átnevezése</h3>
                <div className="space-y-4">
                    <div>
                        <label htmlFor="group-new-name" className="block text-white font-semibold mb-1">Új név</label>
                        <input
                            type="text"
                            id="group-new-name"
                            value={newName}
                            onChange={(e) => setNewName(e.target.value)}
                            className="w-full px-4 py-2 bg-slate-700 text-white border-2 border-transparent rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500"
                            required
                            disabled={isLoading}
                            autoFocus
                        />
                    </div>
                    <div className="flex gap-4">
                        <button onClick={onClose} disabled={isLoading} className="flex-1 py-2 bg-slate-600 rounded-full font-semibold">Mégse</button>
                        <button onClick={handleSave} disabled={isLoading} className="flex-1 py-2 bg-green-600 rounded-full font-bold">{isLoading ? 'Mentés...' : 'Mentés'}</button>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default RenameGroupModal;
