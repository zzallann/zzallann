import React, { useState, useRef } from 'react';
import ArrowLeftIcon from './icons/ArrowLeftIcon';
import ImageIcon from './icons/ImageIcon';
import SendIcon from './icons/SendIcon';
import XCircleIcon from './icons/XCircleIcon';
import { useNotification } from '../contexts/NotificationContext';
import { messageService } from '../services/messageService';
import { authService } from '../services/authService';

interface FeedbackPageProps {
  onBackToLogin: () => void;
}

const fileToBase64 = (file: File): Promise<string> => {
    return new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.readAsDataURL(file);
        reader.onload = () => resolve(reader.result as string);
        reader.onerror = error => reject(error);
    });
};

const FeedbackPage: React.FC<FeedbackPageProps> = ({ onBackToLogin }) => {
  const [subject, setSubject] = useState('');
  const [body, setBody] = useState('');
  const [imageFile, setImageFile] = useState<File | null>(null);
  const [imagePreview, setImagePreview] = useState<string | null>(null);
  const [isSending, setIsSending] = useState(false);

  const fileInputRef = useRef<HTMLInputElement>(null);
  const { addNotification } = useNotification();

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      if (file.size > 5 * 1024 * 1024) { // 5MB limit
        addNotification('A kép mérete nem haladhatja meg az 5 MB-ot.', 'error');
        return;
      }
      setImageFile(file);
      const reader = new FileReader();
      reader.onloadend = () => {
        setImagePreview(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const clearImage = () => {
    setImageFile(null);
    setImagePreview(null);
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!subject.trim() && !body.trim()) {
      addNotification('Kérlek írj tárgyat vagy üzenetet a visszajelzéshez.', 'error');
      return;
    }

    setIsSending(true);

    try {
        const recipient = authService.getAllUsers().find(u => u.identifier === '05');
        if (!recipient) {
            throw new Error('A visszajelzés címzettje (05) nem található.');
        }

        const senderId = 'system_police_bot';
        const conversationId = await messageService.findOrCreateConversation(senderId, recipient.id);

        const messageContent = `Tárgy: ${subject}\n\nÜzenet:\n${body}`;
        const imageUrl = imageFile ? await fileToBase64(imageFile) : null;

        await messageService.sendMessage(
            senderId,
            conversationId,
            messageContent,
            imageUrl,
            null, // gifUrl
            true // isFeedback
        );

        addNotification('Köszönjük a visszajelzést! Elküldtük a fejlesztőnek.', 'success');
        onBackToLogin();

    } catch (err: any) {
        addNotification(err.message || 'Hiba a visszajelzés küldésekor.', 'error');
    } finally {
        setIsSending(false);
    }
  };

  return (
    <div className="w-full max-w-sm bg-[var(--component-bg)] backdrop-blur-sm p-8 rounded-2xl shadow-lg animate-fade-in relative text-[var(--text-primary)]">
      <button onClick={onBackToLogin} className="absolute top-4 left-4 p-2 rounded-full hover:bg-[var(--component-bg-hover)] transition-colors">
        <ArrowLeftIcon className="w-6 h-6 text-[var(--text-primary)]" />
      </button>
      <h2 className="text-3xl font-bold text-center mb-6 font-lilita">Visszajelzés</h2>
      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <label htmlFor="feedback-subject" className="block text-[var(--text-primary)] font-semibold mb-1">Tárgy</label>
          <input
            type="text"
            id="feedback-subject"
            value={subject}
            onChange={(e) => setSubject(e.target.value)}
            className="w-full px-4 py-2 bg-[var(--input-bg)] text-[var(--text-primary)] border-2 border-transparent rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500"
            disabled={isSending}
          />
        </div>
        <div>
          <label htmlFor="feedback-body" className="block text-[var(--text-primary)] font-semibold mb-1">Szöveg</label>
          <textarea
            id="feedback-body"
            value={body}
            onChange={(e) => setBody(e.target.value)}
            rows={5}
            className="w-full px-4 py-2 bg-[var(--input-bg)] text-[var(--text-primary)] border-2 border-transparent rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500 resize-none"
            disabled={isSending}
          />
        </div>
        
        <div>
            <input type="file" accept="image/*" ref={fileInputRef} onChange={handleFileChange} className="hidden" />
            {!imagePreview ? (
                <button type="button" onClick={() => fileInputRef.current?.click()} className="w-full flex items-center justify-center gap-2 px-4 py-3 bg-slate-600/50 text-white/80 font-semibold rounded-lg shadow-lg transform hover:scale-105 transition-transform">
                    <ImageIcon className="w-6 h-6" />
                    <span>Kép csatolása (opcionális)</span>
                </button>
            ) : (
                <div className="relative w-full h-32 rounded-lg overflow-hidden">
                    <img src={imagePreview} alt="Előnézet" className="w-full h-full object-cover" />
                    <button type="button" onClick={clearImage} className="absolute top-1 right-1 p-0.5 bg-black/60 rounded-full text-white">
                        <XCircleIcon className="w-6 h-6"/>
                    </button>
                </div>
            )}
        </div>

        <button
          type="submit"
          disabled={isSending}
          className="w-full mt-4 flex items-center justify-center gap-2 px-4 py-3 bg-orange-600 text-white font-bold rounded-full text-lg shadow-lg transform hover:scale-105 transition-transform disabled:bg-orange-400 disabled:scale-100"
        >
          <SendIcon className="w-5 h-5" />
          <span>{isSending ? 'Küldés...' : 'Küldés'}</span>
        </button>
      </form>
    </div>
  );
};

export default FeedbackPage;