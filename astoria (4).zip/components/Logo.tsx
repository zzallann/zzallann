

import React from 'react';

const Logo: React.FC = () => {
  return (
    <div className="flex flex-col items-center justify-center">
      <div className="w-64 h-16 bg-[#F3782E] rounded-t-full transform scale-x-110"></div>
      <h1 className="font-lilita text-7xl text-[var(--text-primary)] tracking-wider my-2 text-shadow">
        Astoria
      </h1>
      <div className="w-64 h-16 bg-[#F3782E] rounded-b-full transform scale-x-110"></div>
    </div>
  );
};

export default Logo;