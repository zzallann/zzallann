import React, { useState, useEffect, useMemo } from 'react';
import type { User } from '../types';
import { authService } from '../services/authService';
import SearchIcon from './icons/SearchIcon';
import UserAvatarWithStatus from './UserAvatarWithStatus';
import XCircleIcon from './icons/XCircleIcon';

interface AddUserToGroupModalProps {
    isOpen: boolean;
    onClose: () => void;
    onAddUsers: (userIds: string[]) => Promise<void>;
    existingParticipantIds: string[];
}

const AddUserToGroupModal: React.FC<AddUserToGroupModalProps> = ({ isOpen, onClose, onAddUsers, existingParticipantIds }) => {
    const [allUsers, setAllUsers] = useState<User[]>([]);
    const [selectedUserIds, setSelectedUserIds] = useState<string[]>([]);
    const [searchTerm, setSearchTerm] = useState('');
    const [isLoading, setIsLoading] = useState(false);

    useEffect(() => {
        if (isOpen) {
            const users = authService.getAllUsers()
                .filter(u => u.approved && !existingParticipantIds.includes(u.id))
                .sort((a, b) => a.name.localeCompare(b.name));
            setAllUsers(users);
        } else {
            // Reset state on close
            setSelectedUserIds([]);
            setSearchTerm('');
        }
    }, [isOpen, existingParticipantIds]);

    const filteredUsers = useMemo(() => {
        if (!searchTerm.trim()) return allUsers;
        const lowerCaseSearch = searchTerm.toLowerCase();
        return allUsers.filter(u => u.name.toLowerCase().includes(lowerCaseSearch));
    }, [searchTerm, allUsers]);

    const handleUserToggle = (userId: string) => {
        setSelectedUserIds(prev =>
            prev.includes(userId)
                ? prev.filter(id => id !== userId)
                : [...prev, userId]
        );
    };

    const handleConfirmAdd = async () => {
        if (selectedUserIds.length === 0) return;
        setIsLoading(true);
        await onAddUsers(selectedUserIds);
        setIsLoading(false);
    };
    
    if (!isOpen) return null;

    return (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex justify-center items-center animate-fade-in" onClick={onClose}>
            <div className="bg-slate-800 w-full max-w-md max-h-[80vh] rounded-2xl shadow-2xl flex flex-col" onClick={e => e.stopPropagation()}>
                <div className="flex justify-between items-center p-4 border-b border-slate-700">
                    <h3 className="text-xl font-bold text-white">Tagok hozzáadása</h3>
                    <button onClick={onClose} className="p-1 rounded-full hover:bg-slate-700"><XCircleIcon className="w-6 h-6 text-slate-400"/></button>
                </div>
                <div className="p-4">
                    <div className="relative">
                        <span className="absolute left-3 top-1/2 -translate-y-1/2"><SearchIcon className="w-5 h-5 text-slate-400"/></span>
                        <input type="text" value={searchTerm} onChange={(e) => setSearchTerm(e.target.value)} placeholder="Keresés..." className="w-full bg-slate-700 text-white pl-10 pr-4 py-2 rounded-full text-sm" />
                    </div>
                </div>
                <div className="flex-1 p-4 pt-0 overflow-y-auto space-y-2">
                    {filteredUsers.map(user => (
                        <label key={user.id} className="flex items-center gap-3 p-2 rounded-md hover:bg-slate-700 cursor-pointer">
                            <input type="checkbox" checked={selectedUserIds.includes(user.id)} onChange={() => handleUserToggle(user.id)} className="h-5 w-5 rounded bg-slate-800 border-slate-500 text-orange-500 focus:ring-orange-500 flex-shrink-0" />
                            <UserAvatarWithStatus user={user} size="small" />
                            <span className="font-semibold text-white">{user.name}</span>
                        </label>
                    ))}
                    {filteredUsers.length === 0 && <p className="text-center text-slate-400 p-4">Nincs több hozzáadható felhasználó.</p>}
                </div>
                 <div className="p-4 border-t border-slate-700">
                    <button onClick={handleConfirmAdd} disabled={isLoading || selectedUserIds.length === 0} className="w-full py-3 bg-green-600 text-white font-bold rounded-full disabled:bg-slate-500">
                        {isLoading ? 'Hozzáadás...' : `Hozzáadás (${selectedUserIds.length})`}
                    </button>
                </div>
            </div>
        </div>
    );
};

export default AddUserToGroupModal;