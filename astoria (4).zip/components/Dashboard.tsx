import React, { useState, useEffect, useCallback, useRef } from 'react';
import type { Post, User, Poll, Conversation, Comment } from '../types';
import { driveService } from '../services/driveService';
import { authService } from '../services/authService';
import { messageService } from '../services/messageService';
import { deadlineService } from '../services/deadlineService';
import { workTimeService } from '../services/workTimeService';
import { taskService } from '../services/taskService';
import { headlineService } from '../services/headlineService';
import { newspaperLinkService } from '../services/newspaperLinkService';
import Sidebar from './Sidebar';
import Feed from './Feed';
import PlaceholderPage from './PlaceholderPage';
import HamburgerIcon from './icons/HamburgerIcon';
import ProfilePage from './ProfilePage';
import MealLoggingPage from './MealLoggingPage';
import WorkTimeRequestPage from './WorkTimeRequestPage';
import SettingsPage from './SettingsPage';
import KollegakPage from './KollegakPage';
import HetiBeosztasPage from './HetiBeosztasPage';
import MessagesPage from './MessagesPage';
import OktatasomPage from './OktatasomPage';
import TaskArchivePage from './TaskArchivePage';
import WasteLoggingPage from './WasteLoggingPage';
import PushNotificationPage from './PushNotificationPage';
import AwardsPage from './AwardsPage';
import { useNotification } from '../contexts/NotificationContext';
import PostDetailModal from './PostDetailModal';
import KpiBar from './KpiBar';
import HelyiLapPage from './HelyiLapPage';
import EditIcon from './icons/EditIcon';
import CheckIcon from './icons/CheckIcon';
import XCircleIcon from './icons/XCircleIcon';
import FavoriteEmployeePage from './FavoriteEmployeePage';


interface DashboardProps {
    user: User;
    onLogout: () => void;
    onUserUpdate: (user: User) => void;
}

const getDativeSuffix = (name: string): string => {
    const highVowels = ['e', 'é', 'i', 'í', 'ö', 'ő', 'ü', 'ű'];
    const nameLower = name.toLowerCase();
    for (let i = nameLower.length - 1; i >= 0; i--) {
        if (highVowels.includes(nameLower[i])) {
            return 'nek';
        }
    }
    return 'nak';
};

const Dashboard: React.FC<DashboardProps> = ({ user, onLogout, onUserUpdate }) => {
    const [posts, setPosts] = useState<Post[]>([]);
    const [conversations, setConversations] = useState<Conversation[]>([]);
    const [totalUnreadCount, setTotalUnreadCount] = useState(0);
    const [unreadTaskCount, setUnreadTaskCount] = useState(0);
    const [isLoading, setIsLoading] = useState(true);
    const [error, setError] = useState('');
    const [activeView, setActiveView] = useState('hirfolyam');
    const [isSidebarOpen, setIsSidebarOpen] = useState(false);
    const [viewingPost, setViewingPost] = useState<Post | null>(null);
    const [isChatViewActive, setChatViewActive] = useState(false);
    const { addNotification } = useNotification();
    
    const [headline, setHeadline] = useState('');
    const [isEditingHeadline, setIsEditingHeadline] = useState(false);
    const [editableHeadline, setEditableHeadline] = useState('');

    const [newspaperLinkText, setNewspaperLinkText] = useState('');
    const [isEditingNewspaperLink, setIsEditingNewspaperLink] = useState(false);
    const [editableNewspaperLinkText, setEditableNewspaperLinkText] = useState('');

    const prevUnreadCount = useRef(0);
    const prevTaskCount = useRef(0);

    const refreshConversations = useCallback(async () => {
        if (!user) return;
        try {
            const convos = await messageService.getConversations(user.id);
            setConversations(convos);
        } catch (err) {
            console.error("Failed to refresh conversations", err);
        }
    }, [user]);

    const refreshTaskCount = useCallback(async () => {
        if (!user || (user.status !== 'pro' && user.status !== 'pro_max')) return;
        try {
            const count = await taskService.getUnreadTaskUpdateCount(user.id);
            setUnreadTaskCount(count);
        } catch (err) {
            console.error("Failed to refresh task count", err);
        }
    }, [user]);

     const checkAndSendReminders = useCallback(async () => {
        const deadline = await deadlineService.getDeadline();
        if (!deadline || deadline < Date.now()) return;

        const allUsers = authService.getAllUsers();
        const usersToCheck = allUsers.filter(u => u.status === 'pro' || u.status === 'normal');
        if (usersToCheck.length === 0) return;

        const requests = await workTimeService.getNextWeeksRequests();
        const usersWhoSubmitted = new Set(requests.map(r => r.userId));

        const POLICE_BOT_ID = 'system_police_bot';

        for (const user of usersToCheck) {
            if (usersWhoSubmitted.has(user.id)) continue;

            const now = Date.now();
            const hoursLeft = (deadline - now) / (1000 * 60 * 60);

            const reminder5hKey = `reminder_sent_${user.id}_${deadline}_5h`;
            const reminder1hKey = `reminder_sent_${user.id}_${deadline}_1h`;

            if (hoursLeft <= 5 && hoursLeft > 1 && !localStorage.getItem(reminder5hKey)) {
                const message = `Figyelem! A heti beosztásod leadási határideje kevesebb, mint 5 óra múlva lejár. Kérlek, ne felejtsd el kitölteni!`;
                const convoId = await messageService.findOrCreateConversation(POLICE_BOT_ID, user.id);
                await messageService.sendMessage(POLICE_BOT_ID, convoId, message, null, null, false);
                localStorage.setItem(reminder5hKey, 'true');
            }

            if (hoursLeft <= 1 && !localStorage.getItem(reminder1hKey)) {
                const message = `Sürgős! Már csak 1 órád maradt a heti beosztásod leadására. Kérlek pótold a mulasztást!`;
                const convoId = await messageService.findOrCreateConversation(POLICE_BOT_ID, user.id);
                await messageService.sendMessage(POLICE_BOT_ID, convoId, message, null, null, false);
                localStorage.setItem(reminder1hKey, 'true');
            }
        }
    }, []);

    useEffect(() => {
        const fetchInitialData = async () => {
            try {
                const [fetchedPosts, convos, headlineData, newspaperLinkData] = await Promise.all([
                    driveService.getPosts(),
                    messageService.getConversations(user.id),
                    headlineService.getHeadline(),
                    newspaperLinkService.getNewspaperLink()
                ]);
                setPosts(fetchedPosts);
                setConversations(convos);
                setHeadline(headlineData.text);
                setEditableHeadline(headlineData.text);
                setNewspaperLinkText(newspaperLinkData.text);
                setEditableNewspaperLinkText(newspaperLinkData.text);


                const initialTasks = await taskService.getTasksForUser(user.id);
                prevTaskCount.current = initialTasks.filter(t => t.status === 'pending').length;

            } catch (err: any) {
                setError('Hiba a bejegyzések betöltése közben.');
            } finally {
                setIsLoading(false);
            }
        };

        fetchInitialData();
        refreshTaskCount();
        checkAndSendReminders();

        if ('Notification' in window && Notification.permission !== 'granted' && Notification.permission !== 'denied') {
            Notification.requestPermission();
        }
    }, [user.id, refreshTaskCount, checkAndSendReminders]);
    
    useEffect(() => {
        const total = conversations.reduce((sum, convo) => sum + convo.unreadCount, 0);
        setTotalUnreadCount(total);
        prevUnreadCount.current = total;
    }, [conversations]);

    useEffect(() => {
        // Poll for notifications when tab is not visible
        const interval = setInterval(async () => {
            if (document.hidden && 'Notification' in window && Notification.permission === 'granted') {
                // Check messages
                const convos = await messageService.getConversations(user.id);
                const newUnreadCount = convos.reduce((sum, c) => sum + c.unreadCount, 0);

                if (newUnreadCount > prevUnreadCount.current) {
                    new Notification('Új üzeneted érkezett!', {
                        body: 'Nyisd meg az Astoria appot a részletekért.',
                        icon: '/icon.svg',
                        tag: 'astoria-message'
                    });
                     // Update state to refresh UI if needed when tab is re-focused
                    setConversations(convos);
                }
                prevUnreadCount.current = newUnreadCount;
                
                // Check tasks
                const myTasks = await taskService.getTasksForUser(user.id);
                const newPendingTaskCount = myTasks.filter(t => t.status === 'pending').length;
                if (newPendingTaskCount > prevTaskCount.current) {
                     new Notification('Új feladatot kaptál!', {
                        body: 'Egy új oktatási feladat vár rád.',
                        icon: '/icon.svg',
                        tag: 'astoria-task'
                    });
                }
                prevTaskCount.current = newPendingTaskCount;
            }
        }, 20000); // Poll every 20 seconds

        return () => clearInterval(interval);
    }, [user.id]);


    const handleCreatePost = async (
        content: string | null,
        gifUrl: string | null,
        imageFile: File | null,
        videoFile: File | null,
        poll: Poll | null
    ) => {
        try {
            const newPost = await driveService.createPost(user, content, gifUrl, imageFile, videoFile, poll);
            setPosts(prevPosts => [newPost, ...prevPosts]);
            
            const updatedUser = { 
                ...user, 
                points: user.points + 20,
                pointsHistory: [
                    { reason: 'Új bejegyzés', points: 20, date: Date.now() },
                    ...(user.pointsHistory || [])
                ]
            };
            authService.updateUser(updatedUser);
            onUserUpdate(updatedUser);
            addNotification("Bejegyzésért 20 koronát kaptál!", 'success');

        } catch (err: any) {
            console.error("Failed to create post:", err);
            addNotification(err.message || "Hiba a bejegyzés létrehozásakor.", 'error');
        }
    };
    
    const handleToggleReaction = async (postId: string, reaction: string) => {
        try {
            const updatedPost = await driveService.toggleReaction(postId, reaction, user.id);
            setPosts(posts.map(p => p.id === postId ? updatedPost : p));

            const reactedPosts = user.reactedPostsForPoints || [];
            if (!reactedPosts.includes(postId)) {
                const updatedUser = { 
                    ...user, 
                    points: user.points + 5,
                    reactedPostsForPoints: [...reactedPosts, postId],
                    pointsHistory: [
                        { reason: 'Reakció egy bejegyzésre', points: 5, date: Date.now() },
                        ...(user.pointsHistory || [])
                    ]
                };
                authService.updateUser(updatedUser);
                onUserUpdate(updatedUser);
                addNotification("Reakcióért 5 koronát kaptál!", 'success');
            }

        } catch (err) {
            console.error("Failed to toggle reaction:", err);
        }
    };
    
    const handleVoteOnPoll = async (postId: string, optionIndex: number) => {
        try {
            const updatedPost = await driveService.voteOnPoll(postId, optionIndex, user.id);
            setPosts(posts.map(p => p.id === postId ? updatedPost : p));
        } catch (err) {
            console.error("Failed to vote on poll:", err);
        }
    };

    const handleDeletePost = async (post: Post) => {
        try {
            await driveService.deletePost(post, user);
            const updatedPosts = await driveService.getPosts();
            setPosts(updatedPosts);
            addNotification('Bejegyzés sikeresen törölve.', 'success');
            if (viewingPost?.id === post.id) {
                setViewingPost(null);
            }
            refreshConversations();
        } catch (err) {
            console.error("Failed to delete post:", err);
            addNotification('Hiba a törlés során.', 'error');
        }
    };

    const handleAddComment = async (postId: string, content: string | null, imageFile: File | null, gifUrl: string | null) => {
        try {
            const updatedPost = await driveService.addComment(postId, user, content, imageFile, gifUrl);
            const updateState = (p: Post) => p.id === postId ? updatedPost : p;
            setPosts(posts.map(updateState));
            setViewingPost(updatedPost);

            const commentedPosts = user.commentedPostsForPoints || [];
            if (!commentedPosts.includes(postId)) {
                const updatedUser = {
                    ...user,
                    points: user.points + 10,
                    commentedPostsForPoints: [...commentedPosts, postId],
                    pointsHistory: [
                        { reason: 'Első komment egy poszthoz', points: 10, date: Date.now() },
                        ...(user.pointsHistory || [])
                    ]
                };
                authService.updateUser(updatedUser);
                onUserUpdate(updatedUser);
                addNotification("Első kommentért 10 koronát kaptál!", "success");
            }

        } catch (err) {
            console.error("Failed to add comment:", err);
            addNotification("Hiba a komment írása közben.", "error");
        }
    };

    const handleToggleCommentReaction = async (postId: string, commentId: string, reaction: string) => {
        try {
            const updatedPost = await driveService.toggleCommentReaction(postId, commentId, reaction, user.id);
            const updateState = (p: Post) => p.id === postId ? updatedPost : p;
            setPosts(posts.map(updateState));
            setViewingPost(updatedPost);

            const reactedComments = user.reactedCommentsForPoints || [];
            if (!reactedComments.includes(commentId)) {
                const updatedUser = {
                    ...user,
                    points: user.points + 2,
                    reactedCommentsForPoints: [...reactedComments, commentId],
                    pointsHistory: [
                        { reason: 'Reakció egy kommentre', points: 2, date: Date.now() },
                        ...(user.pointsHistory || [])
                    ]
                };
                authService.updateUser(updatedUser);
                onUserUpdate(updatedUser);
                addNotification("Kommentreakcióért 2 koronát kaptál!", "success");
            }
        } catch (err) {
            console.error("Failed to toggle comment reaction:", err);
        }
    };

    const handleDeleteComment = async (postId: string, commentId: string) => {
        try {
            const updatedPost = await driveService.deleteComment(postId, commentId, user);
            const updateState = (p: Post) => p.id === postId ? updatedPost : p;
            setPosts(posts.map(updateState));
            if (viewingPost?.id === postId) {
                setViewingPost(updatedPost);
            }
            addNotification('Komment sikeresen törölve.', 'success');
            refreshConversations();
        } catch (err: any) {
            console.error("Failed to delete comment:", err);
            addNotification(err.message || 'Hiba a komment törlése során.', 'error');
        }
    };


    const handleNavigate = (view: string, context?: any) => {
        if (context) {
             (window as any).navigationContext = context;
        }
        setActiveView(view);
        setIsSidebarOpen(false);
    };

    const handleSaveHeadline = async () => {
        if (editableHeadline.trim() === '') {
            addNotification('A szöveg nem lehet üres!', 'error');
            return;
        }
        try {
            const updated = await headlineService.updateHeadline(editableHeadline);
            setHeadline(updated.text);
            setIsEditingHeadline(false);
            addNotification('Szöveg frissítve!', 'success');
        } catch {
            addNotification('Hiba a mentés során!', 'error');
        }
    };

    const handleCancelEditHeadline = () => {
        setEditableHeadline(headline);
        setIsEditingHeadline(false);
    };

    const handleSaveNewspaperLink = async () => {
        if (editableNewspaperLinkText.trim() === '') {
            addNotification('A szöveg nem lehet üres!', 'error');
            return;
        }
        try {
            const updated = await newspaperLinkService.updateNewspaperLink(editableNewspaperLinkText);
            setNewspaperLinkText(updated.text);
            setIsEditingNewspaperLink(false);
            addNotification('Bulvárhír szövege frissítve!', 'success');
        } catch {
            addNotification('Hiba a mentés során!', 'error');
        }
    };

    const handleCancelEditNewspaperLink = () => {
        setEditableNewspaperLinkText(newspaperLinkText);
        setIsEditingNewspaperLink(false);
    };

    const isFullWidthPage = activeView === 'uzenetek';
    const isJournalist = user.status === 'pro' && user.identifier === '04';

    const renderContent = () => {
        switch(activeView) {
            case 'hirfolyam':
                return <Feed user={user} posts={posts} isLoading={isLoading} error={error} onCreatePost={handleCreatePost} onToggleReaction={handleToggleReaction} onVoteOnPoll={handleVoteOnPoll} onDeletePost={handleDeletePost} onViewPost={setViewingPost} />;
            case 'profil':
                return <ProfilePage user={user} posts={posts} currentUser={user} onToggleReaction={handleToggleReaction} onVoteOnPoll={handleVoteOnPoll} onDeletePost={handleDeletePost} onNavigate={handleNavigate} onLogout={onLogout} onUserUpdate={onUserUpdate} />;
            case 'selejt':
                return <WasteLoggingPage user={user} />;
            case 'push':
                return <PushNotificationPage user={user} onNavigate={handleNavigate} />;
            case 'etkezes':
                return <MealLoggingPage user={user} onUserUpdate={onUserUpdate} />;
            case 'uzenetek':
                return <MessagesPage currentUser={user} onUserUpdate={onUserUpdate} onConversationsChange={refreshConversations} setChatViewActive={setChatViewActive}/>;
            case 'munkaido':
                return <WorkTimeRequestPage user={user} />;
            case 'beosztas':
                return <HetiBeosztasPage user={user} />;
             case 'oktatasom':
                return <OktatasomPage user={user} onNavigate={handleNavigate} onRefreshTaskCount={refreshTaskCount} />;
             case 'archivum':
                return <TaskArchivePage currentUser={user} onNavigate={handleNavigate} />;
             case 'kollegak':
                return <KollegakPage currentUser={user} onUserUpdate={onUserUpdate} onStartChat={(userId) => handleNavigate('uzenetek', { startChatWith: userId })}/>;
             case 'havi_kedvenc':
                return <FavoriteEmployeePage currentUser={user} />;
             case 'dijazottak':
                return <AwardsPage currentUser={user} />;
             case 'helyilap':
                return <HelyiLapPage currentUser={user} onUserUpdate={onUserUpdate} />;
             case 'beallitasok':
                return <SettingsPage user={user} onUserUpdate={onUserUpdate} />;
            default:
                return <PlaceholderPage title="Hamarosan" />;
        }
    };

    return (
        <div className="h-screen flex flex-row transition-colors duration-300">
            <Sidebar 
                user={user} 
                isOpen={isSidebarOpen} 
                onClose={() => setIsSidebarOpen(false)}
                onNavigate={handleNavigate}
                onLogout={onLogout}
                totalUnreadCount={totalUnreadCount}
                unreadTaskCount={unreadTaskCount}
            />
            <div className="flex-1 flex flex-col min-h-0 bg-transparent overflow-x-hidden">
                <header className={`flex-shrink-0 z-10 flex items-center justify-between gap-2 p-4 ${isChatViewActive ? 'hidden' : ''}`}>
                    <button
                        className={`md:hidden p-2 rounded-full text-[var(--text-primary)] bg-[var(--component-bg)] backdrop-blur-md ${isSidebarOpen ? 'hidden' : ''}`}
                        onClick={() => setIsSidebarOpen(true)}
                    >
                        <HamburgerIcon className="w-6 h-6" />
                    </button>
                    
                    <div className="flex-1"></div>

                    {activeView === 'hirfolyam' && (
                       <div className="flex items-center gap-2 px-4 py-2 bg-slate-700/50 backdrop-blur-sm rounded-full text-sm shadow-lg flex-shrink min-w-0">
                            {isEditingNewspaperLink && isJournalist ? (
                                <>
                                    <input
                                        type="text"
                                        value={editableNewspaperLinkText}
                                        onChange={(e) => setEditableNewspaperLinkText(e.target.value)}
                                        className="text-sm font-semibold text-white bg-slate-900/50 rounded-full px-3 py-1 focus:ring-orange-500 focus:outline-none"
                                        autoFocus
                                    />
                                    <button onClick={handleSaveNewspaperLink} className="p-1 bg-green-600 rounded-full flex-shrink-0"><CheckIcon className="w-4 h-4 text-white"/></button>
                                    <button onClick={handleCancelEditNewspaperLink} className="p-1 bg-red-600 rounded-full flex-shrink-0"><XCircleIcon className="w-4 h-4 text-white"/></button>
                                </>
                            ) : (
                                <>
                                    <button
                                        onClick={() => handleNavigate('helyilap')}
                                        className="text-white font-bold transition-transform hover:scale-105 truncate"
                                    >
                                        {newspaperLinkText}
                                    </button>
                                    {isJournalist && (
                                        <button onClick={() => setIsEditingNewspaperLink(true)} className="text-white/70 hover:text-white ml-2 p-1">
                                            <EditIcon className="w-4 h-4"/>
                                        </button>
                                    )}
                                </>
                            )}
                        </div>
                    )}
                </header>

                <main className={`flex-1 min-h-0 ${isFullWidthPage ? 'flex flex-col' : 'overflow-y-auto p-4 pt-0'}`}>
                    {isFullWidthPage ? (
                        renderContent()
                    ) : (
                        <div className="w-full max-w-2xl mx-auto flex flex-col items-center gap-6 min-w-0">
                            {activeView === 'hirfolyam' && (
                                <>
                                    <KpiBar currentUser={user} />
                                    <div className="w-full bg-slate-800/60 backdrop-blur-sm p-3 rounded-2xl shadow-lg text-white flex items-center gap-3 border border-red-500/50">
                                        <span className="bg-red-600 text-white font-bold uppercase text-xs px-2 py-1 rounded flex-shrink-0 animate-pulse">Breaking</span>
                                        <div className="flex-1 flex items-center gap-2 min-w-0">
                                            {isEditingHeadline && user.status === 'pro_max' ? (
                                                <div className="flex items-center gap-1 w-full">
                                                    <input
                                                        type="text"
                                                        value={editableHeadline}
                                                        onChange={(e) => setEditableHeadline(e.target.value)}
                                                        className="w-full text-sm font-semibold text-white bg-slate-900/50 rounded-full px-3 py-1 focus:ring-orange-500 focus:outline-none"
                                                    />
                                                    <button onClick={handleSaveHeadline} className="p-1 bg-green-600 rounded-full flex-shrink-0"><CheckIcon className="w-4 h-4 text-white"/></button>
                                                    <button onClick={handleCancelEditHeadline} className="p-1 bg-red-600 rounded-full flex-shrink-0"><XCircleIcon className="w-4 h-4 text-white"/></button>
                                                </div>
                                            ) : (
                                                <>
                                                    <div className="flex-1 overflow-hidden whitespace-nowrap relative group">
                                                        <div className="marquee-content group-hover:pause-animation">
                                                            <span className="font-semibold text-sm px-4">{headline}</span>
                                                            <span className="font-semibold text-sm px-4" aria-hidden="true">{headline}</span>
                                                        </div>
                                                    </div>
                                                    {user.status === 'pro_max' && (
                                                        <button onClick={() => setIsEditingHeadline(true)} className="text-white/70 hover:text-white ml-auto flex-shrink-0 p-1">
                                                            <EditIcon className="w-4 h-4"/>
                                                        </button>
                                                    )}
                                                </>
                                            )}
                                        </div>
                                    </div>
                                </>
                            )}
                            {renderContent()}
                        </div>
                    )}
                </main>
            </div>
            {viewingPost && (
                <PostDetailModal
                    post={viewingPost}
                    currentUser={user}
                    onClose={() => setViewingPost(null)}
                    onAddComment={handleAddComment}
                    onToggleReaction={handleToggleReaction}
                    onToggleCommentReaction={handleToggleCommentReaction}
                    onVoteOnPoll={handleVoteOnPoll}
                    onDeletePost={handleDeletePost}
                    onDeleteComment={handleDeleteComment}
                />
            )}
        </div>
    );
};

export default Dashboard;
