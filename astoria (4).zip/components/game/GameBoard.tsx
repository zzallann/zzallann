import React from 'react';
import type { GameState } from '../../types';

interface GameBoardProps {
  gameState: GameState | null;
  onPieceClick: (pieceId: number) => void;
  currentUserId: string;
}

const colors = {
  red: 'bg-red-500',
  blue: 'bg-blue-500',
  green: 'bg-green-500',
  yellow: 'bg-yellow-400',
};

const GameBoard: React.FC<GameBoardProps> = ({ gameState, onPieceClick, currentUserId }) => {
    if (!gameState) {
        return <div className="text-white">Játék betöltése...</div>;
    }
    
    const currentPlayer = gameState.players[gameState.currentPlayerIndex];
    const isMyTurn = currentPlayer.user.id === currentUserId;

    return (
        <div className="w-[320px] h-[320px] sm:w-[480px] sm:h-[480px] bg-slate-700 rounded-lg relative grid grid-cols-11 grid-rows-11 shadow-2xl">
            {/* Home bases */}
            <div className="absolute top-0 left-0 w-[40%] h-[40%] bg-red-800/50 flex items-center justify-center rounded-br-lg">
                <div className="w-2/3 h-2/3 bg-red-800 rounded-lg grid grid-cols-2 gap-2 p-2">
                    {gameState.players[0]?.pieces.filter(p => p.state === 'home').map(p => <div key={p.id} className="bg-red-500 rounded-full"></div>)}
                </div>
            </div>
            <div className="absolute top-0 right-0 w-[40%] h-[40%] bg-blue-800/50 flex items-center justify-center rounded-bl-lg">
                 <div className="w-2/3 h-2/3 bg-blue-800 rounded-lg grid grid-cols-2 gap-2 p-2">
                    {gameState.players[1]?.pieces.filter(p => p.state === 'home').map(p => <div key={p.id} className="bg-blue-500 rounded-full"></div>)}
                </div>
            </div>
            <div className="absolute bottom-0 left-0 w-[40%] h-[40%] bg-green-800/50 flex items-center justify-center rounded-tr-lg">
                 <div className="w-2/3 h-2/3 bg-green-800 rounded-lg grid grid-cols-2 gap-2 p-2">
                    {gameState.players[2]?.pieces.filter(p => p.state === 'home').map(p => <div key={p.id} className="bg-green-500 rounded-full"></div>)}
                </div>
            </div>
            <div className="absolute bottom-0 right-0 w-[40%] h-[40%] bg-yellow-800/50 flex items-center justify-center rounded-tl-lg">
                 <div className="w-2/3 h-2/3 bg-yellow-800 rounded-lg grid grid-cols-2 gap-2 p-2">
                    {gameState.players[3]?.pieces.filter(p => p.state === 'home').map(p => <div key={p.id} className="bg-yellow-400 rounded-full"></div>)}
                </div>
            </div>

            {/* Center Area */}
            <div className="absolute top-[40%] left-[40%] w-[20%] h-[20%] bg-gray-900 flex items-center justify-center">
                 <div className="text-white text-center">
                    <p className="text-xs">Aktuális Dobás</p>
                    <p className="text-4xl font-bold">{gameState.diceValue || '-'}</p>
                </div>
            </div>

            {/* This is a placeholder for actual piece rendering on the board path */}
            {/* A full implementation would map all 52 path positions to coordinates */}
            <p className="absolute bottom-2 left-2 text-white/50 text-xs">A bábuk megjelenítése egyszerűsítve.</p>
            {gameState.players.map(player => 
                player.pieces.filter(p => p.state === 'active').map(piece => {
                    const canMove = isMyTurn && gameState.diceValue !== null;
                    return (
                        <button 
                            key={`${player.color}-${piece.id}`}
                            onClick={() => canMove && onPieceClick(piece.id)}
                            className={`
                                w-6 h-6 rounded-full absolute transform -translate-x-1/2 -translate-y-1/2 
                                ${colors[player.color]}
                                border-2 border-white
                                ${canMove ? 'cursor-pointer animate-pulse' : ''}
                            `}
                            // Placeholder position - replace with real layout calculation
                            style={{ top: `${20 + piece.position * 1.5}%`, left: `${20 + player.pieces.indexOf(piece) * 5}%` }}
                            disabled={!canMove}
                        >
                            <span className="text-xs text-white font-bold">{piece.id + 1}</span>
                        </button>
                    );
                })
            )}

        </div>
    );
};

export default GameBoard;
