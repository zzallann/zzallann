import React from 'react';
import type { GamePlayer } from '../../types';
import { avatars } from '../AvatarSelector';

interface PlayerProfileModalProps {
  player: GamePlayer | null;
  onClose: () => void;
}

const PlayerProfileModal: React.FC<PlayerProfileModalProps> = ({ player, onClose }) => {
  if (!player) return null;

  const playerAvatar = avatars.find(a => a.id === player.user.avatarId);

  return (
    <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex justify-center items-center z-50 animate-fade-in" onClick={onClose}>
      <div className="bg-slate-800 w-full max-w-xs rounded-2xl shadow-2xl p-6 text-white text-center" onClick={e => e.stopPropagation()}>
        <div className="relative w-24 h-24 mx-auto mb-4">
          <div className="w-full h-full rounded-full overflow-hidden bg-slate-700 ring-4 ring-orange-500">
            {player.user.uploadedImage ? (
              <img src={player.user.uploadedImage} alt="Avatar" className="w-full h-full object-cover" />
            ) : playerAvatar ? (
              <playerAvatar.component />
            ) : (
              <div className="w-full h-full flex items-center justify-center text-4xl font-bold">
                {player.user.name.charAt(0).toUpperCase()}
              </div>
            )}
          </div>
        </div>
        <h2 className="text-2xl font-bold font-lilita">{player.user.name}</h2>
        <p className="text-sm text-white/70">Szín: <span style={{ color: player.color }}>{player.color}</span></p>
        <button onClick={onClose} className="mt-6 w-full px-4 py-2 bg-orange-600 font-bold rounded-full text-lg shadow-lg">
          Bezárás
        </button>
      </div>
    </div>
  );
};

export default PlayerProfileModal;
