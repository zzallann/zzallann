import React, { useState, useEffect, useCallback } from 'react';

const TENOR_API_KEY = 'LIVDSRZULELA'; // Public developer key
const CLIENT_KEY = 'astoria-app-0.1'; // Client key for analytics

interface GifPickerProps {
    onSelectGif: (url: string) => void;
    onClose: () => void;
}

// Simple debounce function
const debounce = <F extends (...args: any[]) => any>(func: F, waitFor: number) => {
    let timeout: ReturnType<typeof setTimeout> | null = null;
    return (...args: Parameters<F>): void => {
        if (timeout) {
            clearTimeout(timeout);
        }
        timeout = setTimeout(() => func(...args), waitFor);
    };
};

const GifPicker: React.FC<GifPickerProps> = ({ onSelectGif, onClose }) => {
    const [searchTerm, setSearchTerm] = useState('');
    const [gifs, setGifs] = useState<any[]>([]);
    const [isLoading, setIsLoading] = useState(false);

    const fetchGifs = async (query: string) => {
        setIsLoading(true);
        setGifs([]);
        const baseUrl = 'https://tenor.googleapis.com/v2/';
        const params = new URLSearchParams({
            key: TENOR_API_KEY,
            client_key: CLIENT_KEY,
            limit: '24',
            locale: 'hu-HU',
            contentfilter: 'medium',
        });
        
        let endpoint = '';
        if (query) {
            params.append('q', query);
            endpoint = `search?${params.toString()}`;
        } else {
            endpoint = `trending?${params.toString()}`;
        }

        try {
            const response = await fetch(baseUrl + endpoint);
            const data = await response.json();
            setGifs(data.results || []);
        } catch (error) {
            console.error("Failed to fetch GIFs from Tenor", error);
        } finally {
            setIsLoading(false);
        }
    };

    const debouncedFetchGifs = useCallback(debounce(fetchGifs, 500), []);

    useEffect(() => {
        debouncedFetchGifs(searchTerm);
    }, [searchTerm, debouncedFetchGifs]);

    // Initial fetch for trending GIFs
    useEffect(() => {
        fetchGifs('');
    }, []);

    return (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex justify-center items-center z-50 animate-fade-in" onClick={onClose}>
            <div className="bg-[var(--component-bg)] w-full max-w-lg h-[80vh] rounded-2xl shadow-2xl flex flex-col p-4 transition-colors duration-300" onClick={(e) => e.stopPropagation()}>
                <div className="flex-shrink-0 mb-4">
                    <input 
                        type="text"
                        placeholder="GIF keresése a Tenor-on..."
                        value={searchTerm}
                        onChange={(e) => setSearchTerm(e.target.value)}
                        className="w-full px-4 py-2 bg-[var(--input-bg)] text-[var(--text-primary)] border-2 border-transparent rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500 focus:border-transparent transition"
                        autoFocus
                    />
                </div>
                <div className="flex-1 overflow-y-auto pr-2">
                    {isLoading && <p className="text-center text-[var(--text-primary)]">Töltés...</p>}
                    <div className="grid grid-cols-2 md:grid-cols-3 gap-2">
                        {gifs.map(gif => (
                             <div 
                                key={gif.id} 
                                className="cursor-pointer aspect-square bg-[var(--input-bg)] bg-opacity-50 rounded-md" 
                                onClick={() => onSelectGif(gif.media_formats.mediumgif.url)}
                            >
                                <img 
                                    src={gif.media_formats.tinygif.url} 
                                    alt={gif.content_description} 
                                    className="w-full h-full object-cover rounded-md" 
                                    loading="lazy"
                                />
                            </div>
                        ))}
                    </div>
                </div>
                 <p className="text-center text-xs text-[var(--text-tertiary)] mt-4">
                    Forrás: <a href="https://tenor.com/hu/" target="_blank" rel="noopener noreferrer" className="font-bold underline hover:text-[var(--text-primary)] transition-colors">Tenor</a>
                 </p>
                 <button onClick={onClose} className="mt-2 w-full px-4 py-2 bg-slate-600/50 text-[var(--text-primary)] font-bold rounded-full text-lg shadow-lg transform hover:scale-105 transition-transform duration-200">
                    Bezárás
                </button>
            </div>
        </div>
    );
};

export default GifPicker;