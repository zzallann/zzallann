import React, { useState } from 'react';
import type { User } from '../types';
import { avatars } from './AvatarSelector';
import SettingsIcon from './icons/SettingsIcon';
import LogoutIcon from './icons/LogoutIcon';
import UserStatusBadge from './UserStatusBadge';
import LogoutModal from './LogoutModal';

const getMenuItems = (userStatus: User['status']) => {
    let oktatasName = 'Oktatásom';
    if (userStatus === 'pro_max') {
        // FIX: Corrected typo from `oktasName` to `oktatasName`.
        oktatasName = 'Oktatás';
    } else if (userStatus === 'pro') {
        // FIX: Corrected typo from `oktasName` to `oktatasName`.
        oktatasName = 'Oktatás leadása és kiadása';
    }

    const baseItems = [
        { id: 'hirfolyam', name: 'Hírfolyam' },
    ];

    if (userStatus === 'pro' || userStatus === 'pro_max') {
        baseItems.push(
            { id: 'selejt', name: 'Selejt' }
        );
    }
    if (userStatus === 'pro_max') {
        baseItems.push(
            { id: 'push', name: 'Push küldése' }
        );
    }
    
    baseItems.push(
        { id: 'oktatasom', name: oktatasName },
        { id: 'uzenetek', name: 'Üzenetek' },
        { id: 'etkezes', name: userStatus === 'pro_max' ? 'Mai fogyasztás' : 'Étkezés megadása' },
        { id: 'munkaido', name: userStatus === 'pro_max' ? 'Beosztási kérelmek' : 'Munkaidő kérelem' },
        { id: 'beosztas', name: 'Heti beosztás' },
        { id: 'kollegak', name: userStatus === 'pro_max' ? 'Csapatlista' : 'Kollégák' },
        { id: 'havi_kedvenc', name: 'Havi kedvenc' },
        { id: 'dijazottak', name: 'Díjazottak, programok' },
    );
    
    return baseItems;
};

const formatCrowns = (points: number): string => {
  const roundedUp = Math.ceil(points * 100) / 100;
  return roundedUp.toLocaleString('hu-HU', {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  });
};

interface SidebarProps {
    user: User;
    isOpen: boolean;
    onClose: () => void;
    onNavigate: (view: string) => void;
    onLogout: () => void;
    totalUnreadCount: number;
    unreadTaskCount: number;
}

const Sidebar: React.FC<SidebarProps> = ({ user, isOpen, onClose, onNavigate, onLogout, totalUnreadCount, unreadTaskCount }) => {
    const userAvatar = avatars.find(a => a.id === user.avatarId);
    const menuItems = getMenuItems(user.status);

    const handleNavigationClick = (viewId: string) => {
        onNavigate(viewId);
    };

    return (
        <>
            {/* Overlay for mobile */}
            {isOpen && <div className="fixed inset-0 bg-black/60 z-30 md:hidden" onClick={onClose} />}

            {/* Sidebar */}
            <aside className={`
                transform transition-transform duration-300 ease-in-out
                fixed inset-y-0 left-0 z-40 w-64
                bg-[var(--component-bg)] backdrop-blur-md
                md:relative md:inset-auto md:z-auto md:w-64
                md:bg-[var(--component-bg)] md:backdrop-blur-sm
                md:rounded-2xl md:translate-x-0
                flex-shrink-0 flex flex-col
                ${isOpen ? 'translate-x-0' : '-translate-x-full'}
            `}>
                <div className="p-4 flex flex-col h-full">
                    <nav className="flex-1">
                        <ul>
                            {/* Profile Item */}
                            <li>
                                <button onClick={() => handleNavigationClick('profil')} className="w-full flex items-center gap-3 p-3 text-[var(--text-primary)] rounded-lg hover:bg-[var(--component-bg-hover)] transition-colors duration-200">
                                    <div className="w-10 h-10 rounded-full overflow-hidden flex-shrink-0 bg-slate-700/50">
                                        {user.uploadedImage ? (
                                            <img src={user.uploadedImage} alt="Avatar" className="w-full h-full object-cover"/>
                                        ) : userAvatar ? (
                                            <userAvatar.component />
                                        ) : (
                                            <div className="w-full h-full flex items-center justify-center text-xl font-bold text-[var(--text-primary)]">
                                                {user.name.charAt(0).toUpperCase()}
                                            </div>
                                        )}
                                    </div>
                                    <div className="flex flex-col leading-tight text-left">
                                        <span className="font-bold flex items-center">{user.name} <UserStatusBadge user={user} /></span>
                                        <span className="text-sm font-normal text-[var(--text-secondary)]">{formatCrowns(user.points)} korona</span>
                                    </div>
                                 </button>
                            </li>

                            <hr className="border-t border-[var(--border-color)] my-2"/>

                            {/* Other Menu Items */}
                            {menuItems.map(item => (
                                <li key={item.id}>
                                    <button onClick={() => handleNavigationClick(item.id)} className="w-full text-left flex items-center gap-4 p-3 text-[var(--text-primary)] font-bold rounded-lg hover:bg-[var(--component-bg-hover)] transition-colors duration-200">
                                        <span>{item.name}</span>
                                        {item.id === 'uzenetek' && totalUnreadCount > 0 && (
                                            <span className="ml-auto bg-red-600 text-white text-xs font-bold rounded-full h-5 w-5 flex items-center justify-center animate-pop">
                                                {totalUnreadCount}
                                            </span>
                                        )}
                                        {item.id === 'oktatasom' && unreadTaskCount > 0 && (
                                            <span className="ml-auto bg-blue-600 text-white text-xs font-bold rounded-full h-5 w-5 flex items-center justify-center animate-pop">
                                                {unreadTaskCount}
                                            </span>
                                        )}
                                    </button>
                                </li>
                            ))}
                        </ul>
                    </nav>
                </div>
            </aside>
        </>
    );
};

export default Sidebar;
