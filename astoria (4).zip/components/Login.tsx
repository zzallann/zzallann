import React, { useState } from 'react';
import { authService } from '../services/authService';
import type { User } from '../types';

interface LoginProps {
  onLoginSuccess: (user: User) => void;
  onSwitchToRegister: () => void;
  onForgotPassword: () => void;
}

const Login: React.FC<LoginProps> = ({ onLoginSuccess, onSwitchToRegister, onForgotPassword }) => {
  const [identifier, setIdentifier] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setIsLoading(true);
    try {
      const user = await authService.login(identifier, password);
      onLoginSuccess(user);
    } catch (err: any) {
      setError(err.message || 'Ismeretlen hiba történt.');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="w-full max-w-sm bg-[var(--component-bg)] backdrop-blur-sm p-8 rounded-2xl shadow-lg animate-fade-in">
      <h2 className="text-3xl font-bold text-[var(--text-primary)] text-center mb-6 font-lilita">Bejelentkezés</h2>
      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <label htmlFor="login-identifier" className="block text-[var(--text-primary)] font-semibold mb-1">Azonosító kód</label>
          <input
            type="text"
            id="login-identifier"
            value={identifier}
            onChange={(e) => setIdentifier(e.target.value)}
            className="w-full px-4 py-2 bg-[var(--input-bg)] text-[var(--text-primary)] border-2 border-transparent rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500 focus:border-transparent transition"
            required
            disabled={isLoading}
          />
        </div>
        <div>
          <label htmlFor="login-password" className="block text-[var(--text-primary)] font-semibold mb-1">Jelszó</label>
          <input
            type="password"
            id="login-password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            className="w-full px-4 py-2 bg-[var(--input-bg)] text-[var(--text-primary)] border-2 border-transparent rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500 focus:border-transparent transition"
            required
            disabled={isLoading}
          />
        </div>
        
        {error && <p className="text-orange-300 text-sm text-center bg-orange-800/50 p-2 rounded-lg">{error}</p>}
        
        <button
          type="submit"
          disabled={isLoading}
          className="w-full mt-4 px-4 py-3 bg-orange-600 text-white font-bold rounded-full text-lg shadow-lg transform hover:scale-105 transition-transform duration-200 disabled:bg-orange-400 disabled:scale-100 disabled:cursor-not-allowed"
        >
          {isLoading ? 'Folyamatban...' : 'Bejelentkezés'}
        </button>
      </form>
      <div className="text-center text-[var(--text-primary)] mt-4 text-sm">
        <button onClick={onForgotPassword} className="hover:underline" disabled={isLoading}>
          Elfelejtetted a jelszavad?
        </button>
      </div>
      <p className="text-center text-[var(--text-primary)] mt-6">
        Még nincs fiókod?{' '}
        <button onClick={onSwitchToRegister} className="font-bold hover:underline" disabled={isLoading}>
          Regisztrálj!
        </button>
      </p>
    </div>
  );
};

export default Login;