import React, { useMemo } from 'react';
import type { Message } from '../types';
import XCircleIcon from './icons/XCircleIcon';

interface ChatMediaModalProps {
    isOpen: boolean;
    onClose: () => void;
    messages: Message[];
}

const ChatMediaModal: React.FC<ChatMediaModalProps> = ({ isOpen, onClose, messages }) => {
    const mediaMessages = useMemo(() => 
        messages.filter(m => m.imageUrl || m.gifUrl).reverse()
    , [messages]);

    if (!isOpen) return null;

    return (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex justify-center items-center animate-fade-in" onClick={onClose}>
            <div className="bg-slate-800 w-full max-w-2xl h-[90vh] rounded-2xl shadow-2xl flex flex-col" onClick={e => e.stopPropagation()}>
                <div className="flex justify-between items-center p-4 border-b border-slate-700">
                    <h3 className="text-xl font-bold text-white">Média</h3>
                    <button onClick={onClose} className="p-1 rounded-full hover:bg-slate-700"><XCircleIcon className="w-6 h-6 text-slate-400"/></button>
                </div>
                <div className="flex-1 p-4 overflow-y-auto">
                    {mediaMessages.length > 0 ? (
                        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-2">
                            {mediaMessages.map(msg => {
                                const url = msg.imageUrl || msg.gifUrl;
                                return (
                                    <a key={msg.id} href={url!} target="_blank" rel="noopener noreferrer" className="aspect-square bg-slate-700 rounded-lg overflow-hidden">
                                        <img src={url!} alt="Média" className="w-full h-full object-cover" />
                                    </a>
                                );
                            })}
                        </div>
                    ) : (
                        <p className="text-center text-slate-400 mt-8">Nincs megosztott média ebben a beszélgetésben.</p>
                    )}
                </div>
            </div>
        </div>
    );
};

export default ChatMediaModal;