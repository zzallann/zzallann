import React, { useState, useEffect, useMemo } from 'react';
import type { User, MealLog, MealMenuItem } from '../types';
import AccordionItem from './AccordionItem';
import SendIcon from './icons/SendIcon';
import PlusIcon from './icons/PlusIcon';
import MinusIcon from './icons/MinusIcon';
import ArrowLeftIcon from './icons/ArrowLeftIcon';
import EyeIcon from './icons/EyeIcon';
import EyeSlashIcon from './icons/EyeSlashIcon';
import { useNotification } from '../contexts/NotificationContext';
import { mealService } from '../services/mealService';
import { authService } from '../services/authService';
import { avatars } from './AvatarSelector';
import ZebraIcon from './icons/ZebraIcon';
import CheckCircleIcon from './icons/CheckCircleIcon';
import SearchIcon from './icons/SearchIcon';
import PencilIcon from './icons/PencilIcon';
import TrashIcon from './icons/TrashIcon';
import SaveIcon from './icons/SaveIcon';


interface SelectedItem extends MealMenuItem {
    quantity: number;
}

type View = 'selection' | 'summary' | 'success';

interface MealLoggingPageProps {
    user: User;
    onUserUpdate: (user: User) => void;
}

const formatCrowns = (points: number): string => {
    const roundedUp = Math.ceil(points * 100) / 100;
    return roundedUp.toLocaleString('hu-HU', {
        minimumFractionDigits: 2,
        maximumFractionDigits: 2,
    });
};

const MealLoggingPage: React.FC<MealLoggingPageProps> = ({ user, onUserUpdate }) => {
    const [view, setView] = useState<View>('selection');
    const [openAccordion, setOpenAccordion] = useState<string | null>(null);
    const [selectedItems, setSelectedItems] = useState<Record<string, SelectedItem>>({});
    const [isSubmitting, setIsSubmitting] = useState(false);
    const { addNotification } = useNotification();
    const [searchTerm, setSearchTerm] = useState('');

    const [menuData, setMenuData] = useState<Record<string, MealMenuItem[]>>({});
    const [isLoadingMenu, setIsLoadingMenu] = useState(true);
    const [isEditMode, setIsEditMode] = useState(false);
    const [isProMaxLogging, setIsProMaxLogging] = useState(false); // For ProMax to toggle between summary and logging
    
    // States for the edit modal
    const [isModalOpen, setIsModalOpen] = useState(false);
    const [editingItem, setEditingItem] = useState<{item: MealMenuItem, category: string, isNew: boolean} | null>(null);
    const [modalData, setModalData] = useState<{name: string, price: string, unit: 'db' | 'kg'}>({name: '', price: '0', unit: 'db'});

    // For Pro Max 
    const [todaysLogs, setTodaysLogs] = useState<MealLog[]>([]);
    const [isLoadingLogs, setIsLoadingLogs] = useState(true);
    const [customUserName, setCustomUserName] = useState('');
    const [isLoggingForSelf, setIsLoggingForSelf] = useState(true);

    // For Normal & Pro user
    const [hasClaimedToday, setHasClaimedToday] = useState(false);
    const [isCheckingClaim, setIsCheckingClaim] = useState(user.status === 'normal' || user.status === 'pro');

    const isProUser = user.status === 'pro' || user.status === 'pro_max';

    const fetchMenu = async () => {
        setIsLoadingMenu(true);
        const menu = await mealService.getMenu();
        setMenuData(menu);
        setIsLoadingMenu(false);
    };

    useEffect(() => {
        fetchMenu();
    }, []);

    const fetchLogs = async () => {
        if (user.status === 'pro_max') {
            setIsLoadingLogs(true);
            const logs = await mealService.getTodaysLogs();
            setTodaysLogs(logs);
            setIsLoadingLogs(false);
        }
    };
    
    useEffect(() => {
        const checkClaimStatus = async () => {
            if (user.status === 'normal' || user.status === 'pro') {
                setIsCheckingClaim(true);
                const logs = await mealService.getTodaysLogs();
                // A claim is identified by its description, which is different from itemized entries
                const userLog = logs.find(log => log.userId === user.id && (log.items[0]?.name.includes('műszak')));
                setHasClaimedToday(!!userLog);
                setIsCheckingClaim(false);
            }
        };

        if (user.status === 'normal' || user.status === 'pro') {
            checkClaimStatus();
        } else if (user.status === 'pro_max') {
            fetchLogs();
        }
    }, [user.status, user.id]);


    useEffect(() => {
        if (user.status === 'pro_max' && view === 'selection') { // view check to avoid changing name in summary
            setCustomUserName(user.name);
            setIsLoggingForSelf(true);
        }
    }, [view, user.status, user.name]);

    const filteredMenuData = useMemo(() => {
        if (!searchTerm.trim()) {
            return menuData;
        }
        const lowercasedFilter = searchTerm.toLowerCase();
        const filtered: Record<string, MealMenuItem[]> = {};

        for (const category in menuData) {
            const matchingItems = menuData[category].filter(item =>
                item.name.toLowerCase().includes(lowercasedFilter)
            );
            if (matchingItems.length > 0) {
                filtered[category] = matchingItems;
            }
        }
        return filtered;
    }, [searchTerm, menuData]);

    const handleToggleAccordion = (title: string) => {
        setOpenAccordion(openAccordion === title ? null : title);
    };

    const handleQuantityChange = (item: MealMenuItem, change: 1 | -1) => {
        setSelectedItems(prev => {
            const existingItem = prev[item.name];
            const newQuantity = (existingItem?.quantity || 0) + change;
            const newItems = { ...prev };

            if (newQuantity <= 0) {
                delete newItems[item.name];
            } else {
                newItems[item.name] = { ...item, quantity: newQuantity };
            }
            return newItems;
        });
    };
    
    const handleDecimalQuantityChange = (item: MealMenuItem, value: string) => {
        const newQuantity = parseFloat(value);
        setSelectedItems(prev => {
            const newItems = { ...prev };
            if (isNaN(newQuantity) || newQuantity <= 0) {
                delete newItems[item.name];
            } else {
                newItems[item.name] = { ...item, quantity: newQuantity };
            }
            return newItems;
        });
    };

    const totalQuantity = (Object.values(selectedItems) as SelectedItem[]).reduce((sum, item) => sum + item.quantity, 0);
    const totalPrice = (Object.values(selectedItems) as SelectedItem[]).reduce((sum, item) => sum + (item.price * item.quantity), 0);
    
    const handleSubmit = async () => {
        setIsSubmitting(true);
        try {
            const itemsArray = Object.values(selectedItems).map(({ name, quantity, price, unit }) => ({ name, quantity, price }));
            
            let loggerDetails: { id: string; name: string; avatarId: string | null; uploadedImage: string | null; };
            let shouldDeductPoints = false;
            let pointDeductionUser = user;
    
            if (user.status === 'pro_max') {
                if (!customUserName.trim()) {
                    addNotification('A fogyasztó nevét meg kell adni.', 'error');
                    setIsSubmitting(false);
                    return;
                }
                 if (isLoggingForSelf) {
                    loggerDetails = { id: user.id, name: user.name, avatarId: user.avatarId, uploadedImage: user.uploadedImage };
                    shouldDeductPoints = true;
                 } else {
                    loggerDetails = { id: `external_${Date.now()}`, name: customUserName, avatarId: null, uploadedImage: null };
                 }
            } else { // 'pro' or 'normal' user
                loggerDetails = { id: user.id, name: user.name, avatarId: user.avatarId, uploadedImage: user.uploadedImage };
                shouldDeductPoints = true;
            }
    
            if (shouldDeductPoints && pointDeductionUser.points < totalPrice) {
                addNotification('Nincs elég koronád ehhez a rendeléshez.', 'error');
                setIsSubmitting(false);
                return;
            }
    
            await mealService.logMeal(loggerDetails, itemsArray, totalPrice);
            
            if (shouldDeductPoints) {
                const updatedUser = {
                    ...pointDeductionUser,
                    points: pointDeductionUser.points - totalPrice,
                    pointsHistory: [
                        { reason: 'Étkezés', points: -totalPrice, date: Date.now() },
                        ...(pointDeductionUser.pointsHistory || [])
                    ]
                };
                authService.updateUser(updatedUser);
                onUserUpdate(updatedUser);
                addNotification(`${formatCrowns(totalPrice)} korona levonva étkezésre.`, 'success');
            } else {
                addNotification('Rendelés rögzítve.', 'success');
            }
    
            setView('success');

        } catch (error) {
            addNotification('Hiba a rendelés leadásakor.', 'error');
        } finally {
            setIsSubmitting(false);
        }
    };

    const handleNewOrder = () => {
        setSelectedItems({});
        setView('selection');
        setIsProMaxLogging(false);
         if (user.status === 'pro_max') {
            fetchLogs();
        }
    };
    
    const handleClaimAllowance = async (amount: number, description: string) => {
        setIsSubmitting(true);
        try {
            const itemsArray = [{ name: description, quantity: 1, price: amount }];
            await mealService.logMeal(
                { id: user.id, name: user.name, avatarId: user.avatarId, uploadedImage: user.uploadedImage },
                itemsArray,
                amount
            );

            const updatedUser = {
                ...user,
                points: user.points + amount,
                pointsHistory: [
                    { reason: 'Napi étkezési hozzájárulás', points: amount, date: Date.now() },
                    ...(user.pointsHistory || [])
                ]
            };
            authService.updateUser(updatedUser);
            onUserUpdate(updatedUser);
            
            addNotification(`${amount} korona jóváírva étkezésre.`, 'success');
            setHasClaimedToday(true);
        } catch (error) {
            addNotification('Hiba a rögzítéskor.', 'error');
        } finally {
            setIsSubmitting(false);
        }
    };
    
    // Edit mode functions
    const handleOpenModal = (item: MealMenuItem | null, category: string) => {
        if (item) {
            setEditingItem({ item, category, isNew: false });
            setModalData({ name: item.name, price: String(item.price), unit: item.unit });
        } else {
            setEditingItem({ item: { name: '', price: 0, unit: 'db' }, category, isNew: true });
            setModalData({ name: '', price: '0', unit: 'db' });
        }
        setIsModalOpen(true);
    };

    const handleCloseModal = () => {
        setIsModalOpen(false);
        setEditingItem(null);
    };
    
    const handleSaveItem = () => {
        if (!editingItem) return;

        const price = parseFloat(modalData.price);
        if (!modalData.name.trim() || isNaN(price) || price < 0) {
            addNotification('Érvénytelen név vagy ár.', 'error');
            return;
        }

        const oldName = editingItem.isNew ? null : editingItem.item.name;
        const newItem: MealMenuItem = { name: modalData.name.trim(), price, unit: modalData.unit };

        setMenuData(prevMenu => {
            const newMenu = JSON.parse(JSON.stringify(prevMenu));
            const targetCategory = editingItem.category;

            if (oldName && oldName !== newItem.name) {
                const itemExists = Object.values(newMenu).flat().some((i: any) => i.name === newItem.name);
                if (itemExists) {
                    addNotification('Már létezik ilyen nevű tétel.', 'error');
                    return prevMenu; // Abort update
                }
            }

            if (oldName) {
                const categoryItems = newMenu[targetCategory] as MealMenuItem[];
                const itemIndex = categoryItems.findIndex(i => i.name === oldName);
                if (itemIndex > -1) {
                    categoryItems.splice(itemIndex, 1);
                }
            }
            
            if (!newMenu[targetCategory]) newMenu[targetCategory] = [];
            
            newMenu[targetCategory].push(newItem);
            newMenu[targetCategory].sort((a: MealMenuItem, b: MealMenuItem) => a.name.localeCompare(b.name));

            return newMenu;
        });
        handleCloseModal();
    };

    const handleDeleteItem = (itemToDelete: MealMenuItem, category: string) => {
        if (window.confirm(`Biztosan törlöd a következőt: ${itemToDelete.name}? A művelet nem vonható vissza.`)) {
            setMenuData(prevMenu => {
                const newMenu = JSON.parse(JSON.stringify(prevMenu));
                newMenu[category] = newMenu[category].filter((i: MealMenuItem) => i.name !== itemToDelete.name);
                return newMenu;
            });
        }
    };
    
    const handleSaveMenu = async () => {
        await mealService.saveMenu(menuData);
        addNotification("Menü sikeresen elmentve!", "success");
        setIsEditMode(false);
    };

    if (view === 'success') {
         return (
            <div className="w-full max-w-2xl mx-auto animate-fade-in text-white text-center">
                 <div className="bg-white/10 dark:bg-slate-800/30 backdrop-blur-sm rounded-2xl shadow-lg p-8">
                     <img 
                        src="https://media3.giphy.com/media/v1.Y2lkPTc5MGI3NjExMzBhNnVyZWdleHJ1ZTZ6dnJsbjI5czVwazllNTE4dXRhdjR3OTJwciZlcD12MV9pbnRlcm5hbF9naWZfYnlfaWQmY3Q9Zw/W7hqeUiClfUoi0CF6X/giphy.gif"
                        alt="Jó étvágyat"
                        className="mx-auto w-48 h-48 rounded-lg"
                     />
                     <p className="text-2xl font-bold font-lilita mt-4">Jó étvágyat!</p>
                     <button
                        onClick={handleNewOrder}
                        className="mt-8 px-6 py-3 bg-orange-600 text-white font-bold rounded-full shadow-lg transform hover:scale-105 transition-transform duration-200"
                    >
                       {user.status === 'pro_max' ? 'Vissza a listához' : 'Új rendelés'}
                    </button>
                 </div>
            </div>
        )
    }

    if (user.status === 'pro_max' && !isProMaxLogging && !isEditMode && view !== 'summary') {
        const itemizedLogs = todaysLogs.filter(log => !(log.items.length === 1 && log.items[0].name.includes('hozzájárulás')));
        const totalConsumption = itemizedLogs.reduce((sum, log) => sum + log.totalPrice, 0);
        const itemizedLogsByUser = itemizedLogs.reduce((acc: Record<string, MealLog[]>, log) => {
            const key = log.userId;
            if (!acc[key]) acc[key] = [];
            acc[key].push(log);
            return acc;
        }, {} as Record<string, MealLog[]>);

        return (
             <div className="w-full max-w-2xl mx-auto animate-fade-in space-y-6 text-white">
                <div className="flex justify-center items-center gap-4">
                    <h1 className="text-3xl font-bold font-lilita tracking-wide text-center">Mai fogyasztás</h1>
                    <button onClick={() => setIsProMaxLogging(true)} title="Új fogyasztás rögzítése" className="p-2 rounded-full text-white bg-green-600 hover:bg-green-700 transition-colors">
                        <PlusIcon className="w-6 h-6" />
                    </button>
                    <button onClick={() => setIsEditMode(true)} title="Menü szerkesztése" className="p-2 rounded-full text-white bg-slate-700/50 hover:bg-slate-600/50 transition-colors">
                        <PencilIcon className="w-6 h-6" />
                    </button>
                </div>
                <div className="bg-slate-800/30 backdrop-blur-sm rounded-2xl shadow-lg p-6">
                    {isLoadingLogs ? <p>Lista betöltése...</p> : todaysLogs.length === 0 ? <p>Ma még nem volt fogyasztás rögzítve.</p> : (
                        <>
                            <h3 className="text-xl font-bold font-lilita mb-3 border-b border-white/20 pb-2">Részletes Fogyasztás</h3>
                            {Object.keys(itemizedLogsByUser).length === 0 ? <p className="text-sm text-white/70">Nincs részletes fogyasztás rögzítve.</p> : (
                                <div className="space-y-4 max-h-[40vh] overflow-y-auto pr-2">
                                    {Object.keys(itemizedLogsByUser).map(userId => {
                                        const logs = itemizedLogsByUser[userId];
                                        const firstLog = logs[0];
                                        const logUserAvatar = avatars.find(a => a.id === firstLog.userAvatarId);
                                        const isExternal = userId.startsWith('external_');

                                        return (
                                            <div key={userId} className="bg-slate-900/40 p-3 rounded-lg">
                                                <div className="flex items-center gap-3 mb-2">
                                                    <div className="w-10 h-10 rounded-full overflow-hidden flex-shrink-0 bg-slate-700/50 flex items-center justify-center">
                                                        {isExternal ? (<ZebraIcon />) : firstLog.userUploadedImage ? (<img src={firstLog.userUploadedImage} alt={firstLog.userName}/>) : logUserAvatar ? (<logUserAvatar.component/>) : null}
                                                    </div>
                                                    <div>
                                                        <p className="font-bold">{firstLog.userName}</p>
                                                        <p className="text-xs text-amber-400 font-semibold">
                                                            {formatCrowns(logs.reduce((sum, l) => sum + l.totalPrice, 0))} korona
                                                        </p>
                                                    </div>
                                                </div>
                                                <div className="space-y-1 pl-2">
                                                    {logs.map(log => (
                                                        <ul key={log.id} className="text-sm list-disc list-inside text-white/80 border-t border-white/10 pt-1 mt-1 first:border-t-0 first:pt-0 first:mt-0">
                                                            {log.items.map(item => <li key={item.name}>{item.name} <span className="text-white/60">x{item.quantity}</span></li>)}
                                                        </ul>
                                                    ))}
                                                </div>
                                            </div>
                                        );
                                    })}
                                </div>
                            )}
                        </>
                    )}
                     <div className="mt-6 pt-4 border-t-2 border-white/20 flex justify-between items-center">
                        <span className="text-xl font-bold">Mai Összes Fogyasztás:</span>
                        <span className="text-2xl font-bold text-amber-400">{formatCrowns(totalConsumption)} korona</span>
                    </div>
                </div>
            </div>
        )
    }
    
    if (view === 'summary') {
        return (
             <div className="w-full max-w-2xl mx-auto animate-fade-in space-y-6 text-white">
                <div className="bg-white/10 dark:bg-slate-800/30 backdrop-blur-sm rounded-2xl shadow-lg p-6">
                    <button onClick={() => setView('selection')} className="flex items-center gap-2 mb-4 font-semibold hover:text-orange-300 transition-colors">
                        <ArrowLeftIcon className="w-5 h-5"/>
                        Vissza a választáshoz
                    </button>
                    <h1 className="text-3xl font-bold font-lilita tracking-wide text-center mb-6">Rendelés összegzése</h1>
                    <div className="space-y-3 max-h-96 overflow-y-auto pr-2">
                        {/* FIX: Explicitly type 'item' to resolve TypeScript errors. */}
                        {Object.values(selectedItems).map((item: SelectedItem) => (
                            <div key={item.name} className="flex justify-between items-center p-3 bg-slate-900/30 rounded-lg">
                                <div>
                                    <p className="font-bold">{item.name} <span className="text-white/70">x{item.quantity}{item.unit}</span></p>
                                    <p className="text-sm text-white/70">{formatCrowns(item.price)} korona / {item.unit}</p>
                                </div>
                                <p className="font-bold text-lg">{formatCrowns(item.price * item.quantity)} korona</p>
                            </div>
                        ))}
                    </div>
                    <div className="mt-6 pt-4 border-t-2 border-white/20 flex justify-between items-center">
                        <span className="text-xl font-bold">Végösszeg:</span>
                        <span className="text-2xl font-bold text-amber-400">{formatCrowns(totalPrice)} korona</span>
                    </div>
                     <button
                        onClick={handleSubmit}
                        disabled={isSubmitting}
                        className="w-full mt-6 flex items-center justify-center gap-2 px-4 py-3 bg-orange-600 text-white font-bold rounded-full shadow-lg transform hover:scale-105 transition-transform duration-200 disabled:bg-orange-400 disabled:scale-100"
                    >
                        <SendIcon className="w-5 h-5" />
                        <span>{isSubmitting ? 'Küldés...' : 'Véglegesítés és küldés'}</span>
                    </button>
                </div>
            </div>
        )
    }

    if (user.status === 'normal' || user.status === 'pro') {
        if (isCheckingClaim) return <div className="text-white text-center">Státusz ellenőrzése...</div>;
        if (!hasClaimedToday) {
            return (
                <div className="w-full max-w-2xl mx-auto animate-fade-in space-y-6 text-white">
                    <h1 className="text-3xl font-bold font-lilita tracking-wide text-center">Étkezés igénylése</h1>
                    <div className="bg-slate-800/30 backdrop-blur-sm rounded-2xl shadow-lg p-6 text-center">
                        <p className="text-white/80 mb-6">Válaszd ki a műszakodnak megfelelő étkezési hozzájárulást. Ez az összeg hozzáadásra kerül a korona egyenlegedhez. Naponta egyszer igényelhető.</p>
                        <div className="space-y-4">
                            <button onClick={() => handleClaimAllowance(700, 'Napi hozzájárulás (8 óra alatt)')} disabled={isSubmitting} className="w-full p-4 bg-orange-600 rounded-lg font-bold text-lg shadow-lg transform hover:scale-105 transition-transform disabled:bg-slate-500 disabled:cursor-not-allowed">
                                <div>8 óra alatti műszak</div><div className="text-2xl">700 korona</div>
                            </button>
                            <button onClick={() => handleClaimAllowance(800, 'Napi hozzájárulás (8 óra felett)')} disabled={isSubmitting} className="w-full p-4 bg-orange-700 rounded-lg font-bold text-lg shadow-lg transform hover:scale-105 transition-transform disabled:bg-slate-500 disabled:cursor-not-allowed">
                                <div>8 óra feletti műszak</div><div className="text-2xl">800 korona</div>
                            </button>
                        </div>
                    </div>
                </div>
            );
        }
    }
    
    const pageTitle = isEditMode ? "Menü Szerkesztése" : (user.status === 'pro_max' ? "Tétel felvitele" : "Mit fogyasztottál?");

    return (
        <div className="w-full max-w-2xl mx-auto animate-fade-in pb-24">
            <div className="bg-white/10 dark:bg-slate-800/30 backdrop-blur-sm rounded-2xl shadow-lg p-6">
                <div className="text-center mb-6 relative">
                    {user.status === 'pro_max' && isProMaxLogging && (
                        <button onClick={() => setIsProMaxLogging(false)} className="absolute left-0 top-1/2 -translate-y-1/2 p-2 rounded-full hover:bg-white/10">
                            <ArrowLeftIcon className="w-6 h-6" />
                        </button>
                    )}
                    <div className="flex justify-center items-center gap-4">
                        <h1 className="text-3xl font-bold text-white font-lilita tracking-wide">{pageTitle}</h1>
                        {isProUser && user.status !== 'pro_max' && (
                            <button onClick={() => setIsEditMode(prev => !prev)} title="Szerkesztés mód" className={`p-2 rounded-full text-white transition-colors ${isEditMode ? 'bg-orange-600' : 'bg-slate-700/50 hover:bg-slate-600/50'}`}>
                                <PencilIcon className="w-6 h-6" />
                            </button>
                        )}
                         {isProUser && user.status === 'pro_max' && (
                             <button onClick={() => setIsEditMode(prev => !prev)} title={isEditMode ? "Fogyasztás nézet" : "Szerkesztés nézet"} className={`p-2 rounded-full text-white transition-colors ${isEditMode ? 'bg-orange-600' : 'bg-slate-700/50 hover:bg-slate-600/50'}`}>
                                {isEditMode ? <EyeIcon className="w-6 h-6" /> : <PencilIcon className="w-6 h-6" />}
                            </button>
                         )}
                    </div>
                    {!isEditMode && user.status !== 'pro_max' && <p className="text-white/80">Válaszd ki a listából</p>}
                    {isEditMode && <p className="text-white/80 text-sm">Adj hozzá, törölj vagy módosíts tételeket.</p>}
                </div>
                
                {isEditMode && (
                     <div className="flex justify-between items-center mb-4 p-2 bg-slate-900/30 rounded-lg">
                        <button onClick={() => handleOpenModal(null, Object.keys(menuData)[0] || 'Egyéb')} className="flex items-center gap-2 px-4 py-2 bg-green-600 text-white font-bold rounded-full text-sm">
                            <PlusIcon className="w-5 h-5"/> Új tétel
                        </button>
                        <button onClick={handleSaveMenu} className="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white font-bold rounded-full text-sm">
                            <SaveIcon className="w-5 h-5"/> Változtatások mentése
                        </button>
                     </div>
                )}
                
                {!isEditMode && user.status === 'pro_max' && (
                     <div className="mb-6 bg-slate-900/30 p-4 rounded-lg">
                        <label htmlFor="custom-name" className="block text-white font-semibold mb-2">Fogyasztó neve</label>
                        <div className="flex flex-col sm:flex-row gap-2">
                            <input type="text" id="custom-name" value={customUserName} onChange={(e) => { setCustomUserName(e.target.value); setIsLoggingForSelf(e.target.value === user.name);}} className="w-full bg-slate-700 text-white p-2 rounded-lg" placeholder="Pl. Karbantartó, Vendég..."/>
                            <button type="button" onClick={() => { setCustomUserName(user.name); setIsLoggingForSelf(true);}} className={`px-4 py-2 font-bold rounded-lg transition-colors w-full sm:w-auto ${isLoggingForSelf ? 'bg-orange-600 text-white' : 'bg-slate-600 text-white/80'}`}>Saját magamnak</button>
                        </div>
                    </div>
                )}

                <div className="mb-4 relative">
                    <input type="text" placeholder="Keresés a tételek között..." value={searchTerm} onChange={(e) => setSearchTerm(e.target.value)} className="w-full bg-slate-700 text-white p-2 rounded-lg pl-10"/>
                    <SearchIcon className="w-5 h-5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2"/>
                </div>

                <div className="bg-slate-900/30 rounded-lg overflow-hidden">
                    {isLoadingMenu ? <p className="text-center p-4">Menü betöltése...</p> : Object.keys(filteredMenuData).map((category) => (
                        <AccordionItem key={category} title={category} isOpen={openAccordion === category || !!searchTerm.trim() || isEditMode} onClick={() => handleToggleAccordion(category)}>
                           <div className="space-y-3 max-h-[30vh] overflow-y-auto pr-2">
                                {isEditMode && (
                                    <button onClick={() => handleOpenModal(null, category)} className="text-sm text-green-400 font-semibold flex items-center gap-1"><PlusIcon className="w-4 h-4"/> Új tétel ebben a kategóriában</button>
                                )}
                                {filteredMenuData[category].map(item => (
                                    <div key={item.name} className="flex items-center justify-between p-2 rounded-md hover:bg-white/10 transition-colors">
                                        <div>
                                            <p className="font-semibold text-white">{item.name}</p>
                                            <p className="text-sm text-white/70">{formatCrowns(item.price)} korona</p>
                                        </div>
                                        {isEditMode ? (
                                            <div className="flex items-center gap-2">
                                                <button onClick={() => handleOpenModal(item, category)} className="p-2 text-blue-400 hover:text-blue-300"><PencilIcon className="w-5 h-5"/></button>
                                                <button onClick={() => handleDeleteItem(item, category)} className="p-2 text-red-400 hover:text-red-300"><TrashIcon className="w-5 h-5"/></button>
                                            </div>
                                        ) : item.unit === 'kg' ? (
                                            <div className="flex items-center gap-2">
                                                <input type="number" step="0.01" min="0" value={selectedItems[item.name]?.quantity || ''} onChange={(e) => handleDecimalQuantityChange(item, e.target.value)} className="w-24 bg-slate-800 text-white text-center rounded-md p-1 [appearance:textfield] [&::-webkit-outer-spin-button]:appearance-none [&::-webkit-inner-spin-button]:appearance-none" placeholder="0.00"/>
                                                <span className="font-bold text-white/80 w-4 text-left">kg</span>
                                            </div>
                                        ) : (
                                            <div className="flex items-center gap-2">
                                                <button onClick={() => handleQuantityChange(item, -1)} className="p-1 rounded-full bg-orange-600/80 text-white hover:bg-orange-600 disabled:bg-gray-500" disabled={(selectedItems[item.name]?.quantity || 0) === 0}><MinusIcon className="w-5 h-5"/></button>
                                                <span className="w-8 text-center font-bold text-white text-lg">{selectedItems[item.name]?.quantity || 0}</span>
                                                <button onClick={() => handleQuantityChange(item, 1)} className="p-1 rounded-full bg-orange-600/80 text-white hover:bg-orange-600"><PlusIcon className="w-5 h-5"/></button>
                                            </div>
                                        )}
                                    </div>
                                ))}
                            </div>
                        </AccordionItem>
                    ))}
                </div>
            </div>
            
            {!isEditMode && totalQuantity > 0 && (
                <div className="fixed bottom-4 left-1/2 -translate-x-1/2 w-full max-w-sm z-20 px-4">
                    <div className="bg-slate-900/80 backdrop-blur-md p-3 rounded-2xl shadow-lg flex justify-between items-center animate-fade-in-up">
                        <div>
                            <p className="text-white font-bold">{Object.values(selectedItems).length} tétel</p>
                            <p className="text-amber-400 font-bold text-lg">{formatCrowns(totalPrice)} korona</p>
                        </div>
                        <button onClick={() => setView('summary')} className="px-5 py-3 bg-orange-600 text-white font-bold rounded-full shadow-lg transform hover:scale-105 transition-transform">Összegzés</button>
                    </div>
                </div>
            )}
            
            {isModalOpen && editingItem && (
                 <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex justify-center items-center z-50" onClick={handleCloseModal}>
                    <div className="bg-slate-800 w-full max-w-md rounded-2xl p-6 text-white" onClick={e => e.stopPropagation()}>
                        <h3 className="text-2xl font-bold font-lilita mb-4">{editingItem.isNew ? 'Új tétel' : 'Tétel szerkesztése'}</h3>
                        <div className="space-y-4">
                            <div><label className="font-semibold">Név</label><input type="text" value={modalData.name} onChange={e => setModalData(d => ({...d, name: e.target.value}))} className="w-full bg-slate-700 p-2 rounded mt-1"/></div>
                            <div><label className="font-semibold">Ár</label><input type="number" step="0.01" value={modalData.price} onChange={e => setModalData(d => ({...d, price: e.target.value}))} className="w-full bg-slate-700 p-2 rounded mt-1"/></div>
                            <div>
                                <label className="font-semibold">Mértékegység</label>
                                <div className="flex gap-4 mt-2">
                                    <label className="flex items-center gap-2"><input type="radio" name="unit" value="db" checked={modalData.unit === 'db'} onChange={() => setModalData(d => ({...d, unit: 'db'}))} className="accent-orange-500"/> db</label>
                                    <label className="flex items-center gap-2"><input type="radio" name="unit" value="kg" checked={modalData.unit === 'kg'} onChange={() => setModalData(d => ({...d, unit: 'kg'}))} className="accent-orange-500"/> kg</label>
                                </div>
                            </div>
                        </div>
                        <div className="flex gap-4 mt-6">
                            <button onClick={handleSaveItem} className="flex-1 py-2 bg-green-600 rounded-full font-bold">Mentés</button>
                            <button onClick={handleCloseModal} className="flex-1 py-2 bg-slate-600 rounded-full">Mégse</button>
                        </div>
                    </div>
                 </div>
            )}
        </div>
    );
};

export default MealLoggingPage;