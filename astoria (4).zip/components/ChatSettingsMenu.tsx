import React from 'react';
import BellSlashIcon from './icons/BellSlashIcon';
import GroupChatIcon from './icons/GroupChatIcon';
import SearchIcon from './icons/SearchIcon';
import ImageIcon from './icons/ImageIcon';
import PencilIcon from './icons/PencilIcon';
import EditIcon from './icons/EditIcon';

interface ChatSettingsMenuProps {
    isOpen: boolean;
    onClose: () => void;
    onMute: () => void;
    onViewParticipants: () => void;
    onSearch: () => void;
    onViewMedia: () => void;
    onEditImage: () => void;
    onRename: () => void;
    isGroupChat: boolean;
    canRename: boolean;
}

const ChatSettingsMenu: React.FC<ChatSettingsMenuProps> = ({ isOpen, onClose, onMute, onViewParticipants, onSearch, onViewMedia, onEditImage, onRename, isGroupChat, canRename }) => {
    if (!isOpen) return null;

    return (
        <>
            <div className="fixed inset-0 z-10" onClick={onClose}></div>
            <div className="absolute top-14 right-4 bg-slate-700 rounded-lg shadow-2xl z-20 w-64 animate-fade-in-down p-2">
                <ul className="text-white font-semibold">
                    {isGroupChat && (
                         <li><button onClick={onEditImage} className="w-full flex items-center gap-3 p-3 text-left hover:bg-slate-600 rounded-md"><PencilIcon className="w-5 h-5"/> Kép módosítása</button></li>
                    )}
                    {canRename && (
                        // FIX: The EditIcon component was used without being imported.
                        <li><button onClick={onRename} className="w-full flex items-center gap-3 p-3 text-left hover:bg-slate-600 rounded-md"><EditIcon className="w-5 h-5"/> Csoport átnevezése</button></li>
                    )}
                    <li><button onClick={onMute} className="w-full flex items-center gap-3 p-3 text-left hover:bg-slate-600 rounded-md"><BellSlashIcon className="w-5 h-5"/> Értesítések némítása</button></li>
                    <li><button onClick={onViewParticipants} className="w-full flex items-center gap-3 p-3 text-left hover:bg-slate-600 rounded-md"><GroupChatIcon className="w-5 h-5"/> Résztvevők</button></li>
                    <li><button onClick={onSearch} className="w-full flex items-center gap-3 p-3 text-left hover:bg-slate-600 rounded-md"><SearchIcon className="w-5 h-5"/> Keresés a beszélgetésben</button></li>
                    <li><button onClick={onViewMedia} className="w-full flex items-center gap-3 p-3 text-left hover:bg-slate-600 rounded-md"><ImageIcon className="w-5 h-5"/> Média, fájlok</button></li>
                </ul>
            </div>
        </>
    );
};

export default ChatSettingsMenu;