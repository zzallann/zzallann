import React, { useState } from 'react';
import { authService } from '../services/authService';
import type { User } from '../types';
import AvatarSelector from './AvatarSelector';
import ArrowLeftIcon from './icons/ArrowLeftIcon';

interface RegisterProps {
  onRegisterSuccess: (user: User) => void;
  onSwitchToLogin: () => void;
}

const Register: React.FC<RegisterProps> = ({ onRegisterSuccess, onSwitchToLogin }) => {
  const [identifier, setIdentifier] = useState('');
  const [name, setName] = useState('');
  const [fullName, setFullName] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [selectedAvatar, setSelectedAvatar] = useState<string | null>(null);
  const [error, setError] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [fieldErrors, setFieldErrors] = useState<{ name?: string; password?: string; }>({});
  const [isPendingApproval, setIsPendingApproval] = useState(false);
  
  const handleAvatarSelect = (avatarId: string) => {
    setSelectedAvatar(avatarId);
  }

  const handleNameChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setName(e.target.value);
    if (fieldErrors.name) {
      setFieldErrors(prev => {
        const { name, ...rest } = prev;
        return rest;
      });
    }
  };

  const handlePasswordChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setPassword(e.target.value);
    if (fieldErrors.password) {
      setFieldErrors(prev => {
        const { password, ...rest } = prev;
        return rest;
      });
    }
  };

  const handleNameBlur = async (e: React.FocusEvent<HTMLInputElement>) => {
    const newName = e.target.value.trim();
    if (newName === '') return;
    const isTaken = await authService.isNameTaken(newName);
    if (isTaken) {
      setFieldErrors(prev => ({ ...prev, name: 'Ez a felhasználónév már foglalt.' }));
    }
  };

  const handlePasswordBlur = (e: React.FocusEvent<HTMLInputElement>) => {
    const newPassword = e.target.value;
    if (newPassword.length > 0 && newPassword.length < 6) {
      setFieldErrors(prev => ({ ...prev, password: 'A jelszónak legalább 6 karakter hosszúnak kell lennie.' }));
    }
  };


  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    if (Object.keys(fieldErrors).length > 0) {
        setError('Kérlek javítsd a pirossal jelölt hibákat.');
        return;
    }
    
    if (password.length < 6) {
      setError('A jelszónak legalább 6 karakter hosszúnak kell lennie.');
      setFieldErrors(prev => ({ ...prev, password: 'A jelszónak legalább 6 karakter hosszúnak kell lennie.' }));
      return;
    }
    if (password !== confirmPassword) {
      setError('A két jelszó nem egyezik.');
      return;
    }
    if (!selectedAvatar) {
      setError('Kérlek válassz egy avatart.');
      return;
    }
    
    setIsLoading(true);
    
    try {
        await authService.register(identifier, name, fullName, password, selectedAvatar);
        setIsPendingApproval(true);
    } catch (err: any) {
        if (err.message.includes('felhasználónév már foglalt')) {
            setFieldErrors(prev => ({ ...prev, name: err.message }));
        }
        setError(err.message || 'Ismeretlen hiba történt.');
    } finally {
        setIsLoading(false);
    }
  };

  if (isPendingApproval) {
    return (
        <div className="w-full max-w-sm bg-[var(--component-bg)] backdrop-blur-sm p-8 rounded-2xl shadow-lg animate-fade-in text-center text-[var(--text-primary)]">
            <h2 className="text-2xl font-bold font-lilita mb-4">Sikeres Regisztráció!</h2>
            <p className="text-[var(--text-secondary)]">
                A fiókodat létrehoztuk, de még egy Pro Max felhasználó jóváhagyására van szükség.
                Amint ez megtörtént, be tudsz majd jelentkezni.
            </p>
            <button onClick={onSwitchToLogin} className="mt-6 w-full flex items-center justify-center gap-2 px-4 py-3 bg-orange-600 font-bold rounded-full text-lg shadow-lg">
                <ArrowLeftIcon className="w-6 h-6"/>
                Vissza a bejelentkezéshez
            </button>
        </div>
    );
  }

  return (
    <div className="w-full max-w-sm bg-[var(--component-bg)] backdrop-blur-sm p-8 rounded-2xl shadow-lg animate-fade-in">
      <h2 className="text-3xl font-bold text-[var(--text-primary)] text-center mb-6 font-lilita">Regisztráció</h2>
      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <label htmlFor="reg-identifier" className="block text-[var(--text-primary)] font-semibold mb-1">Azonosító kód</label>
          <input
            type="text"
            id="reg-identifier"
            value={identifier}
            onChange={(e) => setIdentifier(e.target.value)}
            className="w-full px-4 py-2 bg-[var(--input-bg)] text-[var(--text-primary)] border-2 border-transparent rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500 focus:border-transparent transition"
            required
            disabled={isLoading}
          />
        </div>
        <div>
          <label htmlFor="reg-name" className="block text-[var(--text-primary)] font-semibold mb-1">Becenév</label>
          <input
            type="text"
            id="reg-name"
            value={name}
            onChange={handleNameChange}
            onBlur={handleNameBlur}
            className={`w-full px-4 py-2 bg-[var(--input-bg)] text-[var(--text-primary)] border-2 rounded-lg focus:outline-none focus:ring-2 transition ${fieldErrors.name ? 'border-red-500 focus:ring-red-500' : 'border-transparent focus:ring-orange-500 focus:border-transparent'}`}
            required
            disabled={isLoading}
          />
          {fieldErrors.name && <p className="text-red-400 text-sm mt-1">{fieldErrors.name}</p>}
        </div>
         <div>
          <label htmlFor="reg-fullname" className="block text-[var(--text-primary)] font-semibold mb-1">Teljes Név</label>
          <input
            type="text"
            id="reg-fullname"
            value={fullName}
            onChange={(e) => setFullName(e.target.value)}
            className="w-full px-4 py-2 bg-[var(--input-bg)] text-[var(--text-primary)] border-2 border-transparent rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500 focus:border-transparent transition"
            required
            disabled={isLoading}
          />
        </div>
        <div>
          <label htmlFor="reg-password" className="block text-[var(--text-primary)] font-semibold mb-1">Jelszó</label>
          <input
            type="password"
            id="reg-password"
            value={password}
            onChange={handlePasswordChange}
            onBlur={handlePasswordBlur}
            className={`w-full px-4 py-2 bg-[var(--input-bg)] text-[var(--text-primary)] border-2 rounded-lg focus:outline-none focus:ring-2 transition ${fieldErrors.password ? 'border-red-500 focus:ring-red-500' : 'border-transparent focus:ring-orange-500 focus:border-transparent'}`}
            required
            disabled={isLoading}
          />
          {fieldErrors.password && <p className="text-red-400 text-sm mt-1">{fieldErrors.password}</p>}
        </div>
        <div>
          <label htmlFor="confirm-password" className="block text-[var(--text-primary)] font-semibold mb-1">Jelszó megerősítése</label>
          <input
            type="password"
            id="confirm-password"
            value={confirmPassword}
            onChange={(e) => setConfirmPassword(e.target.value)}
            className="w-full px-4 py-2 bg-[var(--input-bg)] text-[var(--text-primary)] border-2 border-transparent rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500 focus:border-transparent transition"
            required
            disabled={isLoading}
          />
        </div>
        
        <AvatarSelector 
            selectedAvatar={selectedAvatar} 
            onSelectAvatar={handleAvatarSelect} 
            exclude={['police-bear', 'zebra']}
            avatarSet="default"
        />

        {error && <p className="text-orange-300 text-sm text-center bg-orange-800/50 p-2 rounded-lg">{error}</p>}
        
        <button
          type="submit"
          disabled={isLoading}
          className="w-full mt-4 px-4 py-3 bg-orange-600 text-white font-bold rounded-full text-lg shadow-lg transform hover:scale-105 transition-transform duration-200 disabled:bg-orange-400 disabled:scale-100 disabled:cursor-not-allowed"
        >
          {isLoading ? 'Folyamatban...' : 'Regisztráció'}
        </button>
      </form>
      <p className="text-center text-[var(--text-primary)] mt-6">
        Már van fiókod?{' '}
        <button onClick={onSwitchToLogin} className="font-bold hover:underline" disabled={isLoading}>
          Jelentkezz be!
        </button>
      </p>
    </div>
  );
};

export default Register;