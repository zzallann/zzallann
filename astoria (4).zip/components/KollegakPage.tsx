import React, { useState, useEffect, useMemo } from 'react';
import type { User } from '../types';
import { authService } from '../services/authService';
import { messageService } from '../services/messageService';
import { useNotification } from '../contexts/NotificationContext';
import UserStatusBadge from './UserStatusBadge';
import PasswordResetModal from './PasswordResetModal';
import KeyIcon from './icons/KeyIcon';
import WarningIcon from './icons/WarningIcon';
import DeleteConfirmationModal from './DeleteConfirmationModal';
import MinusIcon from './icons/MinusIcon';
import UserAvatarWithStatus from './UserAvatarWithStatus';
import SearchIcon from './icons/SearchIcon';
import XCircleIcon from './icons/XCircleIcon';
import CheckCircleIcon from './icons/CheckCircleIcon';
import CrownTransferModal from './CrownTransferModal';
import GiftIcon from './icons/GiftIcon';
import TrashIcon from './icons/TrashIcon';


interface KollegakPageProps {
    currentUser: User;
    onUserUpdate: (user: User) => void;
    onStartChat: (userId: string) => void;
}

const timeSince = (timestamp: number): string => {
    const seconds = Math.floor((Date.now() - timestamp) / 1000);
    if (seconds < 60) return "épp most";
    const minutes = Math.floor(seconds / 60);
    if (minutes < 60) return `${minutes} perce`;
    const hours = Math.floor(minutes / 60);
    if (hours < 24) return `${hours} órája`;
    const days = Math.floor(hours / 24);
    return `${days} napja`;
};

const KollegakPage: React.FC<KollegakPageProps> = ({ currentUser, onUserUpdate, onStartChat }) => {
    const [allUsers, setAllUsers] = useState<User[]>([]);
    const [isLoading, setIsLoading] = useState(true);
    const [selectedUserForPasswordReset, setSelectedUserForPasswordReset] = useState<User | null>(null);
    const [selectedUserForCrownTransfer, setSelectedUserForCrownTransfer] = useState<User | null>(null);
    const [confirmation, setConfirmation] = useState<{ user: User, action: 'warn' | 'strike' | 'remove_strike' } | null>(null);
    const [userToDelete, setUserToDelete] = useState<User | null>(null);
    const [searchTerm, setSearchTerm] = useState('');
    const { addNotification } = useNotification();

    const fetchUsers = () => {
        try {
            const users = authService.getAllUsers().filter(u => u.status !== 'admin');
            const sortedUsers = users.sort((a, b) => {
                const statusOrder = { 'pro_max': 0, 'pro': 1, 'normal': 2 };
                const statusA = a.status || 'normal';
                const statusB = b.status || 'normal';
                if (statusOrder[statusA] !== statusOrder[statusB]) {
                    return statusOrder[statusA] - statusOrder[statusB];
                }
                return a.name.localeCompare(b.name);
            });
            setAllUsers(sortedUsers);
        } catch (error) {
            console.error("Failed to load users", error);
        } finally {
            setIsLoading(false);
        }
    };
    
    useEffect(() => {
        fetchUsers();
    }, []);
    
    const pendingUsers = useMemo(() => allUsers.filter(u => !u.approved), [allUsers]);
    const approvedUsers = useMemo(() => allUsers.filter(u => u.approved && u.id !== currentUser.id), [allUsers, currentUser.id]);

    const filteredUsers = useMemo(() => {
        if (!searchTerm.trim()) {
            return approvedUsers;
        }
        const lowerCaseSearchTerm = searchTerm.toLowerCase();
        return approvedUsers.filter(user => {
            const nameMatch = user.name.toLowerCase().includes(lowerCaseSearchTerm) || user.fullName.toLowerCase().includes(lowerCaseSearchTerm);
            if (currentUser.status === 'pro_max' || currentUser.status === 'admin') {
                const idMatch = user.identifier.toLowerCase().includes(lowerCaseSearchTerm);
                return nameMatch || idMatch;
            }
            return nameMatch;
        });
    }, [searchTerm, approvedUsers, currentUser.status]);

    const handleConfirmAction = async () => {
        if (!confirmation) return;
        
        const { user: targetUser, action } = confirmation;
        let updatedUser = { ...targetUser };
        let successMessage = '';
        
        try {
            if (action === 'warn') {
                await messageService.sendLatenessNotification(targetUser.id, currentUser.name, 'warning');
                successMessage = `Figyelmeztetés elküldve ${targetUser.name} számára.`;
            } else if (action === 'strike') {
                updatedUser.strikes = (updatedUser.strikes || 0) + 1;
                updatedUser.points = Math.max(0, updatedUser.points - 100);
                if (updatedUser.pointsHistory) {
                    updatedUser.pointsHistory.unshift({ reason: 'Strigula késésért', points: -100, date: Date.now() });
                }
                authService.updateUser(updatedUser);
                await messageService.sendLatenessNotification(targetUser.id, currentUser.name, 'strike', updatedUser.strikes);
                successMessage = `Strigula rögzítve ${targetUser.name} számára. 100 korona levonva.`;
            } else if (action === 'remove_strike') {
                if (updatedUser.strikes > 0) {
                    updatedUser = await authService.removeStrike(targetUser.id);
                    await messageService.sendStrikeRemovalNotification(targetUser.id, currentUser.name, updatedUser.strikes);
                    successMessage = `Strigula eltávolítva ${targetUser.name} számára.`;
                } else {
                    addNotification(`${targetUser.name} felhasználónak nincs strigulája.`, 'info');
                    setConfirmation(null);
                    return;
                }
            }
            
            addNotification(successMessage, 'success');
            setAllUsers(allUsers.map(u => u.id === targetUser.id ? updatedUser : u));

        } catch (error) {
            addNotification('Hiba történt a művelet során.', 'error');
        } finally {
            setConfirmation(null);
        }
    };
    
    const handleApprove = async (userId: string) => {
        try {
            await authService.approveUser(userId);
            addNotification("Felhasználó jóváhagyva.", "success");
            fetchUsers();
        } catch (error) {
            addNotification("Hiba a jóváhagyás során.", "error");
        }
    };

    const handleReject = async (userId: string) => {
        try {
            await authService.rejectUser(userId);
            addNotification("Regisztráció elutasítva és törölve.", "success");
            fetchUsers();
        } catch (error) {
            addNotification("Hiba az elutasítás során.", "error");
        }
    };

    const handleTransferSuccess = (updatedSender: User, updatedRecipient: User) => {
        setAllUsers(prevUsers => prevUsers.map(u => {
            if (u.id === updatedSender.id) return updatedSender;
            if (u.id === updatedRecipient.id) return updatedRecipient;
            return u;
        }));
        if (currentUser.id === updatedSender.id) {
            onUserUpdate(updatedSender);
        }
    };

    const handleDeleteUser = async () => {
        if (!userToDelete) return;
        try {
            await authService.deleteUser(userToDelete.id);
            addNotification(`${userToDelete.name} felhasználó sikeresen törölve.`, 'success');
            fetchUsers(); // Refresh the list
        } catch (error: any) {
            addNotification(error.message || 'Hiba a törlés során.', 'error');
        } finally {
            setUserToDelete(null);
        }
    };


    if (isLoading) {
        return <div className="text-center text-[var(--text-primary)]">Kollégák listájának betöltése...</div>;
    }
    
    const canManage = ['pro_max', 'admin'].includes(currentUser.status || 'normal');
    const pageTitle = canManage ? 'Csapatlista' : 'Kollégák';

    return (
        <>
            <div className="w-full max-w-2xl mx-auto animate-fade-in space-y-6">
                <h1 className="text-3xl sm:text-4xl font-bold font-lilita tracking-wide text-center text-[var(--text-primary)]">{pageTitle}</h1>
                 
                {canManage && pendingUsers.length > 0 && (
                    <div className="bg-yellow-800/40 backdrop-blur-sm p-4 rounded-2xl space-y-3">
                        <h2 className="text-xl font-bold font-lilita text-yellow-300">Jóváhagyásra váró regisztrációk</h2>
                        {pendingUsers.map(user => (
                            <div key={user.id} className="bg-[var(--component-bg)] p-3 rounded-lg flex flex-col sm:flex-row items-center gap-3">
                                <div className="flex-1 text-center sm:text-left">
                                    <p className="font-bold text-white">{user.name} ({user.identifier})</p>
                                    <p className="text-sm text-white/70">{user.fullName}</p>
                                </div>
                                <div className="flex gap-2">
                                    <button onClick={() => handleApprove(user.id)} className="flex items-center gap-1 px-3 py-1 bg-green-600 text-white font-bold text-sm rounded-full"><CheckCircleIcon className="w-4 h-4"/> Elfogad</button>
                                    <button onClick={() => handleReject(user.id)} className="flex items-center gap-1 px-3 py-1 bg-red-600 text-white font-bold text-sm rounded-full"><XCircleIcon className="w-4 h-4"/> Elutasít</button>
                                </div>
                            </div>
                        ))}
                    </div>
                )}
                 
                 <div className="relative">
                    <span className="absolute left-4 top-1/2 -translate-y-1/2"><SearchIcon className="w-5 h-5 text-slate-400"/></span>
                    <input
                        type="text"
                        placeholder={canManage ? "Keresés név vagy azonosító alapján..." : "Keresés név alapján..."}
                        value={searchTerm}
                        onChange={(e) => setSearchTerm(e.target.value)}
                        className="w-full bg-[var(--component-bg)] backdrop-blur-sm text-white pl-12 pr-10 py-3 rounded-full text-sm focus:ring-2 focus:ring-orange-500 outline-none"
                    />
                    {searchTerm && (
                        <button onClick={() => setSearchTerm('')} className="absolute right-3 top-1/2 -translate-y-1/2 p-1">
                            <XCircleIcon className="w-5 h-5 text-slate-400" />
                        </button>
                    )}
                </div>

                <div className="space-y-3">
                    {filteredUsers.length > 0 ? filteredUsers.map(user => {
                        return (
                            <div key={user.id} className="bg-[var(--component-bg)] backdrop-blur-sm p-4 rounded-2xl flex flex-col sm:flex-row items-center gap-4">
                                <div className="flex items-center gap-4 flex-1">
                                    <UserAvatarWithStatus user={user} size="medium" />
                                    <div className="text-[var(--text-primary)]">
                                        <p className="font-bold flex items-center">{user.name} <UserStatusBadge user={user} /></p>
                                        <p className="text-sm text-white/80 -mt-1">{user.fullName}</p>
                                        {user.status !== 'pro_max' && (
                                            <p className="text-xs text-[var(--text-secondary)] mt-1">
                                                Utoljára aktív: {timeSince(user.lastSeen)} | Strigulák: <span className={user.strikes > 0 ? "text-red-400 font-bold" : ""}>{user.strikes}</span>
                                            </p>
                                        )}
                                    </div>
                                </div>
                                <div className="flex items-center gap-2 w-full sm:w-auto">
                                    <button onClick={() => onStartChat(user.id)} className="flex-1 sm:flex-none px-4 py-2 bg-orange-600 text-white font-bold text-sm rounded-full shadow-lg transform hover:scale-105 transition-transform">
                                        Üzenet
                                    </button>
                                    {canManage && (
                                        <>
                                            <button onClick={() => setSelectedUserForCrownTransfer(user)} title="Korona küldése" className="p-2 bg-yellow-600/50 text-yellow-300 rounded-full hover:bg-yellow-500/50 transform hover:scale-105">
                                                <GiftIcon className="w-5 h-5"/>
                                            </button>
                                            <button onClick={() => setSelectedUserForPasswordReset(user)} title="Jelszó módosítása" className="p-2 bg-blue-600/50 text-blue-300 rounded-full hover:bg-blue-500/50 transform hover:scale-105"><KeyIcon className="w-5 h-5"/></button>
                                            {user.status !== 'pro_max' && (
                                                <>
                                                    <button onClick={() => setConfirmation({ user, action: 'warn' })} title="Figyelmeztetés késésért" className="p-2 bg-yellow-600/50 text-yellow-300 rounded-full hover:bg-yellow-500/50 transform hover:scale-105"><WarningIcon className="w-5 h-5"/></button>
                                                    <button onClick={() => setConfirmation({ user, action: 'strike' })} title="Strigula adása késésért" className="p-2 bg-red-600/50 text-red-300 rounded-full hover:bg-red-500/50 transform hover:scale-105"><WarningIcon className="w-5 h-5"/></button>
                                                    <button onClick={() => setConfirmation({ user, action: 'remove_strike' })} title="Strigula eltávolítása" className="p-2 bg-green-600/50 text-green-300 rounded-full hover:bg-green-500/50 transform hover:scale-105"><MinusIcon className="w-5 h-5"/></button>
                                                </>
                                            )}
                                            <button onClick={() => setUserToDelete(user)} title="Felhasználó törlése" className="p-2 bg-red-800/60 text-red-400 rounded-full hover:bg-red-700/60 transform hover:scale-105">
                                                <TrashIcon className="w-5 h-5"/>
                                            </button>
                                        </>
                                    )}
                                </div>
                            </div>
                        )
                    }) : (
                        <p className="text-center text-[var(--text-secondary)] py-8">Nincs a keresésnek megfelelő felhasználó.</p>
                    )}
                </div>
            </div>
            {selectedUserForPasswordReset && (
                <PasswordResetModal user={selectedUserForPasswordReset} onClose={() => setSelectedUserForPasswordReset(null)} />
            )}
            {selectedUserForCrownTransfer && (
                <CrownTransferModal
                    isOpen={!!selectedUserForCrownTransfer}
                    onClose={() => setSelectedUserForCrownTransfer(null)}
                    sender={currentUser}
                    recipient={selectedUserForCrownTransfer}
                    onTransferSuccess={handleTransferSuccess}
                />
            )}
            {userToDelete && (
                <DeleteConfirmationModal
                    isOpen={!!userToDelete}
                    onClose={() => setUserToDelete(null)}
                    onConfirm={handleDeleteUser}
                    title="Felhasználó Törlése"
                    message={`Biztosan törölni szeretnéd ${userToDelete.name} felhasználót? Minden adata véglegesen törlődik.`}
                    confirmText="Igen, Törlöm"
                    confirmButtonClass="bg-red-600"
                />
            )}
            {confirmation && (
                <DeleteConfirmationModal
                    isOpen={!!confirmation}
                    onClose={() => setConfirmation(null)}
                    onConfirm={handleConfirmAction}
                    title={
                        confirmation.action === 'warn' ? 'Figyelmeztetés' :
                        confirmation.action === 'strike' ? 'Strigula' : 'Strigula Eltávolítása'
                    }
                    message={
                        confirmation.action === 'warn' ? `Biztosan figyelmeztetést küldesz ${confirmation.user.name} számára késés miatt?` :
                        confirmation.action === 'strike' ? `Biztosan strigulát adsz ${confirmation.user.name} számára késésért?` :
                        `Biztosan eltávolítasz egy strigulát ${confirmation.user.name} számára?`
                    }
                    confirmText="Igen, biztosan"
                    cancelText="Nem"
                    confirmButtonClass={
                         confirmation.action === 'warn' ? 'bg-yellow-600' :
                         confirmation.action === 'strike' ? 'bg-red-600' : 'bg-green-600'
                    }
                />
            )}
        </>
    );
};

export default KollegakPage;