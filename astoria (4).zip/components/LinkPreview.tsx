import React, { useEffect, useState } from 'react';

interface LinkPreviewProps {
  url: string;
}

const getYoutubeVideoId = (url: string): string | null => {
  const regex = /(?:https?:\/\/)?(?:www\.)?(?:youtube\.com\/(?:[^\/\n\s]+\/\S+\/|(?:v|e(?:mbed)?)\/|\S*?[?&]v=)|youtu\.be\/)([a-zA-Z0-9_-]{11})/;
  const match = url.match(regex);
  return match ? match[1] : null;
};

// TikTok's oEmbed endpoint needs the full URL. We just need to verify it's a TikTok video URL.
const getIsTiktokUrl = (url: string): boolean => {
  const regex = /(?:https?:\/\/)?(?:www\.)?tiktok\.com\/[@a-zA-Z0-9_.-]+\/video\/(\d+)/;
  return regex.test(url);
};

// A simple loading skeleton component
const PreviewSkeleton: React.FC = () => (
    <div className="aspect-video w-full max-w-xl mx-auto rounded-lg bg-slate-700 animate-pulse flex items-center justify-center">
        <span className="text-white/50 text-sm">Előkép betöltése...</span>
    </div>
);


const LinkPreview: React.FC<LinkPreviewProps> = ({ url }) => {
  const youtubeVideoId = getYoutubeVideoId(url);
  const isTiktok = getIsTiktokUrl(url);

  const [tiktokThumbnail, setTiktokThumbnail] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);

  useEffect(() => {
    // Reset state when URL changes
    setTiktokThumbnail(null);
    
    if (isTiktok) {
      const fetchTiktokThumbnail = async () => {
        setIsLoading(true);
        try {
          // IMPORTANT: TikTok's oEmbed API is subject to CORS restrictions and may not work
          // when called directly from a browser. The professional solution is to use a
          // backend proxy server to make this request. This is a best-effort attempt.
          const response = await fetch(`https://www.tiktok.com/oembed?url=${encodeURIComponent(url)}`);
          if (!response.ok) {
            throw new Error(`Network response was not ok (${response.status})`);
          }
          const data = await response.json();
          setTiktokThumbnail(data.thumbnail_url);
        } catch (error) {
          console.error("Hiba a TikTok előnézet betöltésekor:", error);
          // Gracefully fail by not setting a thumbnail
        } finally {
          setIsLoading(false);
        }
      };
      fetchTiktokThumbnail();
    }
  }, [url, isTiktok]);

  if (youtubeVideoId) {
    const thumbnailUrl = `https://img.youtube.com/vi/${youtubeVideoId}/hqdefault.jpg`;
    return (
      <a
        href={url}
        target="_blank"
        rel="noopener noreferrer"
        className="block aspect-video w-full max-w-xl mx-auto rounded-lg overflow-hidden shadow-lg relative group bg-black"
      >
        <img
          src={thumbnailUrl}
          alt="YouTube előkép"
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-black/40 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity duration-300">
          <svg xmlns="http://www.w3.org/2000/svg" className="h-16 w-16 text-white" viewBox="0 0 20 20" fill="currentColor">
            <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM9.555 7.168A1 1 0 008 8v4a1 1 0 001.555.832l3-2a1 1 0 000-1.664l-3-2z" clipRule="evenodd" />
          </svg>
        </div>
      </a>
    );
  }

  if (isTiktok) {
    if (isLoading) {
      return <PreviewSkeleton />;
    }
    if (tiktokThumbnail) {
      return (
        <a
            href={url}
            target="_blank"
            rel="noopener noreferrer"
            className="block aspect-video w-full max-w-xl mx-auto rounded-lg overflow-hidden shadow-lg relative group bg-black"
        >
            <img
            src={tiktokThumbnail}
            alt="TikTok előkép"
            className="w-full h-full object-cover"
            />
            <div className="absolute inset-0 bg-black/40 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                 <svg xmlns="http://www.w3.org/2000/svg" className="h-16 w-16 text-white" viewBox="0 0 20 20" fill="currentColor">
                    <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM9.555 7.168A1 1 0 008 8v4a1 1 0 001.555.832l3-2a1 1 0 000-1.664l-3-2z" clipRule="evenodd" />
                </svg>
            </div>
        </a>
      );
    }
    // If loading is finished and there's no thumbnail (due to fetch error), return null
    return null;
  }

  return null;
};

export default LinkPreview;
