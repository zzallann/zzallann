import React, { useState } from 'react';
import type { User } from '../types';
import { authService } from '../services/authService';
import { messageService } from '../services/messageService';
import { useNotification } from '../contexts/NotificationContext';
import SendIcon from './icons/SendIcon';

interface CrownTransferModalProps {
    isOpen: boolean;
    onClose: () => void;
    sender: User;
    recipient: User;
    onTransferSuccess: (updatedSender: User, updatedRecipient: User) => void;
}

const formatCrowns = (points: number): string => {
    const roundedUp = Math.ceil(points * 100) / 100;
    return roundedUp.toLocaleString('hu-HU', {
        minimumFractionDigits: 2,
        maximumFractionDigits: 2,
    });
};

const CrownTransferModal: React.FC<CrownTransferModalProps> = ({ isOpen, onClose, sender, recipient, onTransferSuccess }) => {
    const [amount, setAmount] = useState('');
    const [reason, setReason] = useState('');
    const [isLoading, setIsLoading] = useState(false);
    const { addNotification } = useNotification();

    const handleAmountChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        const value = e.target.value;
        if (/^\d*$/.test(value)) { // only allow digits
            let numValue = parseInt(value, 10);
            if (numValue > sender.points) {
                numValue = Math.floor(sender.points);
            }
            if (numValue > 10000) {
                 numValue = 10000;
            }
            setAmount(numValue ? String(numValue) : '');
        }
    };

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        const transferAmount = parseInt(amount, 10);
        if (!transferAmount || transferAmount <= 0) {
            addNotification('Adj meg egy érvényes, pozitív összeget.', 'error');
            return;
        }
        if (!reason.trim()) {
            addNotification('Az indoklás megadása kötelező.', 'error');
            return;
        }

        setIsLoading(true);
        try {
            const { sender: updatedSender, recipient: updatedRecipient } = await authService.transferCrowns(sender.id, recipient.id, transferAmount, reason);
            await messageService.sendCrownTransferNotification(recipient.id, sender.name, transferAmount, reason);
            
            addNotification(`${transferAmount.toLocaleString('hu-HU')} korona sikeresen elküldve ${recipient.name} számára.`, 'success');
            onTransferSuccess(updatedSender, updatedRecipient);
            onClose();

        } catch (err: any) {
            addNotification(err.message || 'Hiba történt.', 'error');
        } finally {
            setIsLoading(false);
        }
    };
    
    if (!isOpen) return null;

    return (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex justify-center items-center z-50 animate-fade-in" onClick={onClose}>
            <div className="bg-slate-800 w-full max-w-sm rounded-2xl shadow-2xl p-6 text-white" onClick={e => e.stopPropagation()}>
                <h3 className="text-2xl font-bold font-lilita mb-4 text-center">Korona Küldése</h3>
                <p className="text-center mb-1">Címzett: <span className="font-bold">{recipient.name}</span></p>
                 <p className="text-center text-sm text-white/70 mb-4">Saját egyenleged: <span className="font-bold text-amber-400">{formatCrowns(sender.points)} korona</span></p>

                <form onSubmit={handleSubmit} className="space-y-4">
                    <div>
                        <label htmlFor="crown-amount" className="block text-white font-semibold mb-1">Küldendő összeg (max 10,000)</label>
                        <input
                            type="text"
                            pattern="\d*"
                            id="crown-amount"
                            value={amount}
                            onChange={handleAmountChange}
                            placeholder="Pl. 500"
                            className="w-full px-4 py-2 bg-slate-700 text-white border-2 border-transparent rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500"
                            autoFocus
                            required
                        />
                    </div>
                     <div>
                        <label htmlFor="crown-reason" className="block text-white font-semibold mb-1">Indoklás</label>
                        <textarea
                            id="crown-reason"
                            value={reason}
                            onChange={(e) => setReason(e.target.value)}
                            placeholder="Pl. Születésnapi ajándék, jutalom, stb."
                            className="w-full px-4 py-2 bg-slate-700 text-white border-2 border-transparent rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500 resize-none"
                            rows={2}
                            required
                        />
                    </div>
                    <button
                        type="submit"
                        disabled={isLoading}
                        className="w-full mt-4 flex items-center justify-center gap-2 px-4 py-3 bg-green-600 font-bold rounded-full text-lg shadow-lg transform hover:scale-105 transition-transform disabled:bg-green-400 disabled:scale-100"
                    >
                        <SendIcon className="w-5 h-5" />
                        <span>{isLoading ? 'Küldés...' : 'Küldés'}</span>
                    </button>
                    <button
                        type="button"
                        onClick={onClose}
                        className="w-full px-4 py-2 bg-slate-600/50 text-white/80 font-semibold rounded-full shadow-lg transform hover:scale-105 transition-transform"
                    >
                        Mégse
                    </button>
                </form>
            </div>
        </div>
    );
};

export default CrownTransferModal;
