import React, { useState, useEffect, useCallback } from 'react';
import type { GameState, GamePlayer, User } from '../types';
import { gameService } from '../services/gameService';
import GameBoard from './game/GameBoard';
import PlayerProfileModal from './game/PlayerProfileModal';
import DiceIcon from './icons/DiceIcon';
import { avatars } from './AvatarSelector';

interface GamePageProps {
    user: User;
}

const GamePage: React.FC<GamePageProps> = ({ user }) => {
    const [gameState, setGameState] = useState<GameState | null>(null);
    const [isLoading, setIsLoading] = useState(true);
    const [error, setError] = useState('');
    const [isRolling, setIsRolling] = useState(false);
    const [selectedPlayer, setSelectedPlayer] = useState<GamePlayer | null>(null);

    const fetchGameState = useCallback(async () => {
        try {
            const state = await gameService.getGameState(user);
            setGameState(state);
        } catch (err: any) {
            setError(err.message || 'Hiba a játék állapotának betöltésekor.');
        } finally {
            setIsLoading(false);
        }
    }, [user]);

    useEffect(() => {
        fetchGameState();
    }, [fetchGameState]);

    const handleRollDice = async () => {
        if (!gameState || gameState.diceValue !== null) return;
        setIsRolling(true);
        try {
            const newState = await gameService.rollDice();
            setGameState(newState);
        } catch (err: any) {
            setError(err.message);
        } finally {
            setIsRolling(false);
        }
    };
    
    const handlePieceClick = async (pieceId: number) => {
        if (isRolling) return;
        try {
            const newState = await gameService.movePiece(pieceId);
            setGameState(newState);
        } catch(err: any) {
            // Update state with error message from service
            if (gameState) {
                setGameState({...gameState, message: err.message});
            }
        }
    };

    if (isLoading) {
        return <div className="text-white text-center">Játék betöltése...</div>;
    }
    
    if (error) {
        return <div className="text-orange-300 text-center bg-orange-800/50 p-3 rounded-lg">{error}</div>;
    }

    if (!gameState) {
        return <div className="text-white text-center">Nem sikerült betölteni a játékot.</div>;
    }

    const currentPlayer = gameState.players[gameState.currentPlayerIndex];
    const isMyTurn = currentPlayer.user.id === user.id;

    return (
        <div className="w-full flex flex-col items-center gap-4 animate-fade-in">
            <h1 className="text-3xl sm:text-4xl font-bold text-white font-lilita tracking-wide">Ki nevet a végén?</h1>

            <div className="flex flex-wrap justify-center gap-2 sm:gap-4 mb-2">
                {gameState.players.map((player, index) => {
                    const playerAvatar = avatars.find(a => a.id === player.user.avatarId);
                    const isCurrent = index === gameState.currentPlayerIndex;
                    return (
                        <button key={player.user.id} onClick={() => setSelectedPlayer(player)} className={`flex items-center gap-2 p-2 rounded-lg transition-all ${isCurrent ? 'bg-orange-500/50 ring-2 ring-orange-400' : 'bg-white/10'}`}>
                           <div className="w-8 h-8 rounded-full overflow-hidden bg-slate-700">
                                {player.user.uploadedImage ? <img src={player.user.uploadedImage} alt="Avatar" className="w-full h-full object-cover" /> : playerAvatar ? <playerAvatar.component /> : null}
                           </div>
                           <span className="text-white font-semibold text-sm">{player.user.name}</span>
                        </button>
                    )
                })}
            </div>

            <GameBoard gameState={gameState} onPieceClick={handlePieceClick} currentUserId={user.id} />

            <div className="bg-white/10 dark:bg-slate-800/30 backdrop-blur-sm p-4 rounded-2xl w-full max-w-md text-center">
                <p className="text-white/80 h-10 flex items-center justify-center">{gameState.message}</p>
                {gameState.status === 'playing' && isMyTurn && (
                    <button 
                        onClick={handleRollDice} 
                        disabled={isRolling || gameState.diceValue !== null}
                        className="mt-2 w-full flex justify-center items-center gap-2 px-4 py-3 bg-orange-600 text-white font-bold rounded-full text-lg shadow-lg transform hover:scale-105 transition-transform duration-200 disabled:bg-orange-400 disabled:scale-100 disabled:cursor-not-allowed"
                    >
                        <DiceIcon className="w-6 h-6" />
                        <span>{isRolling ? 'Dobás...' : 'Kockadobás'}</span>
                    </button>
                )}
                 {gameState.status === 'finished' && (
                     <button 
                        onClick={() => fetchGameState()} 
                        className="mt-2 w-full px-4 py-3 bg-green-600 text-white font-bold rounded-full text-lg shadow-lg transform hover:scale-105 transition-transform duration-200"
                    >
                       Új Játék
                    </button>
                )}
            </div>
            
            {selectedPlayer && <PlayerProfileModal player={selectedPlayer} onClose={() => setSelectedPlayer(null)} />}
        </div>
    );
};

export default GamePage;
