import React from 'react';
import { useTheme } from '../contexts/ThemeContext';

interface AppearanceModalProps {
    onClose: () => void;
}

const AppearanceModal: React.FC<AppearanceModalProps> = ({ onClose }) => {
    const { theme, setTheme } = useTheme();

    return (
         <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex justify-center items-center z-50 animate-fade-in" onClick={onClose}>
            <div className="bg-[var(--component-bg)] backdrop-blur-md w-full max-w-sm rounded-2xl shadow-2xl p-6 text-[var(--text-primary)] transition-colors duration-300" onClick={e => e.stopPropagation()}>
                <h3 className="text-2xl font-bold font-lilita mb-4 text-center">Téma kiválasztása</h3>
                
                <div className="space-y-3">
                    <button
                        onClick={() => setTheme('blue')}
                        className={`w-full p-4 font-bold rounded-lg border-2 transition-colors ${theme === 'blue' ? 'bg-orange-500 border-orange-400 text-white' : 'bg-[var(--input-bg)] border-transparent hover:border-orange-500'}`}
                    >
                        Kék Téma
                    </button>
                    <button
                        onClick={() => setTheme('pink')}
                        className={`w-full p-4 font-bold rounded-lg border-2 transition-colors ${theme === 'pink' ? 'bg-orange-500 border-orange-400 text-white' : 'bg-[var(--input-bg)] border-transparent hover:border-orange-500'}`}
                    >
                        Rózsaszín Téma
                    </button>
                    <button
                        onClick={() => setTheme('green')}
                        className={`w-full p-4 font-bold rounded-lg border-2 transition-colors ${theme === 'green' ? 'bg-orange-500 border-orange-400 text-white' : 'bg-[var(--input-bg)] border-transparent hover:border-orange-500'}`}
                    >
                        Zöld Téma
                    </button>
                    <button
                        onClick={() => setTheme('horizon')}
                        className={`w-full p-4 font-bold rounded-lg border-2 transition-colors ${theme === 'horizon' ? 'bg-orange-500 border-orange-400 text-white' : 'bg-[var(--input-bg)] border-transparent hover:border-orange-500'}`}
                    >
                        Horizon
                    </button>
                    <button
                        onClick={() => setTheme('christmas')}
                        className={`w-full p-4 font-bold rounded-lg border-2 transition-colors ${theme === 'christmas' ? 'bg-orange-500 border-orange-400 text-white' : 'bg-[var(--input-bg)] border-transparent hover:border-orange-500'}`}
                    >
                        Karácsonyi Téma
                    </button>
                </div>

                <button 
                    onClick={onClose} 
                    className="mt-6 w-full px-4 py-2 bg-slate-600/50 text-[var(--text-primary)] font-bold rounded-full text-lg shadow-lg transform hover:scale-105 transition-transform duration-200"
                >
                    Bezárás
                </button>
            </div>
        </div>
    );
};

export default AppearanceModal;