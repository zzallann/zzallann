import React, { useState, useRef } from 'react';
import type { User } from '../types';
import { authService } from '../services/authService';
import { messageService } from '../services/messageService';
import { useNotification } from '../contexts/NotificationContext';
import AvatarSelector from './AvatarSelector';
import { useTheme } from '../contexts/ThemeContext';
import type { Theme } from '../contexts/ThemeContext';
import EditIcon from './icons/EditIcon';
import CheckIcon from './icons/CheckIcon';
import XCircleIcon from './icons/XCircleIcon';
import ProfileImageEditorModal from './ProfileImageEditorModal';

interface SettingsPageProps {
    user: User;
    onUserUpdate: (user: User) => void;
}

const themeOptions: { id: Theme; name: string; style: React.CSSProperties }[] = [
    { id: 'blue', name: 'Bálna', style: { background: 'radial-gradient(ellipse at center, #265599, #091325)' } },
    { id: 'pink', name: 'Ibolya', style: { background: 'radial-gradient(ellipse at center, #d03d8d, #4d183d)' } },
    { id: 'green', name: 'Rét', style: { background: 'radial-gradient(ellipse at center, #5a8c5a, #1a331a)' } },
    { id: 'horizon', name: 'Horizon', style: { background: 'linear-gradient(135deg, #4c004c, #004c4c)' } },
    { id: 'christmas', name: 'Karácsony', style: { background: 'radial-gradient(ellipse at bottom, #2d5a37, #7f1d1d)' } },
    { id: 'dark9', name: 'Dark9', style: { background: '#111111', border: '2px solid #e53935' } }
];

const formatCrowns = (points: number): string => {
    const roundedUp = Math.ceil(points * 100) / 100;
    return roundedUp.toLocaleString('hu-HU', {
        minimumFractionDigits: 2,
        maximumFractionDigits: 2,
    });
};

const SettingsPage: React.FC<SettingsPageProps> = ({ user, onUserUpdate }) => {
    const [currentPassword, setCurrentPassword] = useState('');
    const [newPassword, setNewPassword] = useState('');
    const [confirmPassword, setConfirmPassword] = useState('');
    const [error, setError] = useState('');
    const [success, setSuccess] = useState('');
    const [isLoading, setIsLoading] = useState(false);
    
    const [promoCode, setPromoCode] = useState('');
    const [isActivating, setIsActivating] = useState(false);
    const [selectedAvatar, setSelectedAvatar] = useState(user.avatarId);
    const [avatarSet, setAvatarSet] = useState<'pro' | 'default'>('pro');
    const { addNotification } = useNotification();
    const { theme, setTheme } = useTheme();
    
    const [isEditingNames, setIsEditingNames] = useState(false);
    const [editableName, setEditableName] = useState(user.name);
    const [editableFullName, setEditableFullName] = useState(user.fullName);
    const [nameError, setNameError] = useState('');

    const [isImageEditorOpen, setIsImageEditorOpen] = useState(false);
    const [imageToEdit, setImageToEdit] = useState<string | null>(null);
    const imageUploadRef = useRef<HTMLInputElement>(null);

    const handlePasswordChange = async (e: React.FormEvent) => {
        e.preventDefault();
        setError('');
        setSuccess('');

        if (newPassword.length < 6) {
            setError('Az új jelszónak legalább 6 karakter hosszúnak kell lennie.');
            return;
        }
        if (newPassword !== confirmPassword) {
            setError('Az új jelszavak nem egyeznek.');
            return;
        }

        setIsLoading(true);
        try {
            await authService.changePassword(user.id, currentPassword, newPassword);
            setSuccess('Jelszó sikeresen megváltoztatva!');
            setCurrentPassword('');
            setNewPassword('');
            setConfirmPassword('');
        } catch (err: any) {
            setError(err.message || 'Hiba történt.');
        } finally {
            setIsLoading(false);
        }
    };
    
    const handleCancelEditNames = () => {
        setIsEditingNames(false);
        setEditableName(user.name);
        setEditableFullName(user.fullName);
        setNameError('');
    };

    const handleSaveNames = async () => {
        setNameError('');
        if (!editableName.trim() || !editableFullName.trim()) {
            setNameError('A nevek nem lehetnek üresek.');
            return;
        }

        if (editableName.toLowerCase() !== user.name.toLowerCase()) {
            const isTaken = await authService.isNameTaken(editableName);
            if (isTaken) {
                setNameError('Ez a becenév már foglalt.');
                return;
            }
        }
        
        setIsLoading(true); // Reuse existing loading state
        try {
            const updatedUser = { ...user, name: editableName, fullName: editableFullName };
            authService.updateUser(updatedUser);
            onUserUpdate(updatedUser);
            addNotification('Nevek sikeresen frissítve!', 'success');
            setIsEditingNames(false);
        } catch (e) {
            addNotification('Hiba a nevek frissítésekor.', 'error');
        } finally {
            setIsLoading(false);
        }
    };

    const handleCodeActivation = async (e: React.FormEvent) => {
        e.preventDefault();
        if (!promoCode) return;

        setIsActivating(true);
        let newStatus: User['status'] = user.status || 'normal';
        let successMessage = '';

        const proMaxCodes = [
            '32ZataBE86', 'MAXPRO2X', 'ULTRAMAX', 'ASTMAXGO', 'TOPTIER1', 'KINGMAX7', 'PRMX2024'
        ];
        const proCodes = [
            'Fakiata82', 'PRO24AST', 'UPGPRO7X', 'STARPRO5', 'ASTPROGo', 'PROSTAT9', 'GETPRO24'
        ];
        
        // As "Pro Újságíró" is a display condition for a 'pro' user with a specific ID,
        // we provide more 'pro' codes. Any of these will grant 'pro' status.
        const proJournalistCodes = [
            'PRESSPRO', 'JOURNUPG', 'NEWSMAN1', 'BENCUSGO', 'JRPRO24X', 'WRITERUP', 'INFOJPRO'
        ];

        if (proMaxCodes.includes(promoCode)) {
            newStatus = 'pro_max';
            successMessage = 'Sikeres aktiválás! Mostól Pro Max felhasználó vagy.';
        } else if (proCodes.includes(promoCode) || proJournalistCodes.includes(promoCode)) {
            newStatus = 'pro';
            successMessage = 'Sikeres aktiválás! Mostól Pro felhasználó vagy.';
        } else {
            addNotification('Érvénytelen kód.', 'error');
            setIsActivating(false);
            return;
        }
        
        let updatedUser: User;
        
        if (newStatus === 'pro_max' && user.status !== 'pro_max') {
             const pointsToAdd = 1000 - user.points;
             updatedUser = {
                ...user,
                status: 'pro_max',
                points: 1000,
                pointsHistory: [
                    { reason: 'Pro Max státusz bónusz', points: pointsToAdd > 0 ? pointsToAdd : 0, date: Date.now() },
                    ...(user.pointsHistory || [])
                ],
            };
        } else {
            updatedUser = { ...user, status: newStatus };
        }

        try {
            authService.updateUser(updatedUser);
            onUserUpdate(updatedUser);
            // After updating status, update their chat access
            await messageService.updateUserChatAccess(updatedUser);

            addNotification(successMessage, 'success');
            setPromoCode('');
        } catch (err) {
            addNotification('Hiba történt az aktiválás során.', 'error');
        } finally {
            setIsActivating(false);
        }
    };

    const handleAvatarSelect = (avatarId: string) => {
        if (avatarId === selectedAvatar && !user.uploadedImage) return;

        setSelectedAvatar(avatarId);
        
        const updatedUser = { ...user, avatarId: avatarId, uploadedImage: null };
        authService.updateUser(updatedUser);
        onUserUpdate(updatedUser);
        addNotification('Avatar sikeresen frissítve!', 'success');
    };

    const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
        const file = e.target.files?.[0];
        if (file) {
            const reader = new FileReader();
            reader.onload = () => {
                setImageToEdit(reader.result as string);
                setIsImageEditorOpen(true);
            };
            reader.readAsDataURL(file);
        }
        e.target.value = ''; // Allow re-uploading the same file
    };

    const handleSaveImage = async (imageUrl: string) => {
        const updatedUser = { ...user, uploadedImage: imageUrl, avatarId: null };
        authService.updateUser(updatedUser);
        onUserUpdate(updatedUser);
        addNotification('Profilkép sikeresen frissítve!', 'success');
        setIsImageEditorOpen(false);
    };

    const handleRemoveCustomImage = () => {
        if (window.confirm('Biztosan törölni szeretnéd a saját profilképedet?')) {
            const updatedUser = { ...user, uploadedImage: null, avatarId: selectedAvatar || 'lion' };
            authService.updateUser(updatedUser);
            onUserUpdate(updatedUser);
            addNotification('Profilkép törölve.', 'success');
        }
    };

    const statusText = user.status === 'pro' ? 'Pro' : user.status === 'pro_max' ? 'Pro Max' : 'Normál';


    return (
        <>
        <div className="w-full max-w-2xl mx-auto animate-fade-in space-y-6 text-[var(--text-primary)]">
            <h1 className="text-3xl sm:text-4xl font-bold font-lilita tracking-wide text-center">Beállítások</h1>

            {/* Profile Info Card */}
            <div className="bg-[var(--component-bg)] backdrop-blur-sm rounded-2xl shadow-lg p-6 space-y-4">
                <div className="flex justify-between items-center border-b-2 border-[var(--border-color)] pb-2 mb-2">
                    <h2 className="text-2xl font-bold font-lilita">Fiók Adatok</h2>
                    {!isEditingNames ? (
                        <button onClick={() => setIsEditingNames(true)} className="p-2 rounded-full hover:bg-[var(--component-bg-hover)]">
                            <EditIcon className="w-5 h-5" />
                        </button>
                    ) : (
                        <div className="flex gap-2">
                            <button onClick={handleSaveNames} disabled={isLoading} className="p-2 rounded-full text-green-400 hover:bg-green-500/20 disabled:opacity-50"><CheckIcon className="w-5 h-5" /></button>
                            <button onClick={handleCancelEditNames} disabled={isLoading} className="p-2 rounded-full text-red-400 hover:bg-red-500/20"><XCircleIcon className="w-5 h-5" /></button>
                        </div>
                    )}
                </div>
                
                {isEditingNames ? (
                    <div className="space-y-4 animate-fade-in">
                        <div>
                            <label className="block text-sm font-semibold text-[var(--text-tertiary)]">Becenév</label>
                            <input type="text" value={editableName} onChange={e => setEditableName(e.target.value)} className="w-full text-lg bg-[var(--input-bg)] p-1 rounded-md" />
                        </div>
                        <div>
                            <label className="block text-sm font-semibold text-[var(--text-tertiary)]">Teljes Név</label>
                            <input type="text" value={editableFullName} onChange={e => setEditableFullName(e.target.value)} className="w-full text-lg bg-[var(--input-bg)] p-1 rounded-md" />
                        </div>
                        {nameError && <p className="text-red-400 text-sm">{nameError}</p>}
                    </div>
                ) : (
                    <>
                        <div>
                            <label className="block text-sm font-semibold text-[var(--text-tertiary)]">Becenév</label>
                            <p className="text-lg">{user.name}</p>
                        </div>
                        <div>
                            <label className="block text-sm font-semibold text-[var(--text-tertiary)]">Teljes Név</label>
                            <p className="text-lg">{user.fullName}</p>
                        </div>
                    </>
                )}

                <div>
                    <label className="block text-sm font-semibold text-[var(--text-tertiary)]">Azonosító kód</label>
                    <p className="text-lg">{user.identifier}</p>
                </div>
                 <div>
                    <label className="block text-sm font-semibold text-[var(--text-tertiary)]">Jelenlegi Státusz</label>
                    <p className="text-lg font-bold text-orange-400">{statusText}</p>
                </div>
                <div>
                    <label className="block text-sm font-semibold text-[var(--text-tertiary)]">Összes Korona</label>
                    <p className="text-lg font-bold text-amber-400">{formatCrowns(user.points)}</p>
                </div>
            </div>

            {/* Appearance Settings */}
            <div className="bg-[var(--component-bg)] backdrop-blur-sm rounded-2xl shadow-lg p-6">
                <h2 className="text-2xl font-bold font-lilita border-b-2 border-[var(--border-color)] pb-2 mb-4">Megjelenés</h2>
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-4">
                    {themeOptions.map((option) => (
                        <button
                            key={option.id}
                            onClick={() => setTheme(option.id)}
                            className={`flex flex-col items-center justify-center p-3 rounded-lg border-2 transition-all duration-200 ${
                                theme === option.id
                                    ? 'border-orange-500 bg-orange-500/20'
                                    : 'border-transparent bg-[var(--input-bg)] hover:border-orange-500/50'
                            }`}
                        >
                            <div
                                className="w-12 h-12 rounded-full mb-2 border-2 border-white/20"
                                style={option.style}
                            />
                            <span className="font-semibold text-sm">{option.name}</span>
                        </button>
                    ))}
                </div>
            </div>
            

            {/* Avatar Change */}
            <div className="bg-[var(--component-bg)] backdrop-blur-sm rounded-2xl shadow-lg p-6">
                <div className="flex justify-between items-center border-b-2 border-[var(--border-color)] pb-2 mb-4">
                    <h2 className="text-2xl font-bold font-lilita">Avatar módosítása</h2>
                    <div className="flex gap-2">
                         <button onClick={() => imageUploadRef.current?.click()} className="px-3 py-1 text-sm bg-blue-600 rounded-full font-bold">Saját kép</button>
                        {user.uploadedImage && (
                            <button onClick={handleRemoveCustomImage} className="px-3 py-1 text-sm bg-red-600 rounded-full font-bold">Kép Törlése</button>
                        )}
                    </div>
                    <input type="file" ref={imageUploadRef} onChange={handleFileSelect} accept="image/*" className="hidden" />
                </div>
                <div className="flex justify-center gap-4 mb-4">
                    <button
                        onClick={() => setAvatarSet('pro')}
                        className={`px-4 py-2 font-bold rounded-full transition-colors ${
                            avatarSet === 'pro'
                            ? 'bg-orange-600 text-[var(--text-on-accent)]'
                            : 'bg-[var(--input-bg)] text-[var(--text-secondary)]'
                        }`}
                    >
                        Exkluzív
                    </button>
                    <button
                        onClick={() => setAvatarSet('default')}
                            className={`px-4 py-2 font-bold rounded-full transition-colors ${
                            avatarSet === 'default'
                            ? 'bg-orange-600 text-[var(--text-on-accent)]'
                            : 'bg-[var(--input-bg)] text-[var(--text-secondary)]'
                        }`}
                    >
                        Alap
                    </button>
                </div>
                <AvatarSelector
                    selectedAvatar={selectedAvatar}
                    onSelectAvatar={handleAvatarSelect}
                    avatarSet={avatarSet}
                />
            </div>

            {/* Pro Activation */}
             {user.status !== 'pro_max' && (
                <div className="bg-[var(--component-bg)] backdrop-blur-sm rounded-2xl shadow-lg p-6">
                    <h2 className="text-2xl font-bold font-lilita border-b-2 border-[var(--border-color)] pb-2 mb-4">Pro Státusz Aktiválása</h2>
                    <form onSubmit={handleCodeActivation} className="space-y-4">
                        <div>
                            <label htmlFor="promo-code" className="block text-[var(--text-primary)] font-semibold mb-1">Aktiváló kód</label>
                            <input
                                type="text"
                                id="promo-code"
                                value={promoCode}
                                onChange={(e) => setPromoCode(e.target.value)}
                                className="w-full px-4 py-2 bg-[var(--input-bg)] text-[var(--text-primary)] border-2 border-transparent rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500 focus:border-transparent transition"
                                required
                                disabled={isActivating}
                                placeholder="Írd be a kódot..."
                            />
                        </div>
                        <button
                            type="submit"
                            disabled={isActivating}
                            className="w-full mt-4 px-4 py-3 bg-orange-600 text-white font-bold rounded-full text-lg shadow-lg transform hover:scale-105 transition-transform duration-200 disabled:bg-orange-400 disabled:scale-100 disabled:cursor-not-allowed"
                            >
                            {isActivating ? 'Aktiválás...' : 'Aktiválás'}
                        </button>
                    </form>
                </div>
            )}
            
            {/* Points History Card */}
            <div className="bg-[var(--component-bg)] backdrop-blur-sm rounded-2xl shadow-lg p-6">
                <h2 className="text-2xl font-bold font-lilita border-b-2 border-[var(--border-color)] pb-2 mb-4">Korona szerzési akciók</h2>
                <div className="max-h-60 overflow-y-auto space-y-2 pr-2">
                    {user.pointsHistory && user.pointsHistory.length > 0 ? (
                        user.pointsHistory.map((entry, index) => (
                             <div key={index} className="flex justify-between items-center p-2 bg-[var(--input-bg)] bg-opacity-40 rounded-lg">
                                <div>
                                    <p className="font-semibold">{entry.reason}</p>
                                    <p className="text-xs text-[var(--text-tertiary)]">{new Date(entry.date).toLocaleString('hu-HU')}</p>
                                </div>
                                <span className={`font-bold text-lg ${entry.points > 0 ? 'text-green-400' : 'text-red-400'}`}>
                                    {entry.points > 0 ? '+' : ''}{formatCrowns(entry.points)}
                                </span>
                            </div>
                        ))
                    ) : (
                        <p className="text-[var(--text-tertiary)] text-center">Nincs koronához kapcsolódó tevékenység.</p>
                    )}
                </div>
            </div>

            {/* Change Password Card */}
            <div className="bg-[var(--component-bg)] backdrop-blur-sm rounded-2xl shadow-lg p-6">
                <h2 className="text-2xl font-bold font-lilita border-b-2 border-[var(--border-color)] pb-2 mb-4">Jelszó Módosítása</h2>
                <form onSubmit={handlePasswordChange} className="space-y-4">
                    <div>
                        <label htmlFor="current-password" className="block text-[var(--text-primary)] font-semibold mb-1">Jelenlegi jelszó</label>
                        <input
                            type="password"
                            id="current-password"
                            value={currentPassword}
                            onChange={(e) => setCurrentPassword(e.target.value)}
                            className="w-full px-4 py-2 bg-[var(--input-bg)] text-[var(--text-primary)] border-2 border-transparent rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500 focus:border-transparent transition"
                            required
                            disabled={isLoading}
                        />
                    </div>
                     <div>
                        <label htmlFor="new-password" className="block text-[var(--text-primary)] font-semibold mb-1">Új jelszó</label>
                        <input
                            type="password"
                            id="new-password"
                            value={newPassword}
                            onChange={(e) => setNewPassword(e.target.value)}
                            className="w-full px-4 py-2 bg-[var(--input-bg)] text-[var(--text-primary)] border-2 border-transparent rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500 focus:border-transparent transition"
                            required
                            disabled={isLoading}
                        />
                    </div>
                     <div>
                        <label htmlFor="confirm-password" className="block text-[var(--text-primary)] font-semibold mb-1">Új jelszó megerősítése</label>
                        <input
                            type="password"
                            id="confirm-password"
                            value={confirmPassword}
                            onChange={(e) => setConfirmPassword(e.target.value)}
                            className="w-full px-4 py-2 bg-[var(--input-bg)] text-[var(--text-primary)] border-2 border-transparent rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500 focus:border-transparent transition"
                            required
                            disabled={isLoading}
                        />
                    </div>

                    {error && <p className="text-orange-300 text-sm text-center bg-orange-800/50 p-2 rounded-lg">{error}</p>}
                    {success && <p className="text-green-300 text-sm text-center bg-green-800/50 p-2 rounded-lg">{success}</p>}

                    <button
                        type="submit"
                        disabled={isLoading}
                        className="w-full mt-4 px-4 py-3 bg-orange-600 text-white font-bold rounded-full text-lg shadow-lg transform hover:scale-105 transition-transform duration-200 disabled:bg-orange-400 disabled:scale-100 disabled:cursor-not-allowed"
                        >
                        {isLoading ? 'Mentés...' : 'Jelszó frissítése'}
                    </button>
                </form>
            </div>
        </div>
        <ProfileImageEditorModal
            isOpen={isImageEditorOpen}
            onClose={() => setIsImageEditorOpen(false)}
            imageSrc={imageToEdit}
            onSave={handleSaveImage}
        />
        </>
    );
};

export default SettingsPage;