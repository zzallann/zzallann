import React, { useState } from 'react';
import type { User } from '../types';
import UserAvatarWithStatus from './UserAvatarWithStatus';
import XCircleIcon from './icons/XCircleIcon';
import PlusIcon from './icons/PlusIcon';
import TrashIcon from './icons/TrashIcon';
import EditIcon from './icons/EditIcon';
import CheckIcon from './icons/CheckIcon';

interface ChatParticipantsModalProps {
    isOpen: boolean;
    onClose: () => void;
    participants: User[];
    currentUser: User;
    canManageMembers: boolean;
    createdBy?: string;
    onAddUsersClick: () => void;
    onRemoveUser: (userId: string) => void;
    nicknames: Record<string, string>;
    onSetNickname: (userId: string, nickname: string) => void;
}

const ChatParticipantsModal: React.FC<ChatParticipantsModalProps> = ({ isOpen, onClose, participants, currentUser, canManageMembers, createdBy, onAddUsersClick, onRemoveUser, nicknames, onSetNickname }) => {
    const [editing, setEditing] = useState<{ userId: string; value: string } | null>(null);

    if (!isOpen) return null;

    const handleSaveNickname = () => {
        if (editing) {
            onSetNickname(editing.userId, editing.value);
            setEditing(null);
        }
    };

    return (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex justify-center items-center animate-fade-in" onClick={onClose}>
            <div className="bg-slate-800 w-full max-w-md max-h-[80vh] rounded-2xl shadow-2xl flex flex-col" onClick={e => e.stopPropagation()}>
                <div className="flex justify-between items-center p-4 border-b border-slate-700">
                    <h3 className="text-xl font-bold text-white">Résztvevők ({participants.length})</h3>
                    <div className="flex items-center gap-2">
                        {canManageMembers && (
                            <button onClick={onAddUsersClick} className="flex items-center gap-1 px-3 py-1 bg-green-600 text-white font-bold text-sm rounded-full">
                                <PlusIcon className="w-4 h-4"/> Tag hozzáadása
                            </button>
                        )}
                        <button onClick={onClose} className="p-1 rounded-full hover:bg-slate-700"><XCircleIcon className="w-6 h-6 text-slate-400"/></button>
                    </div>
                </div>
                <div className="flex-1 p-4 overflow-y-auto space-y-3 max-h-80">
                    {participants.sort((a,b) => a.name.localeCompare(b.name)).map(user => {
                        const isEditingThisUser = editing?.userId === user.id;
                        const userNickname = nicknames[user.id];

                        return (
                            <div key={user.id} className="flex items-center gap-3 p-2 bg-slate-700/50 rounded-lg">
                                <UserAvatarWithStatus user={user} size="small" />
                                {isEditingThisUser ? (
                                    <div className="flex-1 flex items-center gap-2">
                                        <input
                                            type="text"
                                            value={editing.value}
                                            onChange={(e) => setEditing({ ...editing, value: e.target.value })}
                                            placeholder="Becenév..."
                                            className="w-full bg-slate-800 p-1 rounded-md text-white"
                                            autoFocus
                                            onKeyDown={(e) => { if (e.key === 'Enter') handleSaveNickname(); }}
                                        />
                                        <button onClick={handleSaveNickname} className="p-1 text-green-400"><CheckIcon className="w-5 h-5"/></button>
                                        <button onClick={() => setEditing(null)} className="p-1 text-red-400"><XCircleIcon className="w-5 h-5"/></button>
                                    </div>
                                ) : (
                                    <>
                                        <div className="flex-1">
                                            <span className="font-semibold text-white">{userNickname || user.name}</span>
                                            {userNickname && <span className="text-xs text-white/70 ml-2">({user.name})</span>}
                                            {user.id === createdBy && <span className="text-xs text-orange-400 ml-2">(Admin)</span>}
                                        </div>
                                        {canManageMembers && (
                                            <button onClick={() => setEditing({ userId: user.id, value: userNickname || '' })} className="p-2 text-white/60 hover:text-white rounded-full">
                                                <EditIcon className="w-5 h-5"/>
                                            </button>
                                        )}
                                        {canManageMembers && user.id !== currentUser.id && user.id !== createdBy && (
                                            <button onClick={() => onRemoveUser(user.id)} className="p-2 text-red-400 hover:bg-red-500/20 rounded-full">
                                                <TrashIcon className="w-5 h-5"/>
                                            </button>
                                        )}
                                    </>
                                )}
                            </div>
                        );
                    })}
                </div>
            </div>
        </div>
    );
};

export default ChatParticipantsModal;