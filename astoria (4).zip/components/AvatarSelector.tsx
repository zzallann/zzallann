import React from 'react';
import type { SVGProps } from 'react';
import type { Avatar } from '../types';

import LionIcon from './icons/LionIcon';
import PandaIcon from './icons/PandaIcon';
import UfoIcon from './icons/UfoIcon';
import BearIcon from './icons/BearIcon';
import RabbitIcon from './icons/RabbitIcon';
import BurgerIcon from './icons/BurgerIcon';
import DogIcon from './icons/DogIcon';
import GiraffeIcon from './icons/GiraffeIcon';
import TigerIcon from './icons/TigerIcon';
import HippoIcon from './icons/HippoIcon';
import PigIcon from './icons/PigIcon';
import KoalaIcon from './icons/KoalaIcon';
import PoliceBearIcon from './icons/PoliceBearIcon';
import ZebraIcon from './icons/ZebraIcon';
import MegaphoneIcon from './icons/MegaphoneIcon';
import BurglarIcon from './icons/BurglarIcon';
import JournalistIcon from './icons/JournalistIcon';

// --- NEW PRO AVATAR COMPONENTS ---
const FbiAgentIcon: React.FC<SVGProps<SVGSVGElement>> = (props) => (
  <svg viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg" {...props}>
    <circle cx="24" cy="24" r="20" fill="#FFDAB9"/>
    {/* Suit */}
    <path d="M16 40V30H32V40" fill="#212121"/>
    <path d="M18 30L16 22H32L30 30H18Z" fill="#FFFFFF" stroke="#212121" strokeWidth="2"/>
    <path d="M24 22V30" stroke="#212121" strokeWidth="2"/>
    <path d="M21 22L20 30" stroke="#212121" strokeWidth="1.5"/>
    <path d="M27 22L28 30" stroke="#212121" strokeWidth="1.5"/>
    {/* Hair */}
    <path d="M16 22 C 16 16, 20 12, 24 12 C 28 12, 32 16, 32 22 Z" fill="#424242"/>
    {/* Sunglasses */}
    <rect x="15" y="20" width="8" height="5" rx="2" fill="#212121"/>
    <rect x="25" y="20" width="8" height="5" rx="2" fill="#212121"/>
    <path d="M23 22.5H25" stroke="#424242" strokeWidth="1.5"/>
    {/* Mouth */}
    <path d="M22 34h4" stroke="#424242" strokeWidth="1.5" strokeLinecap="round"/>
  </svg>
);
const DetectiveIcon: React.FC<SVGProps<SVGSVGElement>> = (props) => (
  <svg viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg" {...props}>
    <circle cx="24" cy="24" r="20" fill="#EFEBE9"/>
    {/* Hat */}
    <path d="M10 24 C 10 16, 18 14, 24 14 C 30 14, 38 16, 38 24 Z" fill="#5D4037"/>
    <rect x="8" y="24" width="32" height="4" fill="#6D4C41"/>
    {/* Face */}
    <circle cx="24" cy="28" r="8" fill="#FFDAB9"/>
    <circle cx="20" cy="28" r="1.5" fill="#212121"/>
    <circle cx="28" cy="28" r="1.5" fill="#212121"/>
    <path d="M22 32 C 24 31, 26 31, 26 32" stroke="#424242" strokeWidth="2" strokeLinecap="round"/>
    {/* Magnifying glass */}
    <circle cx="34" cy="34" r="5" fill="#B0BEC5" opacity="0.3"/>
    <circle cx="34" cy="34" r="7" stroke="#424242" strokeWidth="2.5" fill="none"/>
    <path d="M28.5 39.5 L 22 46" stroke="#424242" strokeWidth="3" strokeLinecap="round"/>
  </svg>
);
const ChefIcon: React.FC<SVGProps<SVGSVGElement>> = (props) => (
  <svg viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg" {...props}>
    <circle cx="24" cy="24" r="20" fill="#FFDAB9"/>
    <path d="M12 18 a 6 6 0 0 1 6-6 a 4 4 0 0 1 4 4 a 5 5 0 0 1 5-5 a 5 5 0 0 1 5 5 a 4 4 0 0 1 4-4 a 6 6 0 0 1 6 6 H 12 Z" fill="#FFFFFF" stroke="#6D4C41" strokeWidth="2"/>
    <circle cx="20" cy="24" r="1.5" fill="#3E2723"/>
    <circle cx="28" cy="24" r="1.5" fill="#3E2723"/>
    <path d="M18 32 Q 24 36, 30 32" stroke="#3E2723" strokeWidth="2" strokeLinecap="round" fill="none"/>
    <path d="M18 29 C 16 28, 18 26, 22 28 C 22 28, 26 28, 26 28 C 30 26, 32 28, 30 29" stroke="#3E2723" strokeWidth="2" strokeLinecap="round" fill="#3E2723"/>
  </svg>
);
const ArtistIcon: React.FC<SVGProps<SVGSVGElement>> = (props) => (
  <svg viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg" {...props}>
    <circle cx="24" cy="24" r="20" fill="#D7CCC8"/>
    <circle cx="20" cy="22" r="1.5" fill="#424242"/><circle cx="28" cy="22" r="1.5" fill="#424242"/>
    <path d="M18 28 Q 24 26, 30 28" stroke="#424242" strokeWidth="2" strokeLinecap="round"/>
    <path d="M12 18 L 36 14 L 32 20 H 16 Z" fill="#E53935"/>
    <path d="M32 28 L 36 24 L 38 32 L 32 28 M 34 26 C 33 24, 35 23, 36 22" stroke="#C62828" strokeWidth="2" strokeLinecap="round"/>
    <circle cx="14" cy="30" r="3" fill="#1976D2"/><circle cx="18" cy="34" r="2" fill="#FDD835"/>
  </svg>
);
const NinjaIcon: React.FC<SVGProps<SVGSVGElement>> = (props) => (
  <svg viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg" {...props}>
    <circle cx="24" cy="24" r="20" fill="#263238"/>
    <path d="M12 28 L 24 18 L 36 28 L 24 38 Z" fill="#455A64"/>
    <path d="M12 28 H 36" stroke="#E53935" strokeWidth="3" strokeLinecap="round"/>
    <ellipse cx="18" cy="24" rx="3" ry="4" fill="#FFFFFF"/><ellipse cx="30" cy="24" rx="3" ry="4" fill="#FFFFFF"/>
    <circle cx="18" cy="24" r="1.5" fill="#000000"/><circle cx="30" cy="24" r="1.5" fill="#000000"/>
  </svg>
);
const PirateIcon: React.FC<SVGProps<SVGSVGElement>> = (props) => (
  <svg viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg" {...props}>
    <circle cx="24" cy="24" r="20" fill="#FFDAB9"/>
    <path d="M16 20 H 32 V 16 C 32 12, 28 10, 24 10 C 20 10, 16 12, 16 16 V 20 Z" fill="#212121"/>
    <rect x="18" y="22" width="4" height="6" fill="#212121"/>
    <path d="M26 22 H 30 V 28 H 26 V 22 Z" fill="#212121" />
    <path d="M18 32 Q 24 36, 30 32" stroke="#C62828" strokeWidth="3" strokeLinecap="round"/>
    <circle cx="26" cy="14" r="3" fill="#FFFFFF"/>
    <path d="M25 13 L 27 15 M 27 13 L 25 15" stroke="#212121" strokeWidth="1.5" strokeLinecap="round"/>
  </svg>
);
const ScientistIcon: React.FC<SVGProps<SVGSVGElement>> = (props) => (
  <svg viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg" {...props}>
    <circle cx="24" cy="24" r="20" fill="#F5F5F5"/>
    <path d="M16 38 V 28 H 32 V 38" fill="#FFFFFF" stroke="#B0BEC5" strokeWidth="2"/>
    <path d="M22 34 H 26 V 30 H 22 V 34 Z" fill="#4FC3F7"/>
    <circle cx="20" cy="22" r="4" fill="none" stroke="#616161" strokeWidth="2"/>
    <circle cx="28" cy="22" r="4" fill="none" stroke="#616161" strokeWidth="2"/>
    <path d="M16 18 C 12 10, 36 10, 32 18" stroke="#424242" strokeWidth="3" strokeLinecap="round"/>
    <path d="M20 28 Q 24 30, 28 28" stroke="#616161" strokeWidth="2" strokeLinecap="round"/>
  </svg>
);
const RobotIcon: React.FC<SVGProps<SVGSVGElement>> = (props) => (
  <svg viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg" {...props}>
    <rect x="8" y="14" width="32" height="24" rx="4" fill="#B0BEC5"/>
    <rect x="12" y="18" width="24" height="8" fill="#455A64"/>
    <rect x="14" y="20" width="8" height="4" fill="#EF5350" /><rect x="26" y="20" width="8" height="4" fill="#EF5350" />
    <rect x="20" y="30" width="8" height="2" fill="#78909C"/>
    <path d="M24 14 L 28 8 L 26 8 L 22 14" fill="#90A4AE"/>
    <circle cx="28" cy="7" r="2" fill="#EF5350"/>
  </svg>
);
const VampireIcon: React.FC<SVGProps<SVGSVGElement>> = (props) => (
  <svg viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg" {...props}>
    <circle cx="24" cy="24" r="20" fill="#F5F5F5"/>
    <path d="M12 24 L 24 10 L 36 24 L 24 38 Z" fill="#212121"/>
    <path d="M16 16 L 24 24 L 32 16" fill="#F5F5F5"/>
    <circle cx="20" cy="26" r="1.5" fill="#E53935"/><circle cx="28" cy="26" r="1.5" fill="#E53935"/>
    <path d="M20 32 L 22 30 M 28 32 L 26 30" stroke="#FFFFFF" strokeWidth="2" strokeLinecap="round"/>
  </svg>
);
const ZombieIcon: React.FC<SVGProps<SVGSVGElement>> = (props) => (
  <svg viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg" {...props}>
    <circle cx="24" cy="24" r="20" fill="#A5D6A7"/>
    <circle cx="20" cy="22" r="3" fill="#FFFFFF" stroke="#4CAF50" strokeWidth="2"/>
    <path d="M28 20 L 32 24 M 32 20 L 28 24" stroke="#4CAF50" strokeWidth="3" strokeLinecap="round"/>
    <path d="M18 32 C 22 30, 26 30, 30 32" stroke="#66BB6A" strokeWidth="2" strokeLinecap="round"/>
    <path d="M14 28 L 18 26 M 34 28 L 30 26" stroke="#8D6E63" strokeWidth="2" strokeLinecap="round"/>
  </svg>
);
const ElfIcon: React.FC<SVGProps<SVGSVGElement>> = (props) => (
  <svg viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg" {...props}>
    <circle cx="24" cy="24" r="20" fill="#FFECB3"/>
    <path d="M16 18 L 12 8 L 18 16" fill="#FFECB3" stroke="#C8A464" strokeWidth="2" strokeLinejoin="round"/>
    <path d="M32 18 L 36 8 L 30 16" fill="#FFECB3" stroke="#C8A464" strokeWidth="2" strokeLinejoin="round"/>
    <circle cx="20" cy="24" r="2" fill="#4CAF50"/><circle cx="28" cy="24" r="2" fill="#4CAF50"/>
    <path d="M20 32 Q 24 34, 28 32" stroke="#C8A464" strokeWidth="2" strokeLinecap="round"/>
    <path d="M18 16 C 16 12, 32 12, 30 16" stroke="#FDD835" strokeWidth="2" strokeLinecap="round"/>
  </svg>
);
const DwarfIcon: React.FC<SVGProps<SVGSVGElement>> = (props) => (
  <svg viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg" {...props}>
    <circle cx="24" cy="24" r="20" fill="#FFDAB9"/>
    {/* Helmet */}
    <path d="M14 22 C 14 14, 18 10, 24 10 C 30 10, 34 14, 34 22 Z" fill="#90A4AE" stroke="#546E7A" strokeWidth="2"/>
    <path d="M21 10 L 20 14 M 27 10 L 28 14" stroke="#546E7A" strokeWidth="2" strokeLinecap="round" />
    {/* Beard */}
    <path d="M14 22 V 40 C 14 40, 24 34, 34 40 V 22 Z" fill="#A1887F" stroke="#6D4C41" strokeWidth="2"/>
    <path d="M16 24 L 12 38 M 20 24 L 16 38 M 24 24 L 24 32 M 28 24 L 32 38 M 32 24 L 36 38" stroke="#D7CCC8" strokeWidth="2" strokeLinecap="round"/>
    {/* Face */}
    <path d="M20 23 C 20 25, 22 26, 24 26 C 26 26, 28 25, 28 23 Z" fill="#FFDAB9"/>
    <circle cx="21" cy="22" r="1" fill="#424242"/>
    <circle cx="27" cy="22" r="1" fill="#424242"/>
  </svg>
);
const FairyIcon: React.FC<SVGProps<SVGSVGElement>> = (props) => (
  <svg viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg" {...props}>
    <circle cx="24" cy="24" r="14" fill="#FFEBEE"/>
    <path d="M10 24 C 4 16, 10 8, 16 16" fill="#81D4FA" opacity="0.7" stroke="#039BE5" strokeWidth="2"/>
    <path d="M38 24 C 44 16, 38 8, 32 16" fill="#81D4FA" opacity="0.7" stroke="#039BE5" strokeWidth="2"/>
    <circle cx="21" cy="22" r="1.5" fill="#EC407A"/><circle cx="27" cy="22" r="1.5" fill="#EC407A"/>
    <path d="M22 28 Q 24 30, 26 28" stroke="#EC407A" strokeWidth="2" strokeLinecap="round"/>
    <circle cx="24" cy="16" r="2" fill="#FDD835"/>
  </svg>
);
const CyborgIcon: React.FC<SVGProps<SVGSVGElement>> = (props) => (
  <svg viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg" {...props}>
    <path d="M24 4 A 20 20 0 0 0 24 44" fill="#FFDAB9"/>
    <path d="M24 4 A 20 20 0 0 1 24 44" fill="#B0BEC5"/>
    <path d="M24 4 V 44" stroke="#455A64" strokeWidth="2"/>
    <circle cx="18" cy="22" r="2" fill="#424242"/>
    <path d="M16 30 Q 20 32, 24 30" stroke="#424242" strokeWidth="2" strokeLinecap="round"/>
    <circle cx="30" cy="22" r="4" fill="#EF5350" />
    <path d="M28 28 H 32" stroke="#78909C" strokeWidth="2"/>
  </svg>
);
const GhostIcon: React.FC<SVGProps<SVGSVGElement>> = (props) => (
  <svg viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg" {...props}>
    <path d="M10 40 L 12 36 L 16 40 L 20 36 L 24 40 L 28 36 L 32 40 L 36 36 L 38 40 H 10 V 20 C 10 12, 16 8, 24 8 C 32 8, 38 12, 38 20 V 40 Z" fill="#FFFFFF" stroke="#90A4AE" strokeWidth="2"/>
    <circle cx="20" cy="24" r="3" fill="#263238"/><circle cx="28" cy="24" r="3" fill="#263238"/>
    <path d="M22 32 Q 24 30, 26 32" stroke="#263238" strokeWidth="2" strokeLinecap="round"/>
  </svg>
);
const AlienIcon: React.FC<SVGProps<SVGSVGElement>> = (props) => (
  <svg viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg" {...props}>
    <path d="M24 4 C 12 4, 10 24, 10 24 C 10 36, 16 44, 24 44 C 32 44, 38 36, 38 24 C 38 24, 36 4, 24 4 Z" fill="#8BC34A"/>
    <ellipse cx="18" cy="24" rx="4" ry="8" fill="#212121"/>
    <ellipse cx="30" cy="24" rx="4" ry="8" fill="#212121"/>
    <path d="M20 34 H 28" stroke="#558B2F" strokeWidth="2" strokeLinecap="round"/>
  </svg>
);

// --- NEW GROUP AVATAR ICONS ---
const GroupStarIcon: React.FC<SVGProps<SVGSVGElement>> = (props) => (
  <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" {...props}><path d="M12 2L15.09 8.26L22 9.27L17 14.14L18.18 21.02L12 17.77L5.82 21.02L7 14.14L2 9.27L8.91 8.26L12 2Z" fill="currentColor"/></svg>
);
const GroupPlanetIcon: React.FC<SVGProps<SVGSVGElement>> = (props) => (
  <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" {...props}><path d="M18.9 14.25C21.1 12.33 21.1 9.07 18.9 7.15C17.76 6.22 16.32 5.8 14.86 5.95C12.8-0.3 6.33-0.53 4.03 5.3C3.54 6.62 3.53 7.96 4.02 9.1C1.82 11.02 1.82 14.28 4.02 16.2C5.16 17.13 6.6 17.55 8.06 17.4C10.12 23.65 16.6 23.88 18.9 18.05C19.39 16.73 19.4 15.39 18.9 14.25Z" fill="currentColor"/><path d="M8.06 17.4C8.75 17.53 9.47 17.46 10.14 17.2C13.21 21.46 19.78 18.2 18.9 14.25C19.4 15.39 19.39 16.73 18.9 18.05C16.6 23.88 10.12 23.65 8.06 17.4Z" fill="currentColor" opacity="0.4"/></svg>
);
const GroupCoffeeIcon: React.FC<SVGProps<SVGSVGElement>> = (props) => (
  <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" {...props}><path d="M4 8H18C20.2091 8 22 9.79086 22 12C22 14.2091 20.2091 16 18 16H17.5M4 8V18C4 19.1046 4.89543 20 6 20H14C15.1046 20 16 19.1046 16 18V16M4 8C4 6.89543 4.89543 6 6 6H14C15.1046 6 16 6.89543 16 8V16" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/></svg>
);
const GroupChatBubblesIcon: React.FC<SVGProps<SVGSVGElement>> = (props) => (
    <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" {...props}><path d="M17 11.5V11C17 7.13401 13.866 4 10 4C6.13401 4 3 7.13401 3 11V11.5C3 15.366 6.13401 18.5 10 18.5C10.5523 18.5 11.0523 18.4477 11.5 18.3562M21 11.5C21 13.9853 19.5853 16 17.5 16C15.4147 16 14 13.9853 14 11.5C14 9.01472 15.4147 7 17.5 7C19.5853 7 21 9.01472 21 11.5Z" stroke="currentColor" strokeWidth="2"/></svg>
);
const GroupCodeIcon: React.FC<SVGProps<SVGSVGElement>> = (props) => (
    <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" {...props}><path d="M9 20L3 14L9 8M15 20L21 14L15 8" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/></svg>
);
const GroupHeartbeatIcon: React.FC<SVGProps<SVGSVGElement>> = (props) => (
    <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" {...props}><path d="M3 12H7L9 4L15 20L17 12H21" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/></svg>
);



export const avatars: Avatar[] = [
  // Default Avatars
  { id: 'lion', name: 'Oroszlán', component: LionIcon },
  { id: 'panda', name: 'Panda', component: PandaIcon },
  { id: 'ufo', name: 'Ufó', component: UfoIcon },
  { id: 'bear', name: 'Medve', component: BearIcon },
  { id: 'rabbit', name: 'Nyúl', component: RabbitIcon },
  { id: 'burger', name: 'Burger', component: BurgerIcon },
  { id: 'dog', name: 'Kutya', component: DogIcon },
  { id: 'giraffe', name: 'Zsiráf', component: GiraffeIcon },
  { id: 'tiger', name: 'Tigris', component: TigerIcon },
  { id: 'hippo', name: 'Víziló', component: HippoIcon },
  { id: 'pig', name: 'Malac', component: PigIcon },
  { id: 'koala', name: 'Koala', component: KoalaIcon },
  
  // Pro Avatars (New Set)
  { id: 'fbi-agent', name: 'FBI Ügynök', component: FbiAgentIcon },
  { id: 'detective', name: 'Detektív', component: DetectiveIcon },
  { id: 'chef', name: 'Séf', component: ChefIcon },
  { id: 'artist', name: 'Művész', component: ArtistIcon },
  { id: 'ninja', name: 'Nindzsa', component: NinjaIcon },
  { id: 'pirate', name: 'Kalóz', component: PirateIcon },
  { id: 'scientist', name: 'Tudós', component: ScientistIcon },
  { id: 'robot', name: 'Robot', component: RobotIcon },
  { id: 'vampire', name: 'Vámpír', component: VampireIcon },
  { id: 'zombie', name: 'Zombi', component: ZombieIcon },
  { id: 'elf', name: 'Elf', component: ElfIcon },
  { id: 'dwarf', name: 'Törp', component: DwarfIcon },
  { id: 'fairy', name: 'Tündér', component: FairyIcon },
  { id: 'cyborg', name: 'Kiborg', component: CyborgIcon },
  { id: 'ghost', name: 'Szellem', component: GhostIcon },
  { id: 'alien', name: 'Földönkívüli', component: AlienIcon },

  // Special Avatars
  { id: 'police-bear', name: 'Rendőr Medve', component: PoliceBearIcon },
  { id: 'zebra', name: 'Zebra', component: ZebraIcon },
  { id: 'megaphone', name: 'Rendszer', component: MegaphoneIcon },
  { id: 'burglar', name: 'Betörő', component: BurglarIcon },
  { id: 'journalist', name: 'Újságíró', component: JournalistIcon },

  // Group Chat Avatars
  { id: 'group-star', name: 'Csillag', component: GroupStarIcon },
  { id: 'group-planet', name: 'Bolyó', component: GroupPlanetIcon },
  { id: 'group-coffee', name: 'Kávé', component: GroupCoffeeIcon },
  { id: 'group-bubbles', name: 'Beszélgetés', component: GroupChatBubblesIcon },
  { id: 'group-code', name: 'Kód', component: GroupCodeIcon },
  { id: 'group-heartbeat', name: 'Pulzus', component: GroupHeartbeatIcon },
];

const defaultAvatarIds = ['lion', 'panda', 'ufo', 'bear', 'rabbit', 'burger', 'dog', 'giraffe', 'tiger', 'hippo', 'pig', 'koala'];
const proAvatarIds = [
    'fbi-agent', 'detective', 'chef', 'artist', 'ninja', 'pirate', 'scientist', 'robot',
    'vampire', 'zombie', 'elf', 'dwarf', 'fairy', 'cyborg', 'ghost', 'alien'
];
export const groupAvatarIds = ['group-star', 'group-planet', 'group-coffee', 'group-bubbles', 'group-code', 'group-heartbeat'];


interface AvatarSelectorProps {
  selectedAvatar: string | null;
  onSelectAvatar: (id: string) => void;
  exclude?: string[];
  avatarSet?: 'default' | 'pro';
}

const AvatarSelector: React.FC<AvatarSelectorProps> = ({ selectedAvatar, onSelectAvatar, exclude = [], avatarSet = 'default' }) => {
  
  let sourceAvatars;
  if (avatarSet === 'pro') {
      sourceAvatars = avatars.filter(a => proAvatarIds.includes(a.id));
  } else { // default
      sourceAvatars = avatars.filter(a => defaultAvatarIds.includes(a.id));
  }

  const selectableAvatars = sourceAvatars.filter(a => !exclude.includes(a.id));

  return (
    <div>
        <label className="block text-[var(--text-primary)] font-semibold mb-2 text-center">Válassz Avatart</label>
        <div className="grid grid-cols-4 sm:grid-cols-6 gap-2">
        {selectableAvatars.map((avatar) => {
            const isSelected = selectedAvatar === avatar.id;
            return (
            <button
                type="button"
                key={avatar.id}
                onClick={() => onSelectAvatar(avatar.id)}
                className={`p-1 rounded-full transition-all duration-200 ${isSelected ? 'ring-4 ring-orange-500 bg-white/50' : 'bg-white/20 hover:bg-white/40'}`}
                title={avatar.name}
            >
                <avatar.component className="w-full h-auto" />
            </button>
            );
        })}
        </div>
    </div>
  );
};

export default AvatarSelector;