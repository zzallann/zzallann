import React, { useState, useEffect } from 'react';

const calculateNextTuesday = (): Date => {
    const now = new Date();
    const today = now.getDay(); // Sunday: 0, Monday: 1, ..., Tuesday: 2
    const targetDay = 2; // Tuesday

    const daysUntilNextTuesday = (targetDay - today + 7) % 7;
    
    const nextTuesday = new Date(now);
    nextTuesday.setDate(now.getDate() + daysUntilNextTuesday);
    nextTuesday.setHours(20, 0, 0, 0); // Set to Tuesday 20:00

    // If today is Tuesday and it's already past 20:00, we need the *next* week's Tuesday
    if (daysUntilNextTuesday === 0 && now.getTime() > nextTuesday.getTime()) {
        nextTuesday.setDate(nextTuesday.getDate() + 7);
    }

    return nextTuesday;
};

const calculateTimeLeft = () => {
    const difference = +calculateNextTuesday() - +new Date();
    let timeLeft = {
        days: 0,
        hours: 0,
        minutes: 0,
        seconds: 0
    };

    if (difference > 0) {
        timeLeft = {
            days: Math.floor(difference / (1000 * 60 * 60 * 24)),
            hours: Math.floor((difference / (1000 * 60 * 60)) % 24),
            minutes: Math.floor((difference / 1000 / 60) % 60),
            seconds: Math.floor((difference / 1000) % 60)
        };
    }

    return timeLeft;
};

const CountdownPage: React.FC = () => {
    const [timeLeft, setTimeLeft] = useState(calculateTimeLeft());

    useEffect(() => {
        const timer = setTimeout(() => {
            setTimeLeft(calculateTimeLeft());
        }, 1000);

        return () => clearTimeout(timer);
    });

    // FIX: Replaced `JSX.Element` with `React.ReactElement` to resolve a TypeScript error.
    const timerComponents: React.ReactElement[] = [];

    Object.keys(timeLeft).forEach((interval) => {
        const key = interval as keyof typeof timeLeft;
        if (timeLeft[key] === undefined) return;

        timerComponents.push(
            <div key={key} className="flex flex-col items-center">
                <span className="font-lilita text-5xl sm:text-7xl text-amber-300 tracking-wider">
                    {String(timeLeft[key]).padStart(2, '0')}
                </span>
                <span className="text-sm sm:text-base text-white/80 uppercase tracking-widest">
                    {key === 'days' ? 'Nap' : key === 'hours' ? 'Óra' : key === 'minutes' ? 'Perc' : 'Másodperc'}
                </span>
            </div>
        );
    });

    return (
        <div className="w-full max-w-2xl mx-auto animate-fade-in space-y-6">
            <div className="bg-white/10 dark:bg-slate-800/30 backdrop-blur-sm rounded-2xl shadow-lg p-8 sm:p-12 text-white text-center">
                <h1 className="text-3xl sm:text-4xl font-bold font-lilita tracking-wide mb-2">Határidő Visszaszámláló</h1>
                <p className="text-white/80 text-lg mb-8">A következő hét kedd estéjéig</p>
                <div className="flex justify-center gap-4 sm:gap-8">
                    {timerComponents.length ? timerComponents : <span>Lejárt az idő!</span>}
                </div>
            </div>
        </div>
    );
};

export default CountdownPage;
