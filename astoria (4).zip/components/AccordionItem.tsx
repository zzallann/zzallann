import React, { ReactNode } from 'react';
import ChevronDownIcon from './icons/ChevronDownIcon';

interface AccordionItemProps {
  title: string;
  isOpen: boolean;
  onClick: () => void;
  children: ReactNode;
}

const AccordionItem: React.FC<AccordionItemProps> = ({ title, isOpen, onClick, children }) => {
  return (
    <div className="border-b-2 border-white/20 last:border-b-0">
      <button
        onClick={onClick}
        className="w-full flex justify-between items-center p-4 text-left font-bold text-white text-lg focus:outline-none hover:bg-white/10 transition-colors"
      >
        <span>{title}</span>
        <ChevronDownIcon
          className={`w-5 h-5 transition-all duration-300 ${isOpen ? 'rotate-180 opacity-0' : 'rotate-0 opacity-100'}`}
        />
      </button>
      <div
        className={`overflow-hidden transition-all duration-300 ease-in-out ${isOpen ? 'max-h-96' : 'max-h-0'}`}
      >
        <div className="p-4 pt-0 text-white/90">
          {children}
        </div>
      </div>
    </div>
  );
};

export default AccordionItem;
