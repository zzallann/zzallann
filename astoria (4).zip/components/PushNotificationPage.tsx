import React, { useState, useEffect } from 'react';
import type { User } from '../types';
import { messageService } from '../services/messageService';
import { useNotification } from '../contexts/NotificationContext';
import SendIcon from './icons/SendIcon';

const PREDEFINED_MESSAGES = [
    'Sziasztok a mai napra nagyon kellene segítség, valaki tudna egy pár órát segíteni?',
    'Figyelem! Fontos megbeszélés lesz 15 perc múlva az irodában.',
    'Aki végzett a munkájával, kérem fáradjon be az irodába.',
    'Kérlek ellenőrizzétek a feladataitokat az applikációban, új kiosztások történtek.',
];

const TARGET_GROUPS: { id: 'normal' | 'pro' | 'pro_max'; label: string }[] = [
    { id: 'normal', label: 'Normál' },
    { id: 'pro', label: 'Pro' },
    { id: 'pro_max', label: 'Pro Max' },
];

interface PushNotificationPageProps {
    user: User;
    onNavigate: (view: string) => void;
}

const PushNotificationPage: React.FC<PushNotificationPageProps> = ({ user, onNavigate }) => {
    const [message, setMessage] = useState('');
    const [selectedGroups, setSelectedGroups] = useState<('normal' | 'pro' | 'pro_max')[]>([]);
    const [isSubmitting, setIsSubmitting] = useState(false);
    const { addNotification } = useNotification();

    useEffect(() => {
        if (user.status !== 'pro_max') {
            onNavigate('hirfolyam');
        }
    }, [user, onNavigate]);

    if (user.status !== 'pro_max') {
        return null;
    }

    const handleGroupToggle = (groupId: 'normal' | 'pro' | 'pro_max') => {
        setSelectedGroups(prev => 
            prev.includes(groupId) ? prev.filter(id => id !== groupId) : [...prev, groupId]
        );
    };

    const handleSelectAll = () => {
        if (selectedGroups.length === TARGET_GROUPS.length) {
            setSelectedGroups([]);
        } else {
            setSelectedGroups(TARGET_GROUPS.map(g => g.id));
        }
    };
    
    const handleSubmit = async (messageToSend: string) => {
        if (!messageToSend.trim()) {
            addNotification('Az üzenet nem lehet üres.', 'error');
            return;
        }
        if (selectedGroups.length === 0) {
            addNotification('Válassz ki legalább egy célcsoportot.', 'error');
            return;
        }

        setIsSubmitting(true);
        try {
            await messageService.sendBroadcastMessage(user, messageToSend, selectedGroups);
            addNotification('Körüzenet sikeresen elküldve!', 'success');
            setMessage('');
            setSelectedGroups([]);
            onNavigate('hirfolyam');
        } catch (error) {
            addNotification('Hiba az üzenet küldésekor.', 'error');
        } finally {
            setIsSubmitting(false);
        }
    };

    return (
        <div className="w-full max-w-2xl mx-auto animate-fade-in space-y-6 text-white">
            <h1 className="text-3xl font-bold font-lilita tracking-wide text-center">Push Üzenet Küldése</h1>

            <div className="bg-slate-800/40 backdrop-blur-sm p-6 rounded-2xl shadow-lg">
                <h2 className="text-xl font-bold font-lilita mb-2">Célcsoportok</h2>
                <div className="flex flex-wrap gap-3 mb-4">
                    <button onClick={handleSelectAll} className="px-4 py-2 text-sm font-bold bg-slate-600 rounded-full hover:bg-slate-500">
                        {selectedGroups.length === TARGET_GROUPS.length ? 'Összes törlése' : 'Összes kijelölése'}
                    </button>
                    {TARGET_GROUPS.map(group => (
                        <button
                            key={group.id}
                            onClick={() => handleGroupToggle(group.id)}
                            className={`px-4 py-2 text-sm font-bold rounded-full transition-colors ${selectedGroups.includes(group.id) ? 'bg-orange-600' : 'bg-slate-700 hover:bg-slate-600'}`}
                        >
                            {group.label}
                        </button>
                    ))}
                </div>

                <h2 className="text-xl font-bold font-lilita mt-6 mb-2">Egyéni üzenet</h2>
                <textarea
                    value={message}
                    onChange={(e) => setMessage(e.target.value)}
                    placeholder="Írd ide az üzeneted..."
                    className="w-full bg-slate-700 text-white placeholder-slate-400 p-3 rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500"
                    rows={4}
                    disabled={isSubmitting}
                />
                <button
                    onClick={() => handleSubmit(message)}
                    disabled={isSubmitting || !message.trim() || selectedGroups.length === 0}
                    className="w-full mt-2 flex items-center justify-center gap-2 px-4 py-3 bg-orange-600 font-bold rounded-full shadow-lg transform hover:scale-105 disabled:bg-slate-500 disabled:cursor-not-allowed"
                >
                    <SendIcon className="w-5 h-5" />
                    <span>Küldés</span>
                </button>
            </div>
            
             <div className="bg-slate-800/40 backdrop-blur-sm p-6 rounded-2xl shadow-lg">
                <h2 className="text-xl font-bold font-lilita mb-4">Sablon üzenetek</h2>
                <div className="space-y-3">
                    {PREDEFINED_MESSAGES.map((template, index) => (
                        <div key={index} className="flex flex-col sm:flex-row items-center gap-3 p-3 bg-slate-900/40 rounded-lg">
                            <p className="flex-1 text-sm text-white/90">{template}</p>
                            <button
                                onClick={() => handleSubmit(template)}
                                disabled={isSubmitting || selectedGroups.length === 0}
                                className="w-full sm:w-auto flex-shrink-0 flex items-center justify-center gap-2 px-4 py-2 bg-orange-600 font-bold rounded-full shadow-lg transform hover:scale-105 disabled:bg-slate-500 disabled:cursor-not-allowed"
                            >
                                <SendIcon className="w-5 h-5" />
                                <span>Küldés</span>
                            </button>
                        </div>
                    ))}
                </div>
            </div>
        </div>
    );
};

export default PushNotificationPage;