import React, { useState } from 'react';
import type { User } from '../types';
import { authService } from '../services/authService';
import { useNotification } from '../contexts/NotificationContext';
import SendIcon from './icons/SendIcon';

interface PasswordResetModalProps {
    user: User;
    onClose: () => void;
}

const PasswordResetModal: React.FC<PasswordResetModalProps> = ({ user, onClose }) => {
    const [newPassword, setNewPassword] = useState('');
    const [isLoading, setIsLoading] = useState(false);
    const { addNotification } = useNotification();

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        if (newPassword.length < 6) {
            addNotification('A jelszónak legalább 6 karakternek kell lennie.', 'error');
            return;
        }
        setIsLoading(true);
        try {
            await authService.adminResetPassword(user.id, newPassword);
            addNotification(`${user.name} jelszava sikeresen módosítva!`, 'success');
            onClose();
        } catch (err: any) {
            addNotification(err.message || 'Hiba történt.', 'error');
        } finally {
            setIsLoading(false);
        }
    };

    return (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex justify-center items-center z-50 animate-fade-in" onClick={onClose}>
            <div className="bg-slate-800 w-full max-w-sm rounded-2xl shadow-2xl p-6 text-white" onClick={e => e.stopPropagation()}>
                <h3 className="text-2xl font-bold font-lilita mb-4 text-center">Jelszó módosítása</h3>
                <p className="text-center mb-4">Felhasználó: <span className="font-bold">{user.name}</span></p>
                <form onSubmit={handleSubmit} className="space-y-4">
                    <div>
                        <label htmlFor="new-pass" className="block text-white font-semibold mb-1">Új jelszó</label>
                        <input
                            type="password"
                            id="new-pass"
                            value={newPassword}
                            onChange={(e) => setNewPassword(e.target.value)}
                            className="w-full px-4 py-2 bg-slate-700 text-white border-2 border-transparent rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500"
                            required
                            disabled={isLoading}
                        />
                    </div>
                    <button
                        type="submit"
                        disabled={isLoading}
                        className="w-full mt-4 flex items-center justify-center gap-2 px-4 py-3 bg-orange-600 font-bold rounded-full text-lg shadow-lg transform hover:scale-105 transition-transform disabled:bg-orange-400 disabled:scale-100"
                    >
                        <SendIcon className="w-5 h-5" />
                        <span>{isLoading ? 'Mentés...' : 'Mentés'}</span>
                    </button>
                    <button
                        type="button"
                        onClick={onClose}
                        className="w-full px-4 py-2 bg-slate-600/50 text-white/80 font-semibold rounded-full shadow-lg transform hover:scale-105 transition-transform"
                    >
                        Mégse
                    </button>
                </form>
            </div>
        </div>
    );
};

export default PasswordResetModal;