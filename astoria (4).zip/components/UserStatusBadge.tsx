import React from 'react';
import type { User } from '../types';

interface UserStatusBadgeProps {
  user: User;
}

const UserStatusBadge: React.FC<UserStatusBadgeProps> = ({ user }) => {
  const { status, identifier } = user;

  if (status === 'admin') {
     return (
      <span className="ml-2 text-xs font-bold uppercase border rounded px-1 text-red-400 border-red-400">
        Admin
      </span>
    );
  }

  if (status === 'pro' && identifier === '04') {
    return (
      <span className="ml-2 text-xs font-bold uppercase border rounded px-1 text-green-300 border-green-300">
        PRO Újságíró
      </span>
    );
  }

  if (!status || status === 'normal') {
    return null;
  }

  const proStyles = "text-blue-300 border-blue-300";
  const proMaxStyles = "text-amber-300 border-amber-300";
  const styles = status === 'pro' ? proStyles : proMaxStyles;

  return (
    <span className={`ml-2 text-xs font-bold uppercase border rounded px-1 ${styles}`}>
      {status === 'pro' ? 'Pro' : 'Pro Max'}
    </span>
  );
};

export default UserStatusBadge;