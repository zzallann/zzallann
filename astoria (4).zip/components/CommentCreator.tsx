import React, { useState, useRef, useEffect } from 'react';
import type { User } from '../types';
import { avatars } from './AvatarSelector';
import { authService } from '../services/authService';
import SendIcon from './icons/SendIcon';
import ImageIcon from './icons/ImageIcon';
import GifIcon from './icons/GifIcon';
import XCircleIcon from './icons/XCircleIcon';
import EmojiIcon from './icons/EmojiIcon';
import EmojiPicker from './EmojiPicker';

interface CommentCreatorProps {
    user: User;
    onAddComment: (content: string | null, imageFile: File | null, gifUrl: string | null) => Promise<void> | void;
}

const CommentCreator: React.FC<CommentCreatorProps> = ({ user, onAddComment }) => {
    const [content, setContent] = useState('');
    const [imageFile, setImageFile] = useState<File | null>(null);
    const [gifUrl, setGifUrl] = useState<string | null>(null);
    const [showGifInput, setShowGifInput] = useState(false);
    const [isSubmitting, setIsSubmitting] = useState(false);
    const [showEmojiPicker, setShowEmojiPicker] = useState(false);
    
    // For mentions
    const [mentionQuery, setMentionQuery] = useState('');
    const [showMentions, setShowMentions] = useState(false);
    const [allUsers, setAllUsers] = useState<User[]>([]);

    const imageInputRef = useRef<HTMLInputElement>(null);
    const textareaRef = useRef<HTMLTextAreaElement>(null);
    const selectedAvatar = avatars.find((a) => a.id === user.avatarId);

    useEffect(() => {
        const users = authService.getAllUsers().filter(u => u.id !== user.id);
        setAllUsers(users);
    }, [user.id]);
    
    const handleContentChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
        const text = e.target.value;
        setContent(text);

        const mentionMatch = text.match(/@(\w*)$/);
        if (mentionMatch) {
            setMentionQuery(mentionMatch[1]);
            setShowMentions(true);
        } else {
            setShowMentions(false);
        }
    };

    const handleSelectMention = (name: string) => {
        setContent(prev => prev.replace(/@\w*$/, `@${name} `));
        setShowMentions(false);
    };

    const handleEmojiSelect = (emoji: string) => {
        const textarea = textareaRef.current;
        if (textarea) {
            const start = textarea.selectionStart;
            const end = textarea.selectionEnd;
            const newContent = content.substring(0, start) + emoji + content.substring(end);
            setContent(newContent);
            setTimeout(() => {
                textarea.selectionStart = textarea.selectionEnd = start + emoji.length;
                textarea.focus();
            }, 0);
        }
    };

    const filteredUsers = mentionQuery
        ? allUsers.filter(u => u.name.toLowerCase().startsWith(mentionQuery.toLowerCase()))
        : [];


    const clearAttachments = () => {
        setImageFile(null);
        setGifUrl(null);
        setShowGifInput(false);
        if (imageInputRef.current) imageInputRef.current.value = '';
    };

    const handleSubmit = async () => {
        if (!content.trim() && !imageFile && !gifUrl) return;

        setIsSubmitting(true);
        await onAddComment(content.trim() || null, imageFile, gifUrl);
        
        setContent('');
        clearAttachments();
        setIsSubmitting(false);
    };

    const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        const file = e.target.files?.[0];
        if (file) {
            clearAttachments();
            setImageFile(file);
        }
    };

    const handleGifUrlChange = (url: string) => {
        clearAttachments();
        setGifUrl(url);
    };

    const canSubmit = content.trim() || imageFile || gifUrl;

    return (
        <div className="relative">
            {showMentions && filteredUsers.length > 0 && (
                <div className="absolute bottom-full left-0 right-0 bg-slate-700 border border-slate-600 rounded-lg shadow-lg mb-2 max-h-40 overflow-y-auto z-10">
                    {filteredUsers.map(u => (
                        <button
                            key={u.id}
                            onClick={() => handleSelectMention(u.name)}
                            className="w-full text-left p-2 hover:bg-slate-600 text-white"
                        >
                            {u.name}
                        </button>
                    ))}
                </div>
            )}
             <div className="bg-slate-800/60 p-2 rounded-xl">
                 {(imageFile || gifUrl) && (
                    <div className="p-2 relative w-fit">
                        <img src={imageFile ? URL.createObjectURL(imageFile) : gifUrl!} alt="Preview" className="max-h-24 rounded-lg"/>
                        <button onClick={clearAttachments} className="absolute -top-1 -right-1 bg-black/70 text-white rounded-full">
                            <XCircleIcon className="w-5 h-5"/>
                        </button>
                    </div>
                 )}
                 {showGifInput && (
                    <div className="p-2">
                        <input
                            type="url"
                            placeholder="GIF URL beillesztése..."
                            onChange={(e) => handleGifUrlChange(e.target.value)}
                            className="w-full bg-slate-700 text-white placeholder-slate-400 p-2 rounded-full focus:outline-none focus:ring-2 focus:ring-orange-500"
                            autoFocus
                        />
                    </div>
                 )}
                <div className="flex gap-2">
                    <div className="w-10 h-10 rounded-full overflow-hidden flex-shrink-0 bg-slate-700/50">
                        {user.uploadedImage ? <img src={user.uploadedImage} alt="Avatar" className="w-full h-full object-cover" /> : selectedAvatar ? <selectedAvatar.component /> : null}
                    </div>
                    <div className="flex-1 flex items-center gap-1 bg-slate-700 rounded-full">
                        <textarea
                            ref={textareaRef}
                            value={content}
                            onChange={handleContentChange}
                            placeholder="Írj kommentet..."
                            className="w-full bg-transparent text-white placeholder-slate-400 p-2 px-4 rounded-full focus:outline-none resize-none"
                            rows={1}
                            disabled={isSubmitting}
                            onKeyPress={(e) => {
                                if (e.key === 'Enter' && !e.shiftKey) {
                                    e.preventDefault();
                                    handleSubmit();
                                }
                            }}
                        />
                        <input type="file" accept="image/*" ref={imageInputRef} onChange={handleFileChange} className="hidden" />
                        <button onClick={() => imageInputRef.current?.click()} disabled={isSubmitting || !!gifUrl} className="p-2 text-white/70 rounded-full hover:bg-slate-600 disabled:opacity-50"><ImageIcon className="w-5 h-5"/></button>
                        <button onClick={() => setShowGifInput(v => !v)} disabled={isSubmitting || !!imageFile} className="p-2 text-white/70 rounded-full hover:bg-slate-600 disabled:opacity-50"><GifIcon className="w-5 h-5"/></button>
                        <div className="relative">
                            <button onClick={() => setShowEmojiPicker(v => !v)} disabled={isSubmitting} className="p-2 text-white/70 rounded-full hover:bg-slate-600">
                                <EmojiIcon className="w-5 h-5"/>
                            </button>
                            {showEmojiPicker && (
                                <>
                                    <div className="fixed inset-0 z-40" onClick={() => setShowEmojiPicker(false)}></div>
                                    <div className="absolute bottom-full right-0 mb-2 z-50">
                                        <EmojiPicker onSelectEmoji={handleEmojiSelect} />
                                    </div>
                                </>
                            )}
                        </div>
                        <button onClick={handleSubmit} disabled={isSubmitting || !canSubmit} className="p-2 mr-1 bg-orange-600 text-white rounded-full disabled:bg-slate-500"><SendIcon className="w-5 h-5"/></button>
                    </div>
                </div>
             </div>
        </div>
    );
};

export default CommentCreator;