import React, { useState, useEffect, useMemo, useCallback } from 'react';
import type { User, WeeklySchedule, ParsedScheduleItem, ProMaxScheduleData, ProMaxDailySchedule } from '../types';
import { scheduleService } from '../services/scheduleService';
import { messageService } from '../services/messageService';
import { authService } from '../services/authService';
import { useNotification } from '../contexts/NotificationContext';
import ChevronLeftIcon from './icons/ChevronLeftIcon';
import ChevronRightIcon from './icons/ChevronRightIcon';
import ImageIcon from './icons/ImageIcon';
import SendIcon from './icons/SendIcon';
import PencilIcon from './icons/PencilIcon';
import SaveIcon from './icons/SaveIcon';
import ClockIcon from './icons/ClockIcon';
import ArrowLeftIcon from './icons/ArrowLeftIcon';
import UserAvatarWithStatus from './UserAvatarWithStatus';
import XCircleIcon from './icons/XCircleIcon';
import SearchIcon from './icons/SearchIcon';


// Helper functions
const getWeekId = (date: Date): string => {
    const d = new Date(Date.UTC(date.getFullYear(), date.getMonth(), date.getDate()));
    d.setUTCDate(d.getUTCDate() + 4 - (d.getUTCDay() || 7));
    const yearStart = new Date(Date.UTC(d.getUTCFullYear(), 0, 1));
    const weekNo = Math.ceil((((d.getTime() - yearStart.getTime()) / 86400000) + 1) / 7);
    return `${d.getUTCFullYear()}-${weekNo}`;
};

const getWeekDateRange = (date: Date): string => {
    const d = new Date(date);
    const day = d.getDay();
    const diff = d.getDate() - day + (day === 0 ? -6 : 1);
    const monday = new Date(d.setDate(diff));
    const sunday = new Date(monday);
    sunday.setDate(monday.getDate() + 6);
    const options: Intl.DateTimeFormatOptions = { month: 'long', day: 'numeric' };
    return `${monday.toLocaleDateString('hu-HU', options)} - ${sunday.toLocaleDateString('hu-HU', options)}`;
};

const getDaysOfWeek = (date: Date): { short: string; long: string; fullDate: string }[] => {
    const d = new Date(date);
    const day = d.getDay();
    const diff = d.getDate() - day + (day === 0 ? -6 : 1);
    const monday = new Date(d.setDate(diff));
    const days = [];
    for (let i = 0; i < 7; i++) {
        const current = new Date(monday);
        current.setDate(monday.getDate() + i);
        days.push({
            short: current.toLocaleDateString('hu-HU', { weekday: 'short' }),
            long: current.toLocaleDateString('hu-HU', { weekday: 'long' }),
            fullDate: current.toISOString().split('T')[0]
        });
    }
    return days;
};

const parseScheduleText = (text: string | null, users: User[]): ParsedScheduleItem[] => {
    if (!text) return [];
    const userMapByIdentifier = new Map(users.map(u => [u.identifier, u]));
    const result: ParsedScheduleItem[] = [];
    const blocks = text.split('---').map(b => b.trim()).filter(Boolean);

    for (const block of blocks) {
        const lines = block.split('\n').map(l => l.trim()).filter(Boolean);
        if (lines.length === 0) continue;

        const header = lines.shift() || '';
        const nameMatch = header.match(/^(.*?)\s*\((.*?)\)$/);
        let foundUser: User | undefined;
        if (nameMatch) {
            const identifier = nameMatch[2].trim();
            foundUser = userMapByIdentifier.get(identifier);
        }

        if (foundUser) {
            const schedule: Record<string, string> = {};
            lines.forEach(line => {
                const parts = line.split(':');
                if (parts.length >= 2) {
                    const day = parts[0].trim().toLowerCase();
                    const task = parts.slice(1).join(':').trim();
                    schedule[day] = task;
                }
            });

            result.push({
                userId: foundUser.id,
                name: foundUser.name,
                identifier: foundUser.identifier,
                schedule: schedule
            });
        }
    }
    return result.sort((a, b) => a.name.localeCompare(b.name));
};


const HetiBeosztasPage: React.FC<{ user: User }> = ({ user }) => {
    const [currentDate, setCurrentDate] = useState(new Date());
    const [schedule, setSchedule] = useState<WeeklySchedule | null>(null);
    const [allUsers, setAllUsers] = useState<User[]>([]);
    const [isLoading, setIsLoading] = useState(true);
    
    const [viewMode, setViewMode] = useState<'view' | 'create' | 'edit_max'>('view');
    const [isEditingSchedule, setIsEditingSchedule] = useState(false);
    
    const [pastedText, setPastedText] = useState('');
    const [parsedTable, setParsedTable] = useState<string[][] | null>(null);
    const [isProcessing, setIsProcessing] = useState(false);
    
    const [editedSchedules, setEditedSchedules] = useState<Record<string, Record<string, string>>>({});
    const [editingUser, setEditingUser] = useState<ParsedScheduleItem | null>(null);

    const [proMaxSchedules, setProMaxSchedules] = useState<ProMaxScheduleData>({});
    const [isEditingMax, setIsEditingMax] = useState(false);
    
    const [latenessModal, setLatenessModal] = useState<{ day: string; date: string } | null>(null);
    const [latenessMinutes, setLatenessMinutes] = useState('15');
    const [latenessMessage, setLatenessMessage] = useState('');

    const [modificationModal, setModificationModal] = useState<{ day: string; date: string } | null>(null);
    const [modificationMessage, setModificationMessage] = useState('');
    
    const [searchTerm, setSearchTerm] = useState('');

    const { addNotification } = useNotification();
    const weekId = useMemo(() => getWeekId(currentDate), [currentDate]);

    const fetchData = useCallback(async () => {
        setIsLoading(true);
        try {
            const [scheduleData, usersData] = await Promise.all([
                scheduleService.getScheduleForWeek(weekId),
                authService.getAllUsers()
            ]);
            setAllUsers(usersData);
            setSchedule(scheduleData);
            
            if (scheduleData?.proMaxScheduleText) {
                try {
                    const parsed = JSON.parse(scheduleData.proMaxScheduleText) as ProMaxScheduleData;
                    if (typeof parsed === 'object' && parsed !== null) {
                        setProMaxSchedules(parsed);
                    } else {
                        setProMaxSchedules({});
                    }
                } catch { 
                    setProMaxSchedules({}); 
                }
            } else {
                setProMaxSchedules({});
            }
            
            const parsedItems = parseScheduleText(scheduleData?.text || null, usersData);
            const initialEdits: Record<string, Record<string, string>> = {};
            parsedItems.forEach(p => { initialEdits[p.userId] = p.schedule; });
            setEditedSchedules(initialEdits);

            if (!scheduleData || (!scheduleData.text && !scheduleData.imageUrl)) {
                setViewMode('create');
            } else {
                setViewMode('view');
                setIsEditingSchedule(false);
            }

        } catch (error) {
            addNotification("Hiba a beosztás betöltésekor.", "error");
        } finally {
            setIsLoading(false);
        }
    }, [weekId, addNotification]);

    useEffect(() => {
        fetchData();
    }, [fetchData]);

    const weeklyHours: Record<string, number> = useMemo(() => {
        if (user.status !== 'pro_max') return {};
        
        const hours: Record<string, number> = {};
        allUsers.forEach(u => {
            const userSchedule = editedSchedules[u.id];
            if (userSchedule) {
                const userHours = (Object.values(userSchedule) as string[]).reduce((totalHours: number, task: string) => {
                    const timeMatch = task.match(/(\d{1,2}):(\d{2})-(\d{1,2}):(\d{2})/);
                    if (timeMatch) {
                        let [, startHour, startMin, endHour, endMin] = timeMatch.map(Number);
                        if (endHour < startHour) endHour += 24;
                        const duration = (endHour * 60 + endMin - (startHour * 60 + startMin)) / 60;
                        return totalHours + duration;
                    }
                    return totalHours;
                }, 0);
                hours[u.id] = userHours;
            }
        });
        return hours;
    }, [editedSchedules, allUsers, user.status]);
    
    const handlePastedText = (text: string) => {
        setPastedText(text);
        const table = text.split('\n').map(row => row.split('\t'));
        setParsedTable(table);
    };

    const handleProcessPastedText = () => {
        if (!parsedTable) return;
        setIsProcessing(true);
        try {
            const dayNames = ['hétfő', 'kedd', 'szerda', 'csütörtök', 'péntek', 'szombat', 'vasárnap'];
            let dateRowIndex = -1;
            let maxScore = 0;
            parsedTable.forEach((row, index) => {
                const score = row.reduce((acc, cell) => dayNames.some(day => cell.toLowerCase().includes(day)) ? acc + 1 : acc, 0);
                if (score > maxScore) { maxScore = score; dateRowIndex = index; }
            });

            if (dateRowIndex === -1 || maxScore < 2) throw new Error("Nem található érvényes dátumsor.");
            
            const dateRow = parsedTable[dateRowIndex];
            const colToDayMap: Record<number, string> = {};
            let currentDay = '';
            dateRow.forEach((cell, index) => {
                const lowerCell = cell.toLowerCase();
                const foundDay = dayNames.find(day => lowerCell.includes(day));
                if (foundDay) currentDay = foundDay;
                if (currentDay) colToDayMap[index] = currentDay;
            });

            const newSchedules: Record<string, Record<string, string>> = {};
            const registeredUsersByIdentifier: Map<string, User> = new Map(allUsers.map(u => [u.identifier, u]));

            parsedTable.forEach((row, rowIndex) => {
                if (rowIndex <= dateRowIndex) return;
                
                const identifierCell = row.find(cell => registeredUsersByIdentifier.has(cell.trim()));
                const foundUser = identifierCell ? registeredUsersByIdentifier.get(identifierCell.trim()) as User : undefined;
                
                if (foundUser && foundUser.status !== 'pro_max') {
                    const dailyTasks: Record<string, string[]> = {};
                    row.forEach((cell, colIndex) => {
                        const dayName = colToDayMap[colIndex];
                        if (dayName && cell.trim()) {
                            if (!dailyTasks[dayName]) dailyTasks[dayName] = [];
                            dailyTasks[dayName].push(cell.trim());
                        }
                    });

                    const userSchedule: Record<string, string> = {};
                    for (const day in dailyTasks) {
                        const parts = dailyTasks[day].filter((p: string) => p.toLowerCase() !== day && !dayNames.some(dn => p.toLowerCase().includes(dn)) && !registeredUsersByIdentifier.has(p.trim()));
                        if (parts.length > 1 && parts.some(p => p.includes(':'))) {
                            const mainTask = parts.find(p => !p.includes(':')) || 'Munka';
                            const times = parts.filter(p => p.includes(':'));
                            userSchedule[day] = `${mainTask} ${times.join('-')}`;
                        } else {
                            userSchedule[day] = parts.join(' ');
                        }
                    }
                    if (Object.keys(userSchedule).length > 0) newSchedules[foundUser.id] = userSchedule;
                }
            });

            if (Object.keys(newSchedules).length === 0) throw new Error("Nem sikerült regisztrált felhasználókhoz beosztást rendelni.");
            
            setEditedSchedules(newSchedules);
            setPastedText('');
            setParsedTable(null);
            setIsEditingSchedule(true);
            setViewMode('view');
            addNotification("Feldolgozás sikeres! Mentsd el a változtatásokat.", "success");

        } catch (e: any) { addNotification(e.message, "error"); } 
        finally { setIsProcessing(false); }
    };
    
    const handleWeekChange = (direction: 'prev' | 'next') => {
        const today = new Date();
        const minDate = new Date(today.getFullYear(), today.getMonth() - 5, 1);
        const maxDate = new Date(today.getFullYear(), today.getMonth() + 3, 1);

        setCurrentDate(prev => {
            const newDate = new Date(prev);
            newDate.setDate(newDate.getDate() + (direction === 'prev' ? -7 : 7));
            if ((direction === 'prev' && newDate < minDate) || (direction === 'next' && newDate > maxDate)) return prev;
            return newDate;
        });
    };

    const handleSaveEdits = async () => {
        setIsProcessing(true);
        const isNewSchedule = !schedule?.text;
        
        let newScheduleText = '';
        const changedUserIds: string[] = [];
        const newUserIds: string[] = Object.keys(editedSchedules);
        const originalSchedules = parseScheduleText(schedule?.text || null, allUsers);
        
        Object.entries(editedSchedules).forEach(([userId, newSchedule]) => {
            const user = allUsers.find(u => u.id === userId);
            if(user) {
                newScheduleText += `${user.name} (${user.identifier})\n`;
                Object.entries(newSchedule).forEach(([day, task]) => { newScheduleText += `${day}: ${task}\n`; });
                newScheduleText += '---\n';

                const original = originalSchedules.find(s => s.userId === userId)?.schedule;
                if(JSON.stringify(original) !== JSON.stringify(newSchedule)) {
                    changedUserIds.push(userId);
                }
            }
        });
        
        try {
            await scheduleService.uploadSchedule(user, weekId, newScheduleText, schedule?.imageUrl, schedule?.gifUrl, schedule?.proMaxScheduleText);
            
            if (isNewSchedule) {
                await messageService.sendNewScheduleNotification(newUserIds, user.name, weekId);
            } else if (changedUserIds.length > 0) {
                await Promise.all(changedUserIds.map(uid => messageService.sendScheduleUpdateNotification(uid, user.name, weekId)));
            }

            addNotification("Módosítások mentve!", "success");
            setIsEditingSchedule(false);
            await fetchData();
        } catch (error: any) {
            addNotification(error.message || "Hiba mentés közben.", "error");
        } finally {
            setIsProcessing(false);
        }
    };
    
    const handleSaveMaxSchedule = async () => {
        setIsProcessing(true);
        try {
            await scheduleService.uploadSchedule(user, weekId, schedule?.text, schedule?.imageUrl, schedule?.gifUrl, JSON.stringify(proMaxSchedules));
            await messageService.sendProMaxScheduleUpdateNotification(user.name, weekId);
            addNotification("Max beosztás mentve!", "success");
            setViewMode('view');
            setIsEditingMax(false);
            await fetchData();
        } catch (error: any) {
            addNotification(error.message || "Hiba mentés közben.", "error");
        } finally {
            setIsProcessing(false);
        }
    };
    
    const handleReplaceSchedule = async () => {
        if(window.confirm("Biztosan lecseréled a teljes heti beosztást? Ez a művelet nem vonható vissza.")) {
            await scheduleService.uploadSchedule(user, weekId, null, null, null, schedule?.proMaxScheduleText);
            setPastedText('');
            setParsedTable(null);
            await fetchData();
        }
    };
    
    const handleSendLateness = async () => {
        if (!latenessModal) return;
        setIsProcessing(true);
        try {
            await messageService.sendLatenessReport(user, parseInt(latenessMinutes, 10), latenessMessage, latenessModal.day, latenessModal.date);
            addNotification("Késés jelentve.", "success");
            setLatenessModal(null);
            setLatenessMessage('');
        } catch (err) { addNotification("Hiba a küldés során.", "error"); }
        finally { setIsProcessing(false); }
    };
    
    const handleSendModification = async () => {
        if (!modificationModal) return;
        setIsProcessing(true);
        try {
            await messageService.sendModificationRequest(user, modificationMessage, modificationModal.day, modificationModal.date);
            addNotification("Kérelem elküldve.", "success");
            setModificationModal(null);
            setModificationMessage('');
        } catch (err) { addNotification("Hiba a küldés során.", "error"); }
        finally { setIsProcessing(false); }
    };

    const parsedScheduleItems = useMemo(() => {
         return allUsers
            .filter(u => u.status !== 'pro_max' && editedSchedules[u.id])
            .map(u => ({
                userId: u.id, name: u.name, identifier: u.identifier,
                schedule: editedSchedules[u.id] || {}
            }))
            .sort((a,b) => a.name.localeCompare(b.name));
    }, [editedSchedules, allUsers]);
    
    const filteredScheduleItems = useMemo(() => {
        if (!searchTerm.trim()) {
            return parsedScheduleItems;
        }
        const lowerCaseSearchTerm = searchTerm.toLowerCase();
        return parsedScheduleItems.filter(item => 
            item.name.toLowerCase().includes(lowerCaseSearchTerm) || 
            item.identifier.toLowerCase().includes(lowerCaseSearchTerm)
        );
    }, [parsedScheduleItems, searchTerm]);
    
    const dailyGroupedSchedules = useMemo(() => {
        const proMaxUsers = allUsers.filter(u => u.status === 'pro_max');
        const weekDays = getDaysOfWeek(currentDate);

        const grouped: Record<string, { user: User; schedule: string; note: string }[]> = {};
        const validSchedules = (typeof proMaxSchedules === 'object' && proMaxSchedules !== null) ? proMaxSchedules : {};
        
        weekDays.forEach(day => {
            grouped[day.long] = [];
            proMaxUsers.forEach(pmUser => {
                const userSchedule = (validSchedules[pmUser.id] as Record<string, ProMaxDailySchedule> | undefined);
                const daySchedule = userSchedule ? userSchedule[day.fullDate] : undefined;

                if (daySchedule && 'schedule' in daySchedule && daySchedule.schedule) {
                    const scheduleItem = daySchedule as ProMaxDailySchedule;
                     grouped[day.long].push({ user: pmUser, schedule: scheduleItem.schedule, note: scheduleItem.note });
                }
            });
        });

        const parseStartTime = (schedule: string): number => {
            if (!schedule) return 99; // Sort empty schedules last
            const timePart = schedule.split('-')[0].trim();
            const hourPart = timePart.split(':')[0];
            const hour = parseInt(hourPart, 10);
            return isNaN(hour) ? 99 : hour;
        };

        for (const day in grouped) {
            grouped[day].sort((a, b) => parseStartTime(a.schedule) - parseStartTime(b.schedule));
        }

        return grouped;
    }, [proMaxSchedules, allUsers, currentDate]);

    if (isLoading) return <div className="text-center text-white">Betöltés...</div>;
    
    const Header = () => (
        <div className="flex justify-between items-center">
            <h1 className="text-3xl font-bold font-lilita">Heti Beosztás</h1>
            {user.status === 'pro_max' && <button onClick={() => setViewMode('edit_max')} className="px-4 py-2 text-sm bg-amber-600 font-bold rounded-full">Max Beosztás</button>}
        </div>
    );
    
    if (viewMode === 'edit_max') {
        const proMaxUsers = allUsers.filter(u => u.status === 'pro_max');
        const weekDays = getDaysOfWeek(currentDate);

        return (
             <div className="w-full max-w-2xl mx-auto animate-fade-in space-y-6 text-white">
                <div className="flex items-center gap-4">
                    <button onClick={() => { setViewMode('view'); setIsEditingMax(false); }} className="p-2 rounded-full hover:bg-white/10"><ArrowLeftIcon className="w-6 h-6"/></button>
                    <h1 className="text-3xl font-bold font-lilita">Max Beosztás</h1>
                    <button onClick={() => setIsEditingMax(p => !p)} className="ml-auto px-4 py-2 text-sm bg-blue-600 font-bold rounded-full">{isEditingMax ? 'Megtekintés' : 'Szerkesztés'}</button>
                </div>
                <div className="bg-slate-800/40 backdrop-blur-sm p-4 sm:p-6 rounded-2xl">
                    <div className="flex justify-between items-center mb-4">
                        <button onClick={() => handleWeekChange('prev')}><ChevronLeftIcon className="w-8 h-8"/></button>
                        <div className="text-center"><h2 className="text-xl font-bold font-lilita">{weekId}. hét</h2><p className="text-sm text-white/70">{getWeekDateRange(currentDate)}</p></div>
                        <button onClick={() => handleWeekChange('next')}><ChevronRightIcon className="w-8 h-8"/></button>
                    </div>
                    {isEditingMax ? (
                        <div className="space-y-4">
                            {proMaxUsers.map(pmUser => (
                                <div key={pmUser.id} className="bg-slate-900/50 p-3 rounded-lg">
                                    <p className="font-bold mb-2">{pmUser.name}</p>
                                    <div className="space-y-2">
                                        {weekDays.map(day => (
                                            <div key={day.fullDate} className="grid grid-cols-1 sm:grid-cols-3 gap-2 items-center">
                                                <span className="text-sm font-semibold capitalize">{day.long}</span>
                                                <input type="text" placeholder="Beosztás" value={proMaxSchedules[pmUser.id]?.[day.fullDate]?.schedule || ''} onChange={e => setProMaxSchedules(s => ({...s, [pmUser.id]: {...(s[pmUser.id] || {}), [day.fullDate]: {...(s[pmUser.id]?.[day.fullDate] || {note:''}), schedule: e.target.value}}}))} className="col-span-2 sm:col-span-1 bg-slate-700 p-1 rounded-md text-sm" />
                                                <textarea placeholder="Megjegyzés (opcionális)" value={proMaxSchedules[pmUser.id]?.[day.fullDate]?.note || ''} onChange={e => setProMaxSchedules(s => ({...s, [pmUser.id]: {...(s[pmUser.id] || {}), [day.fullDate]: {...(s[pmUser.id]?.[day.fullDate] || {schedule:''}), note: e.target.value}}}))} className="col-span-3 sm:col-span-1 bg-slate-700 p-1 rounded-md text-xs resize-none" rows={1}/>
                                            </div>
                                        ))}
                                    </div>
                                </div>
                            ))}
                             <button onClick={handleSaveMaxSchedule} disabled={isProcessing} className="w-full mt-6 flex items-center justify-center gap-2 px-4 py-2 bg-green-600 font-bold rounded-full disabled:bg-slate-500"><SaveIcon className="w-5 h-5"/> {isProcessing ? 'Mentés...' : 'Mentés'}</button>
                        </div>
                    ) : (
                        <div className="space-y-4">
                            {Object.keys(dailyGroupedSchedules).map((day) => {
                                const schedules = dailyGroupedSchedules[day];
                                return (
                                <div key={day}>
                                    <h3 className="font-bold text-lg capitalize mb-2 border-b border-white/20 pb-1">{day}</h3>
                                    {schedules.length > 0 ? schedules.map(({user: pmUser, schedule, note}) => (
                                        <div key={pmUser.id} className="p-2 bg-slate-900/40 rounded-lg mb-2">
                                            <div className="flex justify-between items-center">
                                                <span className="font-semibold">{pmUser.name}</span>
                                                <span className="text-amber-300">{schedule}</span>
                                            </div>
                                            {note && <p className="text-xs text-white/70 italic mt-1 pl-2 border-l-2 border-slate-600">{note}</p>}
                                        </div>
                                    )) : <p className="text-sm text-white/60 text-center">Nincs beosztás erre a napra.</p>}
                                </div>
                                );
                            })}
                        </div>
                    )}
                </div>
            </div>
        );
    }
    
    if (user.status === 'pro_max') {
        return (
            <div className="w-full max-w-2xl mx-auto animate-fade-in space-y-6 text-white">
                 <Header />
                 <div className="bg-slate-800/40 backdrop-blur-sm p-4 sm:p-6 rounded-2xl shadow-lg">
                    <div className="flex justify-between items-center mb-4"><button onClick={() => handleWeekChange('prev')} disabled={isEditingSchedule}><ChevronLeftIcon className="w-8 h-8"/></button><div className="text-center"><h2 className="text-xl font-bold font-lilita">{weekId}. hét</h2><p className="text-sm text-white/70">{getWeekDateRange(currentDate)}</p></div><button onClick={() => handleWeekChange('next')} disabled={isEditingSchedule}><ChevronRightIcon className="w-8 h-8"/></button></div>
                    
                    {viewMode === 'create' ? (
                        <div className="space-y-4">
                            <textarea value={pastedText} onChange={e => handlePastedText(e.target.value)} rows={8} className="w-full bg-slate-700 p-2 rounded-lg" placeholder="Illeszd be a szöveget az Excelből..."/>
                            {parsedTable && (
                                <div className="overflow-x-auto bg-slate-900/50 p-2 rounded-lg">
                                <table className="w-full text-xs text-left border-collapse"><tbody>{parsedTable.map((row, i) => (<tr key={i} className="border-b border-slate-700">{row.map((cell, j) => (<td key={j} className="p-1 whitespace-nowrap">{cell}</td>))}</tr>))}</tbody></table>
                                </div>
                            )}
                            {parsedTable && <button onClick={handleProcessPastedText} disabled={isProcessing} className="w-full py-2 bg-orange-600 font-bold rounded-full">{isProcessing ? 'Feldolgozás...' : 'Beosztás Feldolgozása'}</button>}
                        </div>
                    ) : (
                        <div>
                            <div className="flex gap-4 justify-center mb-4">
                                <button onClick={() => setIsEditingSchedule(p => !p)} className="flex items-center gap-2 px-4 py-2 bg-blue-600 font-bold rounded-full"><PencilIcon className="w-5 h-5"/> {isEditingSchedule ? 'Megtekintés Mód' : 'Szerkesztés'}</button>
                                <button onClick={handleReplaceSchedule} className="px-4 py-2 bg-red-600 font-bold rounded-full">Csere</button>
                            </div>
                            
                            {isEditingSchedule && <button onClick={handleSaveEdits} disabled={isProcessing} className="w-full mb-4 flex items-center justify-center gap-2 px-4 py-2 bg-green-600 font-bold disabled:bg-slate-500"><SaveIcon className="w-5 h-5"/>{isProcessing ? 'Mentés...' : 'Változtatások Mentése'}</button>}
                            
                             <div className="relative mb-4">
                                <span className="absolute left-4 top-1/2 -translate-y-1/2">
                                    <SearchIcon className="w-5 h-5 text-slate-400"/>
                                </span>
                                <input
                                    type="text"
                                    placeholder="Keresés név vagy azonosító alapján..."
                                    value={searchTerm}
                                    onChange={(e) => setSearchTerm(e.target.value)}
                                    className="w-full bg-slate-700/50 text-white pl-12 pr-4 py-3 rounded-full text-sm focus:ring-2 focus:ring-orange-500 outline-none"
                                />
                            </div>

                            <div className="space-y-3">
                                {filteredScheduleItems.length > 0 ? filteredScheduleItems.map(item => {
                                    const userForAvatar = allUsers.find(u => u.id === item.userId);
                                    if (!userForAvatar) return null;
                                    return(
                                    <div key={item.userId} className="p-3 bg-slate-900/40 rounded-lg">
                                        <div className="flex justify-between items-start">
                                            <div className="flex items-center gap-3">
                                                <UserAvatarWithStatus user={userForAvatar} size="small" />
                                                <div>
                                                    <p className="font-bold">{item.name} <span className="text-xs text-white/70">(Azonosító: {item.identifier})</span></p>
                                                </div>
                                            </div>
                                            <div className="text-right flex items-center gap-2">
                                                <p className="font-bold text-amber-300 text-sm">Heti: {weeklyHours[item.userId]?.toFixed(2) || '0.00'} óra</p>
                                                {isEditingSchedule && (<button onClick={() => setEditingUser(item)} className="p-2 -mr-2 rounded-full hover:bg-slate-700"><PencilIcon className="w-5 h-5"/></button>)}
                                            </div>
                                        </div>
                                        <div className="text-sm mt-2 space-y-1">{Object.entries(item.schedule).map(([day, task]) => (<div key={day} className="flex justify-between p-1 bg-slate-800/50 rounded"><span className="capitalize font-semibold">{day}</span><span>{task}</span></div>))}</div>
                                    </div>
                                )}) : <p className="text-center text-white/70 py-4">{searchTerm ? 'Nincs a keresésnek megfelelő beosztás.' : 'Nincs beosztás ehhez a héthez.'}</p>}
                            </div>
                            {schedule?.imageUrl && <img src={schedule.imageUrl} alt="Beosztás" className="w-full rounded-lg mt-4"/>}
                        </div>
                    )}
                 </div>

                 {editingUser && (
                     <div className="fixed inset-0 bg-black/70 flex justify-center items-center z-50" onClick={() => setEditingUser(null)}>
                         <div className="bg-slate-800 p-6 rounded-lg w-full max-w-md" onClick={e => e.stopPropagation()}>
                            <h3 className="font-bold text-lg mb-4">Szerkesztés: {editingUser.name}</h3>
                            <div className="space-y-2">
                                {getDaysOfWeek(currentDate).map(day => (
                                    <div key={day.fullDate} className="flex items-center gap-2">
                                        <label className="w-24 capitalize">{day.long}</label>
                                        <input
                                            type="text"
                                            value={editedSchedules[editingUser.userId]?.[day.long.toLowerCase()] || ''}
                                            onChange={(e) => {
                                                setEditedSchedules(prev => ({
                                                    ...prev,
                                                    [editingUser.userId]: {
                                                        ...(prev[editingUser.userId] || {}),
                                                        [day.long.toLowerCase()]: e.target.value
                                                    }
                                                }));
                                            }}
                                            className="w-full bg-slate-700 p-2 rounded-md"
                                        />
                                    </div>
                                ))}
                            </div>
                            <button onClick={() => setEditingUser(null)} className="mt-4 px-4 py-2 bg-orange-600 rounded-full w-full">Bezárás</button>
                         </div>
                     </div>
                 )}
            </div>
        );
    }
    
    // Normal / Pro user view
    const mySchedule = parsedScheduleItems.find(p => p.userId === user.id);
    const weekDays = getDaysOfWeek(currentDate);

    return (
        <div className="w-full max-w-2xl mx-auto animate-fade-in space-y-6 text-white">
             <h1 className="text-3xl font-bold font-lilita">Heti Beosztásom</h1>
             <div className="bg-slate-800/40 backdrop-blur-sm p-4 sm:p-6 rounded-2xl">
                <div className="flex justify-between items-center mb-4"><button onClick={() => handleWeekChange('prev')}><ChevronLeftIcon className="w-8 h-8"/></button><div className="text-center"><h2 className="text-xl font-bold font-lilita">{weekId}. hét</h2><p className="text-sm text-white/70">{getWeekDateRange(currentDate)}</p></div><button onClick={() => handleWeekChange('next')}><ChevronRightIcon className="w-8 h-8"/></button></div>
                {(mySchedule || schedule?.imageUrl) ? (
                    <>
                    {mySchedule && (
                        <div className="space-y-2">
                            {weekDays.map(day => {
                                const task = mySchedule.schedule[day.long.toLowerCase()] || 'Pihenőnap';
                                const isDayOff = ['pihenőnap', 'szabadság', 'beteg'].some(keyword => task.toLowerCase().includes(keyword));
                                return (
                                    <div key={day.fullDate} className="bg-slate-900/40 p-3 rounded-lg flex flex-col items-center gap-3">
                                        <div className="text-center">
                                            <p className="font-bold capitalize">{day.long}</p>
                                            <p className="text-lg text-amber-300">{task}</p>
                                        </div>
                                        <div className="flex gap-2">
                                            <button onClick={() => setLatenessModal({day: day.long, date: day.fullDate})} disabled={isDayOff} className="p-2 bg-yellow-600/80 rounded-full text-sm font-semibold flex items-center gap-1 disabled:bg-slate-600 disabled:cursor-not-allowed disabled:opacity-50"><ClockIcon className="w-4 h-4"/> Késés</button>
                                            <button onClick={() => setModificationModal({day: day.long, date: day.fullDate})} className="p-2 bg-blue-600/80 rounded-full text-sm font-semibold flex items-center gap-1"><PencilIcon className="w-4 h-4"/> Módosítás</button>
                                        </div>
                                    </div>
                                )
                            })}
                        </div>
                    )}
                    {schedule?.imageUrl && <img src={schedule.imageUrl} alt="Beosztás" className="w-full rounded-lg mt-4"/>}
                    </>
                ) : <p className="text-center text-white/70 py-4">Nincs beosztásod erre a hétre.</p>}
             </div>
              {latenessModal && (
                <div className="fixed inset-0 bg-black/70 flex justify-center items-center z-50" onClick={() => setLatenessModal(null)}>
                    <div className="bg-slate-800 p-6 rounded-lg w-full max-w-md space-y-4" onClick={e => e.stopPropagation()}>
                        <h3 className="font-bold text-lg">Késés jelentése - {latenessModal.day}</h3>
                        <div>
                            <label className="block text-sm font-semibold mb-1">Várható késés (perc)</label>
                            <input type="number" value={latenessMinutes} onChange={e => setLatenessMinutes(e.target.value)} className="w-full bg-slate-700 p-2 rounded-md" min="1"/>
                        </div>
                        <div>
                            <label className="block text-sm font-semibold mb-1">Üzenet (opcionális)</label>
                            <textarea value={latenessMessage} onChange={e => setLatenessMessage(e.target.value)} rows={3} className="w-full bg-slate-700 p-2 rounded-md" placeholder="Pl. dugó miatt..."/>
                        </div>
                        <div className="flex gap-4">
                            <button onClick={handleSendLateness} disabled={isProcessing} className="flex-1 py-2 bg-orange-600 rounded-full font-bold disabled:bg-slate-500">{isProcessing ? 'Küldés...':'Küldés'}</button>
                            <button onClick={() => setLatenessModal(null)} className="flex-1 py-2 bg-slate-600 rounded-full">Mégse</button>
                        </div>
                    </div>
                </div>
              )}
              {modificationModal && (
                 <div className="fixed inset-0 bg-black/70 flex justify-center items-center z-50" onClick={() => setModificationModal(null)}>
                    <div className="bg-slate-800 p-6 rounded-lg w-full max-w-md space-y-4" onClick={e => e.stopPropagation()}>
                        <h3 className="font-bold text-lg">Módosítási kérelem - {modificationModal.day}</h3>
                         <div>
                            <label className="block text-sm font-semibold mb-1">Üzenet</label>
                            <textarea value={modificationMessage} onChange={e => setModificationMessage(e.target.value)} rows={4} className="w-full bg-slate-700 p-2 rounded-md" placeholder="Miért szeretnéd módosítani?" required/>
                        </div>
                        <div className="flex gap-4">
                            <button onClick={handleSendModification} disabled={isProcessing || !modificationMessage.trim()} className="flex-1 py-2 bg-orange-600 rounded-full font-bold disabled:bg-slate-500">{isProcessing ? 'Küldés...':'Küldés'}</button>
                            <button onClick={() => setModificationModal(null)} className="flex-1 py-2 bg-slate-600 rounded-full">Mégse</button>
                        </div>
                    </div>
                </div>
              )}
        </div>
    );
};

export default HetiBeosztasPage;