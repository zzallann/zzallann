import React from 'react';
import type { Post, User } from '../types';
import PostCard from './PostCard';
import CommentCard from './CommentCard';
import CommentCreator from './CommentCreator';
import XCircleIcon from './icons/XCircleIcon';

interface PostDetailModalProps {
    post: Post;
    currentUser: User;
    onClose: () => void;
    onAddComment: (postId: string, content: string | null, imageFile: File | null, gifUrl: string | null) => void;
    onToggleReaction: (postId: string, reaction: string) => void;
    onToggleCommentReaction: (postId: string, commentId: string, reaction: string) => void;
    onVoteOnPoll: (postId: string, optionIndex: number) => void;
    onDeletePost: (post: Post) => void;
    onDeleteComment: (postId: string, commentId: string) => void;
}

const PostDetailModal: React.FC<PostDetailModalProps> = ({ post, currentUser, onClose, onAddComment, onToggleReaction, onToggleCommentReaction, onVoteOnPoll, onDeletePost, onDeleteComment }) => {
    return (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex justify-center items-center animate-fade-in" onClick={onClose}>
            <div 
                className="bg-slate-900 w-full h-full md:h-auto md:max-h-[90vh] max-w-2xl rounded-none md:rounded-2xl shadow-2xl flex flex-col"
                onClick={e => e.stopPropagation()}
            >
                <div className="flex-shrink-0 p-2 text-right">
                    <button onClick={onClose} className="p-2 text-white/70 hover:text-white">
                        <XCircleIcon className="w-8 h-8"/>
                    </button>
                </div>
                
                <div className="flex-1 overflow-y-auto px-4 pb-4 space-y-4">
                    <PostCard
                        post={post}
                        currentUser={currentUser}
                        onToggleReaction={onToggleReaction}
                        onVoteOnPoll={onVoteOnPoll}
                        onDeletePost={onDeletePost}
                    />
                    
                    <div className="space-y-3">
                        {post.comments.map(comment => (
                            <CommentCard 
                                key={comment.id}
                                comment={comment}
                                currentUser={currentUser}
                                onToggleReaction={(reaction) => onToggleCommentReaction(post.id, comment.id, reaction)}
                                onDeleteComment={() => onDeleteComment(post.id, comment.id)}
                            />
                        ))}
                    </div>
                </div>

                <div className="flex-shrink-0 p-4 border-t border-white/20">
                    <CommentCreator
                        user={currentUser}
                        onAddComment={(content, imageFile, gifUrl) => onAddComment(post.id, content, imageFile, gifUrl)}
                    />
                </div>
            </div>
        </div>
    );
};

export default PostDetailModal;