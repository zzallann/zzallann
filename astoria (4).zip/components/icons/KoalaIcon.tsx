
import React from 'react';
import type { SVGProps } from 'react';

const KoalaIcon: React.FC<SVGProps<SVGSVGElement>> = (props) => (
  <svg viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg" {...props}>
    <path d="M24 39c-7.2 0-13-5.8-13-13s5.8-13 13-13 13 5.8 13 13-5.8 13-13 13z" fill="#BDBDBD"/>
    <path d="M24 39c-7.2 0-13-5.8-13-13s5.8-13 13-13 13 5.8 13 13-5.8 13-13 13z" stroke="#616161" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
    <ellipse cx="24" cy="29" rx="5" ry="3" fill="#EEEEEE"/>
    <ellipse cx="24" cy="29" rx="5" ry="3" stroke="#616161" strokeWidth="2"/>
    <path d="M24 28c-1.5 0-2 .5-2 1.5s.5 1.5 2 1.5 2-.5 2-1.5-0.5-1.5-2-1.5z" fill="#424242"/>
    <circle cx="20" cy="22" r="1.5" fill="#424242"/>
    <circle cx="28" cy="22" r="1.5" fill="#424242"/>
    <circle cx="12" cy="20" r="5" fill="#BDBDBD" stroke="#616161" strokeWidth="2"/>
    <circle cx="36" cy="20" r="5" fill="#BDBDBD" stroke="#616161" strokeWidth="2"/>
    <path d="M16,10 C20,2, 28,2, 32,10 L30 13 L18 13 Z" fill="#8B4513"/>
  </svg>
);
export default KoalaIcon;