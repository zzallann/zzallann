import React from 'react';
import type { SVGProps } from 'react';

const PigeonIcon: React.FC<SVGProps<SVGSVGElement>> = (props) => (
  <svg viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg" {...props}>
    <defs>
      <radialGradient id="pigeon_neck" cx="0.5" cy="0.5" r="0.5">
        <stop offset="0%" stopColor="#43A047" />
        <stop offset="50%" stopColor="#8E24AA" />
        <stop offset="100%" stopColor="#00ACC1" />
      </radialGradient>
    </defs>
    {/* Head */}
    <path d="M24 39c-7.2 0-13-5.8-13-13s5.8-13 13-13 13 5.8 13 13-5.8 13-13 13z" fill="#78909C"/>
    <path d="M24 39c-7.2 0-13-5.8-13-13s5.8-13 13-13 13 5.8 13 13-5.8 13-13 13z" stroke="#37474F" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
    
    {/* Iridescent Neck Patch */}
    <path d="M14 26 C 16 32, 20 35, 24 35 C 28 35, 32 32, 34 26 Z" fill="url(#pigeon_neck)" opacity="0.7"/>

    {/* Beak */}
    <path d="M30 24 L 34 22 L 30 20 Z" fill="#FFB74D" stroke="#E65100" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
    <path d="M31 22.5 L 32 20.5" stroke="#E65100" strokeWidth="1" strokeLinecap="round"/>

    {/* Eye */}
    <circle cx="28" cy="22" r="2.5" fill="#E53935"/>
    <circle cx="28.5" cy="21.5" r="0.75" fill="white"/>

    {/* Hat */}
    <path d="M16,10 C20,2, 28,2, 32,10 L30 13 L18 13 Z" fill="#8B4513"/>
  </svg>
);
export default PigeonIcon;
