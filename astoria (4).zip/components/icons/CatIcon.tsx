import React from 'react';
import type { SVGProps } from 'react';

const WizardIcon: React.FC<SVGProps<SVGSVGElement>> = (props) => (
  <svg viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg" {...props}>
    <circle cx="24" cy="24" r="20" fill="#EDE7F6"/>
    <path d="M16 38V34C16 30 20 28 24 28C28 28 32 30 32 34V38H16Z" fill="#B0BEC5"/>
    <path d="M12 28L24 10L36 28L32 26L24 20L16 26L12 28Z" fill="#5E35B1" stroke="#4527A0" strokeWidth="2" strokeLinejoin="round"/>
    <path d="M16 38C12 34 14 30 18 30" stroke="#FFFFFF" strokeWidth="2.5" strokeLinecap="round"/>
    <path d="M32 38C36 34 34 30 30 30" stroke="#FFFFFF" strokeWidth="2.5" strokeLinecap="round"/>
    <path d="M24 38V30" stroke="#FFFFFF" strokeWidth="2.5" strokeLinecap="round"/>
    <circle cx="20" cy="25" r="1.5" fill="#424242"/>
    <circle cx="28" cy="25" r="1.5" fill="#424242"/>
    <path d="M30 18L32 16" fill="none" stroke="#FDD835" strokeWidth="2" strokeLinecap="round"/>
    <path d="M32 22L34 22" fill="none" stroke="#FDD835" strokeWidth="2" strokeLinecap="round"/>
  </svg>
);
export default WizardIcon;