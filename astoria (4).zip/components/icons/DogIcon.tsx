
import React from 'react';
import type { SVGProps } from 'react';

const DogIcon: React.FC<SVGProps<SVGSVGElement>> = (props) => (
  <svg viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg" {...props}>
    <path d="M24 39c-7.2 0-13-5.8-13-13s5.8-13 13-13 13 5.8 13 13-5.8 13-13 13z" fill="#BCAAA4"/>
    <path d="M24 39c-7.2 0-13-5.8-13-13s5.8-13 13-13 13 5.8 13 13-5.8 13-13 13z" stroke="#5D4037" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
    <path d="M33 24c0 5-4 9-9 9s-9-4-9-9" fill="#EFEBE9"/>
    <path d="M33 24c0 5-4 9-9 9s-9-4-9-9" stroke="#5D4037" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
    <circle cx="20" cy="23" r="1.5" fill="#5D4037"/>
    <circle cx="28" cy="23" r="1.5" fill="#5D4037"/>
    <path d="M24 28v5" stroke="#5D4037" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
    <path d="M12 28c-2 0-4-4-4-8s2-8 4-8" stroke="#BCAAA4" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
    <path d="M36 28c2 0 4-4 4-8s-2-8-4-8" stroke="#BCAAA4" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
    <path d="M16,10 C20,2, 28,2, 32,10 L30 13 L18 13 Z" fill="#8B4513"/>
  </svg>
);
export default DogIcon;
