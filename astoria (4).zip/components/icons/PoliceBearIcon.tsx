import React from 'react';
import type { SVGProps } from 'react';

const PoliceBearIcon: React.FC<SVGProps<SVGSVGElement>> = (props) => (
  <svg viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg" {...props}>
    {/* Bear Face */}
    <path d="M24 39c-7.2 0-13-5.8-13-13s5.8-13 13-13 13 5.8 13 13-5.8 13-13 13z" fill="#8D6E63"/>
    <path d="M24 39c-7.2 0-13-5.8-13-13s5.8-13 13-13 13 5.8 13 13-5.8 13-13 13z" stroke="#3E2723" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
    <circle cx="24" cy="29" r="4" fill="#BCAAA4"/>
    <circle cx="24" cy="29" r="4" stroke="#3E2723" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
    <circle cx="24" cy="29" r="1.5" fill="#3E2723"/>
    <circle cx="20" cy="22" r="1.5" fill="#3E2723"/>
    <circle cx="28" cy="22" r="1.5" fill="#3E2723"/>
    <circle cx="14" cy="18" r="3" fill="#8D6E63" stroke="#3E2723" strokeWidth="2"/>
    <circle cx="34" cy="18" r="3" fill="#8D6E63" stroke="#3E2723" strokeWidth="2"/>
    {/* Police Hat */}
    <path d="M14 14C14 11.2386 16.2386 9 19 9H29C31.7614 9 34 11.2386 34 14V16H14V14Z" fill="#1E3A8A" stroke="#172554" strokeWidth="2"/>
    <rect x="12" y="16" width="24" height="3" fill="#1E3A8A" stroke="#172554" strokeWidth="2"/>
    {/* Badge */}
    <path d="M24 10L25.5 12.5L24 15L22.5 12.5L24 10Z" fill="#FBBF24" stroke="#B45309" strokeWidth="1"/>
  </svg>
);
export default PoliceBearIcon;
