import React from 'react';
import type { SVGProps } from 'react';

const JournalistIcon: React.FC<SVGProps<SVGSVGElement>> = (props) => (
  <svg viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg" {...props}>
    <circle cx="24" cy="24" r="20" fill="#E0E0E0" />
    {/* Hat */}
    <path d="M12 24C12 18 16 16 24 16C32 16 36 18 36 24" fill="#424242" />
    <path d="M10 24C10 16.268 15.268 10 24 10C32.732 10 38 16.268 38 24" fill="none" stroke="#212121" strokeWidth="3" strokeLinecap="round" />
    {/* Shirt and Tie */}
    <path d="M18 38V30H30V38" fill="#FFFFFF" />
    <path d="M22 30L24 36L26 30" fill="#C62828" />
    {/* Glasses */}
    <circle cx="20" cy="28" r="3" fill="none" stroke="#212121" strokeWidth="2" />
    <circle cx="28" cy="28" r="3" fill="none" stroke="#212121" strokeWidth="2" />
    <path d="M23 28H25" stroke="#212121" strokeWidth="2" />
    {/* Mouth */}
    <path d="M22 34h4" stroke="#424242" strokeWidth="1.5" strokeLinecap="round" />
  </svg>
);

export default JournalistIcon;