import React from 'react';
import type { SVGProps } from 'react';

const SuperheroIcon: React.FC<SVGProps<SVGSVGElement>> = (props) => (
  <svg viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg" {...props}>
    <circle cx="24" cy="24" r="20" fill="#42A5F5"/>
    <path d="M14 30C14 26 18 24 24 24C30 24 34 26 34 30V34H14V30Z" fill="#1E88E5"/>
    <path d="M12 24H36V18H12V24Z" fill="#0D47A1"/>
    <path d="M18 18V12H30V18" fill="#1E88E5"/>
    <path d="M18 28L24 34L30 28" fill="#FFC107"/>
    <path d="M20 20L24 14L28 20" fill="#E53935"/>
    <path d="M24 14L22 20H26L24 14Z" fill="#FDD835"/>
    <path d="M18 28H30" stroke="#B71C1C" strokeWidth="2"/>
  </svg>
);
export default SuperheroIcon;