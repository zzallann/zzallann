import React from 'react';
import type { SVGProps } from 'react';

const PandaIcon: React.FC<SVGProps<SVGSVGElement>> = (props) => (
  <svg viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg" {...props}>
    <path d="M24 39c-7.2 0-13-5.8-13-13s5.8-13 13-13 13 5.8 13 13-5.8 13-13 13z" fill="#FFFFFF"/>
    <path d="M24 39c-7.2 0-13-5.8-13-13s5.8-13 13-13 13 5.8 13 13-5.8 13-13 13z" stroke="#1F2937" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
    <circle cx="14" cy="18" r="4" fill="#1F2937"/>
    <circle cx="34" cy="18" r="4" fill="#1F2937"/>
    <ellipse cx="19" cy="24" rx="4" ry="5" fill="#1F2937"/>
    <ellipse cx="29" cy="24" rx="4" ry="5" fill="#1F2937"/>
    <circle cx="19" cy="24" r="1.5" fill="#FFFFFF"/>
    <circle cx="29" cy="24" r="1.5" fill="#FFFFFF"/>
    <path d="M24 29c-1 0-2 .5-2 1.5s1 1.5 2 1.5 2-0.5 2-1.5-1-1.5-2-1.5z" fill="#1F2937"/>
    <path d="M24 32v2" stroke="#1F2937" strokeWidth="2" strokeLinecap="round"/>
    <path d="M16,10 C20,2, 28,2, 32,10 L30 13 L18 13 Z" fill="#8B4513"/>
  </svg>
);

export default PandaIcon;
