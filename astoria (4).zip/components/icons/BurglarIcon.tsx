import React from 'react';
import type { SVGProps } from 'react';

const BurglarIcon: React.FC<SVGProps<SVGSVGElement>> = (props) => (
  <svg viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg" {...props}>
    <circle cx="24" cy="24" r="20" fill="#6B7280" />
    <path d="M12 18C12 12.4772 16.4772 8 22 8H26C31.5228 8 36 12.4772 36 18V26H12V18Z" fill="#1F2937" />
    <rect x="12" y="26" width="24" height="8" fill="#4B5563" />
    <rect x="15" y="20" width="18" height="6" fill="#F9FAFB" />
    <circle cx="20" cy="23" r="2" fill="#1F2937" />
    <circle cx="28" cy="23" r="2" fill="#1F2937" />
    <path d="M21 31L27 31" stroke="#F9FAFB" strokeWidth="2" strokeLinecap="round" />
  </svg>
);

export default BurglarIcon;