import React from 'react';
import type { SVGProps } from 'react';

const MenInBlackIcon: React.FC<SVGProps<SVGSVGElement>> = (props) => (
  <svg viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg" {...props}>
    <circle cx="24" cy="24" r="20" fill="#E0E0E0"/>
    <path d="M16 34V30H32V34H16Z" fill="#212121"/>
    <path d="M18 30L16 22H32L30 30H18Z" fill="#FFFFFF" stroke="#212121" strokeWidth="2"/>
    <path d="M24 22V30" stroke="#212121" strokeWidth="2"/>
    <path d="M21 22L20 30" stroke="#212121" strokeWidth="1.5"/>
    <path d="M27 22L28 30" stroke="#212121" strokeWidth="1.5"/>
    <rect x="18" y="14" width="12" height="8" fill="#212121"/>
    <rect x="19" y="15" width="4" height="6" fill="#424242"/>
    <rect x="25" y="15" width="4" height="6" fill="#424242"/>
    <path d="M16 22L18 20" stroke="#212121" strokeWidth="2"/>
    <path d="M32 22L30 20" stroke="#212121" strokeWidth="2"/>
  </svg>
);
export default MenInBlackIcon;