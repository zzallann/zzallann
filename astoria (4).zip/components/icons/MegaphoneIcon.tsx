import React from 'react';
import type { SVGProps } from 'react';

const MegaphoneIcon: React.FC<SVGProps<SVGSVGElement>> = (props) => (
  <svg viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg" {...props}>
    <circle cx="24" cy="24" r="22" fill="#4A5568"/>
    <path d="M16 22H12C11.4477 22 11 22.4477 11 23V29C11 29.5523 11.4477 30 12 30H16V22Z" fill="#A0AEC0"/>
    <path d="M16 20L35 16V36L16 32V20Z" fill="#CBD5E0"/>
    <path d="M16 20L35 16V36L16 32V20Z" stroke="#2D3748" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
  </svg>
);

export default MegaphoneIcon;