import React from 'react';
import type { SVGProps } from 'react';

const GiftIcon: React.FC<SVGProps<SVGSVGElement>> = (props) => (
  <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" {...props}>
    <circle cx="12" cy="12" r="10" fill="url(#gift_gold_grad)"/>
    <path d="M12 5.5L13.5925 9.40755L17.8058 9.7295L14.6167 12.5925L15.5267 16.7705L12 14.5L8.47335 16.7705L9.38335 12.5925L6.19418 9.7295L10.4075 9.40755L12 5.5Z" fill="#FFFFFF"/>
    <defs>
      <linearGradient id="gift_gold_grad" x1="12" y1="2" x2="12" y2="22" gradientUnits="userSpaceOnUse">
        <stop stopColor="#FBBF24"/>
        <stop offset="1" stopColor="#F59E0B"/>
      </linearGradient>
    </defs>
  </svg>
);
export default GiftIcon;