import React from 'react';
import type { SVGProps } from 'react';

const TrophyIcon: React.FC<SVGProps<SVGSVGElement>> = (props) => (
    <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" {...props}>
        <path d="M9 3H15L12 7L9 3Z" fill="#4299E1"/>
        <path d="M7 3H11L9.5 7H5.5L7 3Z" fill="#63B3ED"/>
        <path d="M13 3H17L18.5 7H14.5L13 3Z" fill="#63B3ED" />
        <circle cx="12" cy="15" r="7" fill="#FBBF24"/>
        <circle cx="12" cy="15" r="5" fill="#F6E05E"/>
        <path d="M12 11.5L13.1126 13.754L15.6058 14.102L13.8029 15.826L14.2251 18.308L12 17.098L9.77488 18.308L10.1971 15.826L8.39421 14.102L10.8874 13.754L12 11.5Z" fill="#FFFFFF"/>
    </svg>
);
export default TrophyIcon;