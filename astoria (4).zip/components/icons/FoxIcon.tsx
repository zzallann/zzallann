import React from 'react';
import type { SVGProps } from 'react';

const CowboyIcon: React.FC<SVGProps<SVGSVGElement>> = (props) => (
  <svg viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg" {...props}>
    <circle cx="24" cy="24" r="20" fill="#A1887F"/>
    <path d="M12 30C12 26 16 24 24 24C32 24 36 26 36 30V34H12V30Z" fill="#D7CCC8"/>
    <rect x="18" y="28" width="12" height="4" fill="#C62828"/>
    <path d="M12 24C12 18 16 16 24 16C32 16 36 18 36 24" fill="#6D4C41"/>
    <path d="M10 24C10 16.268 15.268 10 24 10C32.732 10 38 16.268 38 24" fill="none" stroke="#5D4037" strokeWidth="3" strokeLinecap="round"/>
    <path d="M20 32L18 36" stroke="#5D4037" strokeWidth="2" strokeLinecap="round"/>
    <path d="M28 32L30 36" stroke="#5D4037" strokeWidth="2" strokeLinecap="round"/>
  </svg>
);
export default CowboyIcon;