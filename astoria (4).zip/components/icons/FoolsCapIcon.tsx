import React from 'react';
import type { SVGProps } from 'react';

const FoolsCapIcon: React.FC<SVGProps<SVGSVGElement>> = (props) => (
    <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" {...props}>
        <path d="M12 2L4 10V14H7L12 22L17 14H20V10L12 2Z" fill="#8B5CF6" stroke="#6D28D9" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
        <path d="M12 2L14 7L10 7L12 2Z" fill="#A78BFA"/>
        <path d="M4 10L6 12L2 12L4 10Z" fill="#A78BFA" />
        <path d="M20 10L18 12L22 12L20 10Z" fill="#A78BFA" />
        <circle cx="4" cy="10" r="1.5" fill="#FBBF24" />
        <circle cx="20" cy="10" r="1.5" fill="#FBBF24" />
        <circle cx="12" cy="2" r="1.5" fill="#FBBF24" />
    </svg>
);

export default FoolsCapIcon;
