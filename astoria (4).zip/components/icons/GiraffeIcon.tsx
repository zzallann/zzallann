import React from 'react';
import type { SVGProps } from 'react';

const GiraffeIcon: React.FC<SVGProps<SVGSVGElement>> = (props) => (
    <svg viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg" {...props}>
        <path d="M24 39c-7.2 0-13-5.8-13-13s5.8-13 13-13 13 5.8 13 13-5.8 13-13 13z" fill="#FFD54F"/>
        <path d="M24 39c-7.2 0-13-5.8-13-13s5.8-13 13-13 13 5.8 13 13-5.8 13-13 13z" stroke="#C68E17" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
        <path d="M24 30c-5 0-9 3-9 7h18c0-4-4-7-9-7z" fill="#FFF9C4"/>
        <path d="M24 30c-5 0-9 3-9 7h18c0-4-4-7-9-7z" stroke="#C68E17" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
        <circle cx="21" cy="34" r="1" fill="#C68E17"/>
        <circle cx="27" cy="34" r="1" fill="#C68E17"/>
        <circle cx="20" cy="23" r="1.5" fill="#424242"/>
        <circle cx="28" cy="23" r="1.5" fill="#424242"/>
        <path d="M19 13c-1-4 1-6 1-6s2 2 1 6z" fill="#C68E17" stroke="#8D6E63" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
        <path d="M29 13c1-4-1-6-1-6s-2 2-1 6z" fill="#C68E17" stroke="#8D6E63" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
        <path d="M12 20s-2-4 2-6" stroke="#FFD54F" strokeWidth="2" strokeLinecap="round"/>
        <path d="M36 20s2-4-2-6" stroke="#FFD54F" strokeWidth="2" strokeLinecap="round"/>
        <circle cx="15" cy="28" r="2" fill="#C68E17"/>
        <circle cx="33" cy="28" r="2" fill="#C68E17"/>
        <circle cx="24" cy="18" r="2.5" fill="#C68E17"/>
        <path d="M18,9 C21,2, 27,2, 30,9 L28 12 L20 12 Z" fill="#8B4513"/>
    </svg>
);

export default GiraffeIcon;
