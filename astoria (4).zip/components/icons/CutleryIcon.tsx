
import React from 'react';
import type { SVGProps } from 'react';

const CutleryIcon: React.FC<SVGProps<SVGSVGElement>> = (props) => (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={2} stroke="currentColor" {...props}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M15.362 5.214A8.252 8.252 0 0112 21 8.25 8.25 0 016.038 7.048 8.287 8.287 0 009 9.6a8.983 8.983 0 013.362-3.362 8.287 8.287 0 003 1.026zM9 9.6a8.983 8.983 0 013.362-3.362m0 0a8.25 8.25 0 013.362 3.362" />
    </svg>
);
export default CutleryIcon;
