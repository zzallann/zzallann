
import React from 'react';
import type { SVGProps } from 'react';

const TigerIcon: React.FC<SVGProps<SVGSVGElement>> = (props) => (
  <svg viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg" {...props}>
    <path d="M24 39c-7.2 0-13-5.8-13-13s5.8-13 13-13 13 5.8 13 13-5.8 13-13 13z" fill="#FFA726"/>
    <path d="M24 39c-7.2 0-13-5.8-13-13s5.8-13 13-13 13 5.8 13 13-5.8 13-13 13z" stroke="#BF360C" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
    <path d="M24 28c-4 0-7-2-7-5s3-5 7-5 7 2 7 5-3 5-7 5z" fill="#FFF"/>
    <path d="M17 23c0-3 3-5 7-5s7 2 7 5" stroke="#BF360C" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
    <path d="M24 28v5" stroke="#BF360C" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
    <path d="M20 33h8" stroke="#BF360C" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
    <circle cx="20" cy="22" r="1.5" fill="#BF360C"/>
    <circle cx="28" cy="22" r="1.5" fill="#BF360C"/>
    <path d="M12 16L18 11" stroke="#FFA726" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
    <path d="M36 16L30 11" stroke="#FFA726" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
    {/* Stripes */}
    <path d="M13 20s-2 5 0 7" stroke="#424242" strokeWidth="2" strokeLinecap="round"/>
    <path d="M35 20s2 5 0 7" stroke="#424242" strokeWidth="2" strokeLinecap="round"/>
    <path d="M16 14s-3 3-1 6" stroke="#424242" strokeWidth="2" strokeLinecap="round"/>
    <path d="M32 14s3 3 1 6" stroke="#424242" strokeWidth="2" strokeLinecap="round"/>
    <path d="M16,10 C20,2, 28,2, 32,10 L30 13 L18 13 Z" fill="#8B4513"/>
  </svg>
);
export default TigerIcon;