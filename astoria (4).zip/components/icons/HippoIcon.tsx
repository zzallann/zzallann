
import React from 'react';
import type { SVGProps } from 'react';

const HippoIcon: React.FC<SVGProps<SVGSVGElement>> = (props) => (
  <svg viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg" {...props}>
    <path d="M24 39c-7.2 0-13-5.8-13-13s5.8-13 13-13 13 5.8 13 13-5.8 13-13 13z" fill="#B0BEC5"/>
    <path d="M24 39c-7.2 0-13-5.8-13-13s5.8-13 13-13 13 5.8 13 13-5.8 13-13 13z" stroke="#546E7A" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
    <path d="M15 30c-1.5 0-3 2-3 4h24c0-2-1.5-4-3-4H15z" fill="#CFD8DC"/>
    <path d="M15 30c-1.5 0-3 2-3 4h24c0-2-1.5-4-3-4" stroke="#546E7A" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
    <circle cx="18" cy="29" r="2" fill="#546E7A"/>
    <circle cx="30" cy="29" r="2" fill="#546E7A"/>
    <circle cx="20" cy="22" r="1.5" fill="#37474F"/>
    <circle cx="28" cy="22" r="1.5" fill="#37474F"/>
    <circle cx="16" cy="16" r="2" fill="#B0BEC5" stroke="#546E7A" strokeWidth="1.5"/>
    <circle cx="32" cy="16" r="2" fill="#B0BEC5" stroke="#546E7A" strokeWidth="1.5"/>
    <path d="M16,10 C20,2, 28,2, 32,10 L30 13 L18 13 Z" fill="#8B4513"/>
  </svg>
);
export default HippoIcon;