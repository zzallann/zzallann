import React from 'react';
import type { SVGProps } from 'react';

const GoldCrownIcon: React.FC<SVGProps<SVGSVGElement>> = (props) => (
    <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" {...props}>
        <path d="M5 16L3 5L8.5 9L12 5L15.5 9L21 5L19 16H5Z" fill="url(#gold_grad)" stroke="#FBBF24" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
        <circle cx="8.5" cy="8" r="1.5" fill="#FBBF24" />
        <circle cx="15.5" cy="8" r="1.5" fill="#FBBF24" />
        <circle cx="12" cy="4" r="1.5" fill="#FBBF24" />
        <defs>
            <linearGradient id="gold_grad" x1="12" y1="5" x2="12" y2="16" gradientUnits="userSpaceOnUse">
                <stop stopColor="#FBBF24"/>
                <stop offset="1" stopColor="#F59E0B"/>
            </linearGradient>
        </defs>
    </svg>
);

export default GoldCrownIcon;
