import React from 'react';
import type { SVGProps } from 'react';

const UfoIcon: React.FC<SVGProps<SVGSVGElement>> = (props) => (
  <svg viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg" {...props}>
    {/* Head */}
    <path d="M24 39c-7.2 0-13-5.8-13-13s5.8-13 13-13 13 5.8 13 13-5.8 13-13 13z" fill="#A5D6A7"/>
    <path d="M24 39c-7.2 0-13-5.8-13-13s5.8-13 13-13 13 5.8 13 13-5.8 13-13 13z" stroke="#558B2F" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
    
    {/* Eyes */}
    <ellipse cx="19" cy="24" rx="4" ry="7" fill="#1F2937"/>
    <ellipse cx="29" cy="24" rx="4" ry="7" fill="#1F2937"/>
    
    {/* Mouth */}
    <path d="M22 33h4" stroke="#558B2F" strokeWidth="2" strokeLinecap="round"/>

    {/* Hat */}
    <path d="M16,10 C20,2, 28,2, 32,10 L30 13 L18 13 Z" fill="#8B4513"/>
  </svg>
);
export default UfoIcon;