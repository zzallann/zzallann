
import React from 'react';
import type { SVGProps } from 'react';

const BearIcon: React.FC<SVGProps<SVGSVGElement>> = (props) => (
  <svg viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg" {...props}>
    <path d="M24 39c-7.2 0-13-5.8-13-13s5.8-13 13-13 13 5.8 13 13-5.8 13-13 13z" fill="#8D6E63"/>
    <path d="M24 39c-7.2 0-13-5.8-13-13s5.8-13 13-13 13 5.8 13 13-5.8 13-13 13z" stroke="#3E2723" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
    <circle cx="24" cy="29" r="4" fill="#BCAAA4"/>
    <circle cx="24" cy="29" r="4" stroke="#3E2723" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
    <circle cx="24" cy="29" r="1.5" fill="#3E2723"/>
    <circle cx="20" cy="22" r="1.5" fill="#3E2723"/>
    <circle cx="28" cy="22" r="1.5" fill="#3E2723"/>
    <circle cx="14" cy="18" r="3" fill="#8D6E63" stroke="#3E2723" strokeWidth="2"/>
    <circle cx="34" cy="18" r="3" fill="#8D6E63" stroke="#3E2723" strokeWidth="2"/>
    <path d="M16,10 C20,2, 28,2, 32,10 L30 13 L18 13 Z" fill="#8B4513"/>
  </svg>
);
export default BearIcon;
