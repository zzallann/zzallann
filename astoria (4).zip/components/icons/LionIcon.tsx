
import React from 'react';
import type { SVGProps } from 'react';

const LionIcon: React.FC<SVGProps<SVGSVGElement>> = (props) => (
  <svg viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg" {...props}>
    <path d="M24 39c-7.2 0-13-5.8-13-13s5.8-13 13-13 13 5.8 13 13-5.8 13-13 13z" fill="#FFC107"/>
    <path d="M24 39c-7.2 0-13-5.8-13-13s5.8-13 13-13 13 5.8 13 13-5.8 13-13 13z" stroke="#452709" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
    <path d="M24 13c-3 0-6.8 2-6.8 7.5S21 28 24 28s6.8-2 6.8-7.5S27 13 24 13z" fill="#FFF"/>
    <path d="M19 28.5s-4-1-4-5.5c0-6 4-9.5 9-9.5s9 3.5 9 9.5c0 4.5-4 5.5-4 5.5" stroke="#452709" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
    <path d="M24 28v5" stroke="#452709" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
    <path d="M20 33h8" stroke="#452709" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
    <path d="M20 22h-1m10 0h-1" stroke="#452709" strokeWidth="2" strokeLinecap="round"/>
    <path d="M16,10 C20,2, 28,2, 32,10 L30 13 L18 13 Z" fill="#8B4513"/>
  </svg>
);
export default LionIcon;
