import React from 'react';
import type { SVGProps } from 'react';

const FeedbackIcon: React.FC<SVGProps<SVGSVGElement>> = (props) => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M11.35 3.836c-.065.227-.1.463-.1.714v1.459c0 .251.035.497.1.714M12.65 3.836c.065.227.1.463.1.714v1.459c0 .251-.035.497-.1.714M12 6.114v-1.5m0 1.5a2.25 2.25 0 00-2.25 2.25v3.75a2.25 2.25 0 002.25 2.25h.5a2.25 2.25 0 002.25-2.25v-3.75a2.25 2.25 0 00-2.25-2.25h-.5z" />
    <path strokeLinecap="round" strokeLinejoin="round" d="M9 12.75l3 3m0 0l3-3m-3 3v-7.5M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
  </svg>
);

export default FeedbackIcon;
