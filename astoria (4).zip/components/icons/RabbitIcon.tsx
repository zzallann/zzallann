
import React from 'react';
import type { SVGProps } from 'react';

const RabbitIcon: React.FC<SVGProps<SVGSVGElement>> = (props) => (
  <svg viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg" {...props}>
    <path d="M24 39c-7.2 0-13-5.8-13-13s5.8-13 13-13 13 5.8 13 13-5.8 13-13 13z" fill="#E0E0E0"/>
    <path d="M24 39c-7.2 0-13-5.8-13-13s5.8-13 13-13 13 5.8 13 13-5.8 13-13 13z" stroke="#616161" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
    <circle cx="20" cy="24" r="1.5" fill="#616161"/>
    <circle cx="28" cy="24" r="1.5" fill="#616161"/>
    <path d="M24 29c-1 0-1.5 1-1.5 2s.5 2 1.5 2 1.5-1 1.5-2-.5-2-1.5-2z" fill="#F48FB1"/>
    <path d="M21 34h6" stroke="#616161" strokeWidth="2" strokeLinecap="round"/>
    <path d="M18 18c0-6 2-12 2-12s2 6 2 12z" fill="#E0E0E0" stroke="#616161" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
    <path d="M30 18c0-6-2-12-2-12s-2 6-2 12z" fill="#E0E0E0" stroke="#616161" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
    <path d="M19,13 C21,8, 27,8, 29,13 L27 15 L21 15 Z" fill="#8B4513"/>
  </svg>
);
export default RabbitIcon;
