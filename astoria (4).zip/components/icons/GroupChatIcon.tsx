import React from 'react';
import type { SVGProps } from 'react';

const GroupChatIcon: React.FC<SVGProps<SVGSVGElement>> = (props) => (
  <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" {...props}>
    <circle cx="12" cy="8" r="3" fill="currentColor" opacity="0.9" />
    <path d="M15 14H9C7.89543 14 7 14.8954 7 16V19H17V16C17 14.8954 16.1046 14 15 14Z" fill="currentColor" opacity="0.9" />
    <circle cx="7" cy="10" r="2.5" fill="currentColor" opacity="0.7" />
    <path d="M9.5 15H4.5C3.67157 15 3 15.6716 3 16.5V19H9.5V15Z" fill="currentColor" opacity="0.7" />
    <circle cx="17" cy="10" r="2.5" fill="currentColor" opacity="0.7" />
    <path d="M14.5 15H19.5C20.3284 15 21 15.6716 21 16.5V19H14.5V15Z" fill="currentColor" opacity="0.7" />
  </svg>
);

export default GroupChatIcon;