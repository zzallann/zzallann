import React from 'react';

const AAAvatarIcon: React.FC<{ className?: string }> = ({ className }) => (
    <div className={`w-full h-full flex items-center justify-center font-bold text-yellow-400 text-2xl font-lilita ${className}`}>
        AA
    </div>
);

export default AAAvatarIcon;