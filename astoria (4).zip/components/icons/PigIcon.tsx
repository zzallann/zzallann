
import React from 'react';
import type { SVGProps } from 'react';

const PigIcon: React.FC<SVGProps<SVGSVGElement>> = (props) => (
  <svg viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg" {...props}>
    <path d="M24 39c-7.2 0-13-5.8-13-13s5.8-13 13-13 13 5.8 13 13-5.8 13-13 13z" fill="#F48FB1"/>
    <path d="M24 39c-7.2 0-13-5.8-13-13s5.8-13 13-13 13 5.8 13 13-5.8 13-13 13z" stroke="#C2185B" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
    {/* Snout */}
    <ellipse cx="24" cy="29" rx="6" ry="4" fill="#EC407A"/>
    <ellipse cx="24" cy="29" rx="6" ry="4" stroke="#880E4F" strokeWidth="2"/>
    <circle cx="22" cy="29" r="1" fill="#C2185B"/>
    <circle cx="26" cy="29" r="1" fill="#C2185B"/>
    {/* Eyes */}
    <circle cx="20" cy="22" r="1.5" fill="#424242"/>
    <circle cx="28" cy="22" r="1.5" fill="#424242"/>
    {/* Ears */}
    <path d="M12 20C12 16 16 14 16 14L18 18L12 20Z" fill="#F48FB1" stroke="#C2185B" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
    <path d="M36 20C36 16 32 14 32 14L30 18L36 20Z" fill="#F48FB1" stroke="#C2185B" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
    <path d="M16,10 C20,2, 28,2, 32,10 L30 13 L18 13 Z" fill="#8B4513"/>
  </svg>
);
export default PigIcon;