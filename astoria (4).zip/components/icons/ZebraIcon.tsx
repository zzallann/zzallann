import React from 'react';
import type { SVGProps } from 'react';

const ZebraIcon: React.FC<SVGProps<SVGSVGElement>> = (props) => (
  <svg viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg" {...props}>
    {/* Head */}
    <path d="M24 39c-7.2 0-13-5.8-13-13s5.8-13 13-13 13 5.8 13 13-5.8 13-13 13z" fill="#FFFFFF"/>
    <path d="M24 39c-7.2 0-13-5.8-13-13s5.8-13 13-13 13 5.8 13 13-5.8 13-13 13z" stroke="#424242" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
    
    {/* Stripes */}
    <path d="M13 20 C 15 24, 15 28, 13 32" stroke="#424242" strokeWidth="2.5" fill="none" strokeLinecap="round"/>
    <path d="M17 16 C 19 24, 19 32, 17 36" stroke="#424242" strokeWidth="2.5" fill="none" strokeLinecap="round"/>
    <path d="M24 13 C 24 24, 24 32, 24 39" stroke="#424242" strokeWidth="2.5" fill="none" strokeLinecap="round"/>
    <path d="M31 16 C 29 24, 29 32, 31 36" stroke="#424242" strokeWidth="2.5" fill="none" strokeLinecap="round"/>
    <path d="M35 20 C 33 24, 33 28, 35 32" stroke="#424242" strokeWidth="2.5" fill="none" strokeLinecap="round"/>

    {/* Muzzle */}
    <path d="M24 30C19.5817 30 16 33.5817 16 38H32C32 33.5817 28.4183 30 24 30Z" fill="#CFD8DC"/>
    <path d="M24 30C19.5817 30 16 33.5817 16 38H32C32 33.5817 28.4183 30 24 30Z" stroke="#424242" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
    <circle cx="21" cy="34" r="1" fill="#424242"/>
    <circle cx="27" cy="34" r="1" fill="#424242"/>
    
    {/* Eyes */}
    <circle cx="20" cy="23" r="1.5" fill="#424242"/>
    <circle cx="28" cy="23" r="1.5" fill="#424242"/>

    {/* Ears */}
    <path d="M16 16L20 11L21 16" fill="#FFFFFF" stroke="#424242" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
    <path d="M32 16L28 11L27 16" fill="#FFFFFF" stroke="#424242" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
    
    {/* Hat */}
    <path d="M16,10 C20,2, 28,2, 32,10 L30 13 L18 13 Z" fill="#8B4513"/>
  </svg>
);
export default ZebraIcon;
