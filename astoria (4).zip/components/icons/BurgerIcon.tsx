
import React from 'react';
import type { SVGProps } from 'react';

const BurgerIcon: React.FC<SVGProps<SVGSVGElement>> = (props) => (
  <svg viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg" {...props}>
    {/* Bottom Bun */}
    <path d="M12 34C12 30.6863 17.3726 28 24 28C30.6274 28 36 30.6863 36 34Z" fill="#D28F4B"/>
    <path d="M12 34C12 30.6863 17.3726 28 24 28C30.6274 28 36 30.6863 36 34" stroke="#8D6E63" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
    {/* Patty */}
    <rect x="12" y="26" width="24" height="4" rx="2" fill="#5D4037" stroke="#3E2723" strokeWidth="2"/>
    {/* Cheese */}
    <path d="M13 26L14 24H34L35 26H13Z" fill="#FFC107"/>
    {/* Lettuce */}
    <path d="M12 23C13 22 15 22 17 23C19 24 21 24 23 23C25 22 27 22 29 23C31 24 33 24 35 23" fill="#4CAF50" stroke="#2E7D32" strokeWidth="1.5" strokeLinecap="round"/>
    {/* Top Bun */}
    <path d="M24 14C17.3726 14 12 16.6863 12 20V22H36V20C36 16.6863 30.6274 14 24 14Z" fill="#F57C00"/>
    <path d="M24 14C17.3726 14 12 16.6863 12 20V22H36V20C36 16.6863 30.6274 14 24 14Z" stroke="#BF360C" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
    {/* Sesame seeds */}
    <circle cx="20" cy="18" r="1" fill="#FFFDE7"/>
    <circle cx="28" cy="18" r="1" fill="#FFFDE7"/>
    <circle cx="24" cy="16" r="1" fill="#FFFDE7"/>
    <path d="M16,10 C20,2, 28,2, 32,10 L30 13 L18 13 Z" fill="#8B4513"/>
  </svg>
);
export default BurgerIcon;