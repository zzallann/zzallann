import React from 'react';
import type { SVGProps } from 'react';

const UltraChatIcon: React.FC<SVGProps<SVGSVGElement>> = (props) => (
    <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" {...props}>
        <path d="M5 16L3 5L8.5 9L12 5L15.5 9L21 5L19 16H5Z" fill="url(#ultra_grad)" stroke="#E5E7EB" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
        <path d="M12 11.5L13.1126 13.754L15.6058 14.102L13.8029 15.826L14.2251 18.308L12 17.098L9.77488 18.308L10.1971 15.826L8.39421 14.102L10.8874 13.754L12 11.5Z" fill="#FFFFFF"/>
        <defs>
            <linearGradient id="ultra_grad" x1="12" y1="5" x2="12" y2="16" gradientUnits="userSpaceOnUse">
                <stop stopColor="#6366F1"/>
                <stop offset="1" stopColor="#A78BFA"/>
            </linearGradient>
        </defs>
    </svg>
);

export default UltraChatIcon;
