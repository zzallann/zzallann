import React from 'react';
import type { SVGProps } from 'react';

const BronzeCrownIcon: React.FC<SVGProps<SVGSVGElement>> = (props) => (
    <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" {...props}>
        <path d="M5 16L3 5L8.5 9L12 5L15.5 9L21 5L19 16H5Z" fill="url(#bronze_grad)" stroke="#D97706" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
        <circle cx="8.5" cy="8" r="1.5" fill="#D97706" />
        <circle cx="15.5" cy="8" r="1.5" fill="#D97706" />
        <circle cx="12" cy="4" r="1.5" fill="#D97706" />
        <defs>
            <linearGradient id="bronze_grad" x1="12" y1="5" x2="12" y2="16" gradientUnits="userSpaceOnUse">
                <stop stopColor="#F59E0B"/>
                <stop offset="1" stopColor="#B45309"/>
            </linearGradient>
        </defs>
    </svg>
);

export default BronzeCrownIcon;
