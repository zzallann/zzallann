import React from 'react';
import type { SVGProps } from 'react';

const KnightIcon: React.FC<SVGProps<SVGSVGElement>> = (props) => (
  <svg viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg" {...props}>
    <circle cx="24" cy="24" r="20" fill="#B0BEC5"/>
    <path d="M16 36V28H32V36" fill="#78909C" stroke="#455A64" strokeWidth="2"/>
    <path d="M14 28C14 20 18 14 24 14C30 14 34 20 34 28H14Z" fill="#90A4AE" stroke="#455A64" strokeWidth="2"/>
    <rect x="21" y="20" width="6" height="8" fill="#455A64"/>
    <path d="M12 18L24 8L36 18L34 20H14L12 18Z" fill="#CFD8DC" stroke="#455A64" strokeWidth="2"/>
    <path d="M24 8V12" stroke="#E53935" strokeWidth="2" strokeLinecap="round"/>
    <path d="M21 8H27" stroke="#E53935" strokeWidth="2" strokeLinecap="round"/>
  </svg>
);
export default KnightIcon;