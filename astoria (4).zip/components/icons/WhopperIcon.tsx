import React from 'react';
import type { SVGProps } from 'react';

const SpyIcon: React.FC<SVGProps<SVGSVGElement>> = (props) => (
  <svg viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg" {...props}>
    <circle cx="24" cy="24" r="20" fill="#ECEFF1"/>
    <path d="M14 38C14 32 18 30 24 30C30 30 34 32 34 38" fill="#424242"/>
    <path d="M12 30V24H36V30C36 22 24 20 24 20C24 20 12 22 12 30Z" fill="#616161" stroke="#212121" strokeWidth="2"/>
    <path d="M14 20C14 14.4772 18.4772 10 24 10C29.5228 10 34 14.4772 34 20" fill="#424242" stroke="#212121" strokeWidth="2"/>
    <rect x="12" y="19" width="24" height="4" fill="#616161"/>
    <circle cx="24" cy="29" r="2" fill="#FFFFFF"/>
  </svg>
);
export default SpyIcon;