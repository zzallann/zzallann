import React, { useState } from 'react';
import type { User, Post } from '../types';
import { avatars } from './AvatarSelector';
import PostCard from './PostCard';
import UserStatusBadge from './UserStatusBadge';
import SettingsIcon from './icons/SettingsIcon';
import LogoutIcon from './icons/LogoutIcon';
import LogoutModal from './LogoutModal';
import CrownRequestModal from './CrownRequestModal';

interface ProfilePageProps {
  user: User;
  posts: Post[];
  currentUser: User;
  onToggleReaction: (postId: string, reaction: string) => void;
  onVoteOnPoll: (postId: string, optionIndex: number) => void;
  onDeletePost?: (post: Post) => void;
  onNavigate: (view: string) => void;
  onLogout: () => void;
  onUserUpdate: (user: User) => void;
}

const formatCrowns = (points: number): string => {
    const roundedUp = Math.ceil(points * 100) / 100;
    return roundedUp.toLocaleString('hu-HU', {
        minimumFractionDigits: 2,
        maximumFractionDigits: 2,
    });
};

const ProfilePage: React.FC<ProfilePageProps> = ({ user, posts, currentUser, onToggleReaction, onVoteOnPoll, onDeletePost, onNavigate, onLogout, onUserUpdate }) => {
    const userAvatar = avatars.find(a => a.id === user.avatarId);
    const userPosts = posts.filter(p => p.author.id === user.id);
    const [showLogoutModal, setShowLogoutModal] = useState(false);
    const [isCrownRequestModalOpen, setIsCrownRequestModalOpen] = useState(false);
    
    return (
        <>
        <div className="relative w-full max-w-2xl mx-auto animate-fade-in space-y-6">
            <div className="absolute top-4 right-4 flex gap-2 z-10">
                <button 
                    onClick={() => onNavigate('beallitasok')} 
                    className="SettingsBtn"
                    title="Beállítások"
                >
                    <div className="sign">
                        <SettingsIcon />
                    </div>
                    <div className="text">Beállítások</div>
                </button>
                <button 
                    onClick={() => setShowLogoutModal(true)} 
                    className="Btn"
                    title="Kijelentkezés"
                >
                    <div className="sign">
                        <LogoutIcon />
                    </div>
                    <div className="text">Kijelentkezés</div>
                </button>
            </div>
            
            <div className="bg-[var(--component-bg)] backdrop-blur-sm rounded-2xl shadow-lg p-6 pt-20 text-[var(--text-primary)] text-center">
                <div className="relative w-32 h-32 mx-auto mb-4">
                     <div className="w-full h-full rounded-full overflow-hidden flex-shrink-0 bg-white/30 dark:bg-slate-700/50 ring-4 ring-orange-500">
                        {user.uploadedImage ? (
                            <img src={user.uploadedImage} alt="Avatar" className="w-full h-full object-cover"/>
                        ) : userAvatar ? (
                            <userAvatar.component />
                        ) : (
                            <div className="w-full h-full flex items-center justify-center text-5xl font-bold text-slate-700 dark:text-white">
                                {user.name.charAt(0).toUpperCase()}
                            </div>
                        )}
                    </div>
                </div>

                <h1 className="text-3xl font-bold font-lilita flex items-center justify-center">{user.name} <UserStatusBadge user={user} /></h1>
                <p className="text-sm text-[var(--text-secondary)]">{user.fullName}</p>
                
                <div className="mt-4">
                    <p className="text-sm text-[var(--text-secondary)]">Megszerzett Koronák</p>
                    <p className="text-3xl font-bold text-amber-400">{formatCrowns(user.points)}</p>
                </div>

                {user.status !== 'pro_max' && (
                    <div className="mt-4">
                        <p className="text-sm text-[var(--text-secondary)]">Strigulák</p>
                        <p className={`text-3xl font-bold ${user.strikes > 0 ? 'text-red-400' : 'text-green-400'}`}>{user.strikes} / 3</p>
                        <p className="text-xs text-[var(--text-tertiary)] mt-1">Minden strigula 100 korona levonással jár.</p>
                    </div>
                )}
            </div>
            
            {currentUser.id === user.id && user.status === 'pro_max' && (
                <div className="text-center">
                    <button
                        onClick={() => setIsCrownRequestModalOpen(true)}
                        className="golden-button"
                    >
                        Korona igénylés
                    </button>
                </div>
            )}

            <div className="w-full">
                 <h2 className="text-2xl font-bold text-[var(--text-primary)] font-lilita mb-4 text-center">Bejegyzéseim</h2>
                 {userPosts.length > 0 ? (
                    <div className="space-y-6">
                        {userPosts.map(post => (
                            <PostCard 
                                key={post.id}
                                post={post}
                                currentUser={currentUser}
                                onToggleReaction={onToggleReaction}
                                onVoteOnPoll={onVoteOnPoll}
                                onDeletePost={onDeletePost}
                            />
                        ))}
                    </div>
                 ) : (
                    <div className="bg-[var(--component-bg)] backdrop-blur-sm p-8 rounded-2xl text-center">
                        <p className="text-[var(--text-secondary)]">Még nincsenek saját bejegyzéseid.</p>
                    </div>
                 )}
            </div>
        </div>
        <LogoutModal isOpen={showLogoutModal} onClose={() => setShowLogoutModal(false)} onConfirm={onLogout} />
        <CrownRequestModal 
            isOpen={isCrownRequestModalOpen}
            onClose={() => setIsCrownRequestModalOpen(false)}
            user={user}
            onUserUpdate={onUserUpdate}
        />
        </>
    );
};

export default ProfilePage;