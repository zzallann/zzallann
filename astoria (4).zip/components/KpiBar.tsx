import React, { useState, useEffect } from 'react';
import type { User, KpiData } from '../types';
import { kpiService } from '../services/kpiService';
import EditIcon from './icons/EditIcon';

interface KpiBarProps {
    currentUser: User;
}

const parseTimeToSeconds = (time: string): number => {
    const parts = time.split(':');
    if (parts.length !== 2) return 0;
    const [minutes, seconds] = parts.map(Number);
    if (isNaN(minutes) || isNaN(seconds)) return 0;
    return minutes * 60 + seconds;
}

const getDailyMenu = () => {
    const day = new Date().getDay(); // 0 = Sunday, 1 = Monday, ...
    switch (day) {
        case 1: return 'Crispy Chicken Kingmenü';
        case 2: return 'Western Whopper Jr. Kingmenü';
        case 3: return 'Dupla Sajtburger Kingmenü';
        case 4: return 'Whopper Jr. Kingmenü';
        case 5: return 'Chili Cheese CC Kingmenü';
        case 6: return 'Nincsen mára'; // Saturday
        case 0: return 'Nincsen mára'; // Sunday
        default: return 'Nincsen mára';
    }
};

const KpiBar: React.FC<KpiBarProps> = ({ currentUser }) => {
    const [kpis, setKpis] = useState<KpiData | null>(null);
    const [isEditing, setIsEditing] = useState(false);
    const [editableKpis, setEditableKpis] = useState<Omit<KpiData, 'dailyMenu'> | null>(null);

    const canEdit = ['pro_max', 'admin'].includes(currentUser.status || 'normal');
    const isAdmin = currentUser.status === 'admin';

    useEffect(() => {
        const fetchKpis = async () => {
            const data = await kpiService.getKpis();
            setKpis(data);
            const { dailyMenu, ...editable } = data;
            setEditableKpis(editable);
        };
        fetchKpis();
    }, []);

    const handleEditToggle = () => {
        if (isEditing && editableKpis) {
            // Save changes
            kpiService.updateKpis(editableKpis).then(setKpis);
        }
        setIsEditing(!isEditing);
    };

    const handleEditChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
        if (!editableKpis) return;
        setEditableKpis({
            ...editableKpis,
            [e.target.name]: e.target.value,
        });
    };
    
    if (!kpis || !editableKpis) {
        return <div className="w-full h-24 bg-[var(--component-bg)] rounded-2xl animate-pulse"></div>;
    }

    // Color logic
    const timeActual = parseTimeToSeconds(kpis.time);
    const timeTarget = parseTimeToSeconds(kpis.timeTarget);
    const timeDiffPercent = timeTarget > 0 ? ((timeActual / timeTarget) - 1) * 100 : 0;
    let timeColor = 'text-green-400';
    if (timeDiffPercent > 15) {
        timeColor = 'text-red-400';
    } else if (timeDiffPercent > 5) {
        timeColor = 'text-yellow-400';
    }

    const npsActual = parseFloat(kpis.nps);
    const npsTarget = parseFloat(kpis.npsTarget);
    const npsDiffPercent = npsTarget > 0 ? ((npsTarget - npsActual) / npsTarget) * 100 : 0;
    let npsColor = 'text-green-400';
    if (npsDiffPercent > 15) {
        npsColor = 'text-red-400';
    } else if (npsDiffPercent > 5) {
        npsColor = 'text-yellow-400';
    }

    const dailyMenu = getDailyMenu();


    return (
        <div className="w-full bg-[var(--component-bg)] backdrop-blur-sm p-3 rounded-2xl shadow-lg text-[var(--text-primary)]">
            <div className="flex justify-between items-start">
                <div className="flex-1 space-y-2">
                    {isEditing ? (
                        <>
                           <div className="grid grid-cols-3 gap-x-1 sm:gap-x-4 gap-y-2 text-xs sm:text-sm">
                                {/* Row 1 */}
                                <div className="flex items-center gap-1 flex-wrap">
                                    {isAdmin ? <input name="npsLabel" value={editableKpis.npsLabel} onChange={handleEditChange} className="bg-[var(--input-bg)] px-1 rounded font-bold w-12" /> : <span className="font-bold text-right flex-shrink-0">{kpis.npsLabel}:</span>}
                                    <input name="nps" value={editableKpis.nps} onChange={handleEditChange} className="flex-1 min-w-[40px] bg-[var(--input-bg)] px-1 rounded" /> %
                                </div>
                                <div className="flex items-center gap-1 flex-wrap">
                                    {isAdmin ? <input name="timeLabel" value={editableKpis.timeLabel} onChange={handleEditChange} className="bg-[var(--input-bg)] px-1 rounded font-bold w-12" /> : <span className="font-bold text-right flex-shrink-0">{kpis.timeLabel}:</span>}
                                    <input name="time" value={editableKpis.time} onChange={handleEditChange} className="flex-1 min-w-[40px] bg-[var(--input-bg)] px-1 rounded" />p
                                </div>
                                <div className="flex items-center gap-1 flex-wrap">
                                    <input name="customLabel1" value={editableKpis.customLabel1} onChange={handleEditChange} maxLength={6} className="flex-[2_1_50px] bg-[var(--input-bg)] px-1 rounded font-bold" />
                                    <span className="font-bold">:</span>
                                    <input name="customValue1" value={editableKpis.customValue1} onChange={handleEditChange} className="flex-[1_1_30px] bg-[var(--input-bg)] px-1 rounded" />
                                    <select
                                        name="customUnit1"
                                        value={editableKpis.customUnit1}
                                        onChange={handleEditChange}
                                        className="bg-[var(--input-bg)] p-0 sm:px-1 rounded text-white"
                                    >
                                        <option value="%">%</option>
                                        <option value="p">p</option>
                                        <option value="none">Nincs</option>
                                    </select>
                                </div>

                                {/* Row 2 */}
                                <div className="flex items-center gap-1 flex-wrap text-[var(--text-tertiary)]">
                                     {isAdmin ? <input name="npsTargetLabel" value={editableKpis.npsTargetLabel} onChange={handleEditChange} className="bg-[var(--input-bg)] px-1 rounded font-bold w-12" /> : <span className="font-bold text-right flex-shrink-0">{kpis.npsTargetLabel}:</span>}
                                    <input name="npsTarget" value={editableKpis.npsTarget} onChange={handleEditChange} className="flex-1 min-w-[40px] bg-[var(--input-bg)] px-1 rounded" /> %
                                </div>
                                <div className="flex items-center gap-1 flex-wrap text-[var(--text-tertiary)]">
                                     {isAdmin ? <input name="timeTargetLabel" value={editableKpis.timeTargetLabel} onChange={handleEditChange} className="bg-[var(--input-bg)] px-1 rounded font-bold w-12" /> : <span className="font-bold text-right flex-shrink-0">{kpis.timeTargetLabel}:</span>}
                                    <input name="timeTarget" value={editableKpis.timeTarget} onChange={handleEditChange} className="flex-1 min-w-[40px] bg-[var(--input-bg)] px-1 rounded" />p
                                </div>
                                <div className="flex items-center gap-1 flex-wrap text-[var(--text-tertiary)]">
                                    <input name="customLabel2" value={editableKpis.customLabel2} onChange={handleEditChange} maxLength={6} className="flex-[2_1_50px] bg-[var(--input-bg)] px-1 rounded font-bold" />
                                    <span className="font-bold">:</span>
                                    <input name="customValue2" value={editableKpis.customValue2} onChange={handleEditChange} className="flex-[1_1_30px] bg-[var(--input-bg)] px-1 rounded" />
                                    <select
                                        name="customUnit2"
                                        value={editableKpis.customUnit2}
                                        onChange={handleEditChange}
                                        className="bg-[var(--input-bg)] p-0 sm:px-1 rounded text-white"
                                    >
                                        <option value="%">%</option>
                                        <option value="p">p</option>
                                        <option value="none">Nincs</option>
                                    </select>
                                </div>
                            </div>
                            <div className="flex items-center gap-1 flex-wrap text-[var(--text-tertiary)] mt-2">
                                {isAdmin ? <input name="dailyMenuLabel" value={editableKpis.dailyMenuLabel} onChange={handleEditChange} className="bg-[var(--input-bg)] px-1 rounded font-bold w-16" /> : <span className="font-bold">{kpis.dailyMenuLabel}:</span>}
                                <span>{dailyMenu}</span>
                            </div>
                        </>
                    ) : (
                        <>
                            <div className="grid grid-cols-3 gap-x-4 gap-y-1">
                                {/* Top Row */}
                                <div className="text-sm font-bold">{kpis.npsLabel}: <span className={npsColor}>{kpis.nps}%</span></div>
                                <div className="text-sm font-bold">{kpis.timeLabel}: <span className={timeColor}>{kpis.time}p</span></div>
                                <div className="text-sm font-bold truncate">
                                    {kpis.customLabel1}
                                    {kpis.customLabel1 && kpis.customValue1 ? ': ' : ''}
                                    <span className="text-white">
                                        {kpis.customValue1}
                                        {kpis.customUnit1 === 'p' ? ' ' : ''}
                                        {kpis.customUnit1 !== 'none' && kpis.customUnit1}
                                    </span>
                                </div>

                                {/* Bottom Row */}
                                <div className="text-xs text-[var(--text-tertiary)]">{kpis.npsTargetLabel}: {kpis.npsTarget}%</div>
                                <div className="text-xs text-[var(--text-tertiary)]">{kpis.timeTargetLabel}: {kpis.timeTarget}p</div>
                                <div className="text-xs text-[var(--text-tertiary)] truncate">
                                    {kpis.customLabel2}
                                    {kpis.customLabel2 && kpis.customValue2 ? ': ' : ''}
                                    <span className="text-white">
                                        {kpis.customValue2}
                                        {kpis.customUnit2 === 'p' ? ' ' : ''}
                                        {kpis.customUnit2 !== 'none' && kpis.customUnit2}
                                    </span>
                                </div>
                            </div>
                             <div className="text-xs text-[var(--text-tertiary)] mt-2">
                                <span>{kpis.dailyMenuLabel}: {dailyMenu}</span>
                            </div>
                        </>
                    )}
                </div>
                <div className="flex flex-col items-end gap-2">
                     {canEdit && (
                        <button onClick={handleEditToggle} className="p-2 rounded-full hover:bg-[var(--component-bg-hover)]">
                            <EditIcon className="w-5 h-5" />
                        </button>
                    )}
                </div>
            </div>
        </div>
    );
};

export default KpiBar;