import React, { useState } from 'react';
import type { AssignedTask } from '../types';
import { taskService } from '../services/taskService';
import { useNotification } from '../contexts/NotificationContext';
import SendIcon from './icons/SendIcon';

interface EditTaskModalProps {
  task: AssignedTask;
  onClose: () => void;
  onTaskUpdated: (updatedTask: AssignedTask) => void;
}

const EditTaskModal: React.FC<EditTaskModalProps> = ({ task, onClose, onTaskUpdated }) => {
    const [deadline, setDeadline] = useState(new Date(task.deadline).toISOString().split('T')[0]);
    const [isLoading, setIsLoading] = useState(false);
    const { addNotification } = useNotification();

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        setIsLoading(true);
        try {
            const deadlineDate = new Date(deadline);
            deadlineDate.setHours(23, 59, 59); // Set to end of day
            const updatedTask = await taskService.updateTaskDeadline(task.id, deadlineDate.getTime());
            addNotification("Határidő sikeresen módosítva!", "success");
            onTaskUpdated(updatedTask);
            onClose();
        } catch (err) {
            addNotification("Hiba a módosítás során.", "error");
        } finally {
            setIsLoading(false);
        }
    };

    return (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex justify-center items-center z-50 animate-fade-in" onClick={onClose}>
            <div className="bg-slate-800 w-full max-w-sm rounded-2xl shadow-2xl p-6 text-white" onClick={e => e.stopPropagation()}>
                <h3 className="text-2xl font-bold font-lilita mb-4 text-center">Határidő módosítása</h3>
                <p className="text-center mb-1 text-white/80 line-clamp-2">{task.description}</p>
                <form onSubmit={handleSubmit} className="space-y-4 mt-4">
                    <div>
                        <label htmlFor="new-deadline" className="block text-white font-semibold mb-1">Új határidő</label>
                        <input
                            type="date"
                            id="new-deadline"
                            value={deadline}
                            onChange={(e) => setDeadline(e.target.value)}
                            className="w-full px-4 py-2 bg-slate-700 text-white border-2 border-transparent rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500"
                            required
                            disabled={isLoading}
                            min={new Date().toISOString().split("T")[0]}
                        />
                    </div>
                    <button
                        type="submit"
                        disabled={isLoading}
                        className="w-full mt-4 flex items-center justify-center gap-2 px-4 py-3 bg-orange-600 font-bold rounded-full text-lg shadow-lg transform hover:scale-105 transition-transform disabled:bg-orange-400 disabled:scale-100"
                    >
                        <SendIcon className="w-5 h-5" />
                        <span>{isLoading ? 'Mentés...' : 'Mentés'}</span>
                    </button>
                </form>
            </div>
        </div>
    );
};

export default EditTaskModal;
