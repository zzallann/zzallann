import React, { useState, useMemo, useEffect } from 'react';
import type { User, WorkTimeRequest } from '../types';
import SendIcon from './icons/SendIcon';
import ArrowLeftIcon from './icons/ArrowLeftIcon';
import WarningIcon from './icons/WarningIcon';
import { workTimeService } from '../services/workTimeService';
import { deadlineService } from '../services/deadlineService';
import { useNotification } from '../contexts/NotificationContext';
import { authService } from '../services/authService';
import { messageService } from '../services/messageService';
import { avatars } from './AvatarSelector';
import ChevronLeftIcon from './icons/ChevronLeftIcon';
import ChevronRightIcon from './icons/ChevronRightIcon';


type DayType = 'munkanap' | 'szabadság';

interface SelectedDay {
    date: Date;
    type: DayType;
    from: string;
    to: string;
    isFlex: boolean;
}

type View = 'form' | 'summary' | 'success';

interface WorkTimeRequestPageProps {
    user: User;
}

const getWeekId = (date: Date): string => {
    const d = new Date(Date.UTC(date.getFullYear(), date.getMonth(), date.getDate()));
    d.setUTCDate(d.getUTCDate() + 4 - (d.getUTCDay() || 7));
    const yearStart = new Date(Date.UTC(d.getUTCFullYear(), 0, 1));
    const weekNo = Math.ceil((((d.getTime() - yearStart.getTime()) / 86400000) + 1) / 7);
    return `${d.getUTCFullYear()}-${weekNo}`;
};

const getWeekDateRange = (date: Date): string => {
    const d = new Date(date);
    const day = d.getDay();
    const diff = d.getDate() - day + (day === 0 ? -6 : 1); // adjust when day is sunday
    const monday = new Date(d.setDate(diff));
    const sunday = new Date(monday);
    sunday.setDate(monday.getDate() + 6);
    const options: Intl.DateTimeFormatOptions = { month: 'long', day: 'numeric' };
    return `${monday.toLocaleDateString('hu-HU', options)} - ${sunday.toLocaleDateString('hu-HU', options)}`;
};

const getNextWeekDates = (): Date[] => {
    const dates: Date[] = [];
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const dayOfWeek = today.getDay();
    const daysUntilNextMonday = dayOfWeek === 0 ? 1 : 8 - dayOfWeek;

    const nextMonday = new Date(today);
    nextMonday.setDate(today.getDate() + daysUntilNextMonday);

    for (let i = 0; i < 7; i++) {
        const day = new Date(nextMonday);
        day.setDate(nextMonday.getDate() + i);
        dates.push(day);
    }
    return dates;
};

const parseTimeToMinutes = (time: string): number => {
    let [hours, minutes] = time.split(':').map(Number);
    if (hours < 6) hours += 24;
    return hours * 60 + minutes;
};


const TimePicker: React.FC<{ value: string; onChange: (value: string) => void; disabled?: boolean }> = ({ value, onChange, disabled = false }) => {
    const [hour, minute] = value.split(':');
    const handleHourChange = (e: React.ChangeEvent<HTMLSelectElement>) => onChange(`${e.target.value}:${minute}`);
    const handleMinuteChange = (e: React.ChangeEvent<HTMLSelectElement>) => onChange(`${hour}:${e.target.value}`);
    const hours = [...Array.from({length: 17}, (_, i) => i + 7), 0, 1];
    const minutes = ['00', '15', '30', '45'];
    return (<div className="flex items-center gap-1"><select value={hour} onChange={handleHourChange} className="bg-slate-700 border border-slate-600 rounded-md px-2 py-1 disabled:opacity-70" disabled={disabled}>{hours.map(h => <option key={h} value={String(h).padStart(2, '0')}>{String(h).padStart(2, '0')}</option>)}</select><span>:</span><select value={minute} onChange={handleMinuteChange} className="bg-slate-700 border border-slate-600 rounded-md px-2 py-1 disabled:opacity-70" disabled={disabled}>{minutes.map(m => <option key={m} value={m}>{m}</option>)}</select></div>);
};


const WorkTimeRequestPage: React.FC<WorkTimeRequestPageProps> = ({ user }) => {
    const [view, setView] = useState<View>('form');
    const [selectedDays, setSelectedDays] = useState<Record<string, SelectedDay>>({});
    const [message, setMessage] = useState('');
    const [hasExistingRequest, setHasExistingRequest] = useState(false);
    const [isSubmitting, setIsSubmitting] = useState(false);
    const [timeLeft, setTimeLeft] = useState({ days: 0, hours: 0, minutes: 0, seconds: 0 });
    const [deadline, setDeadline] = useState<Date | null>(null);
    const [validationErrors, setValidationErrors] = useState<Record<string, string>>({});
    const { addNotification } = useNotification();
    
    const [allRequests, setAllRequests] = useState<WorkTimeRequest[]>([]);
    const [isLoading, setIsLoading] = useState(true);
    const [isLoadingRequests, setIsLoadingRequests] = useState(true);
    const [newDeadlineDate, setNewDeadlineDate] = useState('');
    const [newDeadlineTime, setNewDeadlineTime] = useState('20:00');
    const [viewingDate, setViewingDate] = useState(getNextWeekDates()[0]);

    const nextWeekDates = useMemo(() => getNextWeekDates(), []);

    const fetchProMaxData = async () => {
        setIsLoadingRequests(true);
        const requests = await workTimeService.getRequestsForWeek(viewingDate);
        setAllRequests(requests);
        setIsLoadingRequests(false);
    };

    useEffect(() => {
        const initializeData = async () => {
            setIsLoading(true);
            try {
                const storedDeadline = await deadlineService.getDeadline();
                if (storedDeadline) {
                    const d = new Date(storedDeadline);
                    setDeadline(d);
                    setNewDeadlineDate(d.toISOString().split('T')[0]);
                    setNewDeadlineTime(d.toTimeString().substring(0, 5));
                }

                if (user.status !== 'pro_max') {
                    const existingRequest = await workTimeService.getNextWeekRequestForUser(user.id);
                    if (existingRequest) {
                        const daysRecord: Record<string, SelectedDay> = {};
                        existingRequest.days.forEach(day => {
                            const date = new Date(day.date);
                            daysRecord[date.toISOString().split('T')[0]] = { date, type: day.type, from: day.from, to: day.to, isFlex: day.isFlex };
                        });
                        setSelectedDays(daysRecord);
                        setMessage(existingRequest.message || '');
                        setHasExistingRequest(true);
                    }
                } else {
                   await fetchProMaxData();
                }
            } catch (error) { console.error("Failed to load data:", error); } 
            finally { setIsLoading(false); }
        };
        initializeData();
    }, [user.id, user.status]);
    
    useEffect(() => {
        if(user.status === 'pro_max') fetchProMaxData();
    }, [viewingDate]);

    useEffect(() => {
        if (!deadline) return;
        const timer = setInterval(() => {
            const difference = +deadline - +new Date();
            if (difference > 0) setTimeLeft({ days: Math.floor(difference / 86400000), hours: Math.floor((difference / 3600000) % 24), minutes: Math.floor((difference / 60000) % 60), seconds: Math.floor((difference / 1000) % 60) });
            else setTimeLeft({ days: 0, hours: 0, minutes: 0, seconds: 0 });
        }, 1000);
        return () => clearInterval(timer);
    }, [deadline]);
    
    useEffect(() => {
        const newErrors: Record<string, string> = {};
        for (const dateString in selectedDays) {
            const day = selectedDays[dateString];
            if (day.type === 'munkanap' && !day.isFlex && parseTimeToMinutes(day.to) < parseTimeToMinutes(day.from)) {
                newErrors[dateString] = 'A befejezési idő nem lehet korábbi a kezdésnél.';
            }
        }
        setValidationErrors(newErrors);
    }, [selectedDays]);

    const handleWeekChange = (direction: 'prev' | 'next') => setViewingDate(prev => { const d = new Date(prev); d.setDate(d.getDate() + (direction === 'prev' ? -7 : 7)); return d; });
    const toggleDaySelection = (date: Date) => setSelectedDays(prev => { const ds = date.toISOString().split('T')[0], n = {...prev}; if(n[ds]) delete n[ds]; else n[ds] = { date, type: 'munkanap', from: '08:00', to: '16:00', isFlex: false }; return n; });
    const handleDayDetailChange = (ds: string, f: 'type'|'from'|'to'|'isFlex', v: string|boolean) => setSelectedDays(p => { const n = {...p}; if(n[ds]) { switch(f){ case 'type': n[ds].type = v as DayType; if(v==='munkanap'){n[ds].isFlex=false; n[ds].from='08:00'; n[ds].to='16:00';} break; case 'from': n[ds].from=v as string;break; case 'to': n[ds].to=v as string;break; case 'isFlex': n[ds].isFlex=v as boolean;break; } } return n; });
    
    const handleShiftSelect = (dateString: string, from: string, to: string) => {
        setSelectedDays(prev => {
            const newDays = { ...prev };
            const dayToUpdate = newDays[dateString];
            if (dayToUpdate) {
                newDays[dateString] = {
                    ...dayToUpdate,
                    from: from,
                    to: to,
                    isFlex: false, // Selecting a shift disables flex
                };
            }
            return newDays;
        });
    };
    
    const handleSubmit = async () => { setIsSubmitting(true); try { await workTimeService.submitRequest(user, sortedSelectedDays, message); setHasExistingRequest(true); setView('success'); } catch (error) { addNotification('Hiba a kérelem leadásakor.', 'error'); } finally { setIsSubmitting(false); } };
    const handleSetDeadline = async (e: React.FormEvent) => {
        e.preventDefault();
        if (!newDeadlineDate || !newDeadlineTime) { addNotification('Dátum és idő megadása kötelező.', 'error'); return; }
        const [hour, minute] = newDeadlineTime.split(':').map(Number);
        const newDeadline = new Date(newDeadlineDate); newDeadline.setHours(hour, minute, 0, 0);
        try {
            const oldDeadline = await deadlineService.getDeadline();
            await deadlineService.setDeadline(newDeadline.getTime());
            addNotification('Határidő sikeresen beállítva!', 'success');
            setDeadline(newDeadline);

            const isExtension = oldDeadline && newDeadline.getTime() > oldDeadline;
            const allUsers = authService.getAllUsers();
            const requests = await workTimeService.getNextWeeksRequests();
            const usersWhoSubmitted = new Set(requests.map(r => r.userId));
            const usersToNotify = allUsers.filter(u => u.id !== user.id && (u.status === 'pro' || u.status === 'normal') && !usersWhoSubmitted.has(u.id));
            const policeBotId = 'system_police_bot';
            const notificationMessage = isExtension ? `A beosztás leadási ideje meg lett hosszabbítva, add le SOS! Új határidő: ${newDeadline.toLocaleString('hu-HU')}` : `A heti beosztás leadási határideje be lett állítva: ${newDeadline.toLocaleString('hu-HU')}.`;
            for (const targetUser of usersToNotify) {
                const convoId = await messageService.findOrCreateConversation(policeBotId, targetUser.id);
                await messageService.sendMessage(policeBotId, convoId, notificationMessage, null, null, false);
            }
        } catch(err) { addNotification('Hiba a határidő beállításakor.', 'error'); }
    };
    const handleNewRequest = () => setView('form');
    const sortedSelectedDays = (Object.values(selectedDays) as SelectedDay[]).sort((a, b) => a.date.getTime() - b.date.getTime());
    const summary = useMemo(() => sortedSelectedDays.reduce((acc, day) => { acc[day.type] = (acc[day.type] || 0) + 1; return acc; }, {} as Record<DayType, number>), [sortedSelectedDays]);
    const isDeadlinePassed = deadline ? deadline.getTime() < Date.now() : false;

    if (isLoading) return <div className="text-center text-white">Adatok betöltése...</div>;

    if (user.status === 'pro_max') {
        return (
            <div className="w-full max-w-2xl mx-auto animate-fade-in space-y-6 text-white">
                <h1 className="text-3xl sm:text-4xl font-bold font-lilita tracking-wide text-center">Kérelmek</h1>
                <div className="bg-slate-800/30 backdrop-blur-sm rounded-2xl shadow-lg p-6">
                    <h2 className="text-2xl font-bold font-lilita mb-4 border-b-2 border-slate-600 pb-2">Leadási Határidő</h2>
                    <form onSubmit={handleSetDeadline} className="flex flex-col sm:flex-row items-center gap-3">
                        <input type="date" value={newDeadlineDate} onChange={e => setNewDeadlineDate(e.target.value)} className="w-full sm:w-auto bg-slate-700 text-white p-2 rounded-lg" required />
                        <input type="time" value={newDeadlineTime} onChange={e => setNewDeadlineTime(e.target.value)} className="w-full sm:w-auto bg-slate-700 text-white p-2 rounded-lg" required />
                        <button type="submit" className="w-full sm:w-auto px-4 py-2 bg-orange-600 font-bold rounded-full shadow-lg">Beállítás</button>
                    </form>
                    {deadline && (
                        <div className="text-white text-center mt-6 pt-4 border-t border-slate-600">
                            <div className="flex justify-center gap-4 sm:gap-8">
                                {Object.entries(timeLeft).map(([key, value]) => (
                                    <div key={key} className="flex flex-col items-center">
                                        <span className="font-lilita text-5xl text-amber-300">{String(value).padStart(2, '0')}</span>
                                        <span className="text-sm uppercase tracking-widest">{key === 'days' ? 'Nap' : key === 'hours' ? 'Óra' : key === 'minutes' ? 'Perc' : 'Mp'}</span>
                                    </div>
                                ))}
                            </div>
                        </div>
                    )}
                </div>
                <div className="bg-slate-800/30 backdrop-blur-sm rounded-2xl shadow-lg p-6">
                    <div className="flex justify-between items-center mb-4"><button onClick={() => handleWeekChange('prev')}><ChevronLeftIcon className="w-8 h-8"/></button><div className="text-center"><h2 className="text-xl font-bold font-lilita">{getWeekId(viewingDate)}. hét</h2><p className="text-sm text-white/70">{getWeekDateRange(viewingDate)}</p></div><button onClick={() => handleWeekChange('next')}><ChevronRightIcon className="w-8 h-8"/></button></div>
                    {isLoadingRequests ? <p>Kérelmek betöltése...</p> : allRequests.length === 0 ? <p>Erre a hétre még nem érkezett kérelem.</p> : (
                        <div className="space-y-4 max-h-96 overflow-y-auto">{allRequests.map(req => { const reqUserAvatar = avatars.find(a => a.id === req.userAvatarId); return (<div key={req.id} className="bg-slate-900/40 p-3 rounded-lg"><div className="flex items-center gap-3 mb-2"><div className="w-10 h-10 rounded-full overflow-hidden flex-shrink-0 bg-slate-700/50">{req.userUploadedImage ? <img src={req.userUploadedImage} alt={req.userName}/> : reqUserAvatar ? <reqUserAvatar.component/> : null}</div><div><p className="font-bold">{req.userName}</p><p className="text-xs text-white/60">Beküldve: {new Date(req.submittedAt).toLocaleString('hu-HU')}</p></div></div>{req.days.length > 0 && (<div className="space-y-1 text-sm">{req.days.map(day => (<div key={day.date} className="flex justify-between items-center bg-slate-800/50 p-2 rounded"><span>{new Date(day.date).toLocaleDateString('hu-HU', { weekday: 'long', day: 'numeric' })}</span><span className="font-semibold">{day.type === 'munkanap' ? (day.isFlex ? 'FLEX' : `${day.from} - ${day.to}`) : 'Szabadság'}</span></div>))}</div>)}{req.message && (<div className={`mt-2 ${req.days.length > 0 ? 'pt-2 border-t border-slate-600' : ''}`}><p className="text-xs font-semibold text-white/80">Üzenet:</p><p className="text-sm italic text-white/90 whitespace-pre-wrap">{req.message}</p></div>)}</div>)})}</div>
                    )}
                </div>
            </div>
        )
    }

    if (isDeadlinePassed && !hasExistingRequest) {
        return (<div className="w-full max-w-2xl mx-auto animate-fade-in text-white text-center"><div className="bg-red-900/40 backdrop-blur-sm rounded-2xl shadow-lg p-8"><h1 className="text-2xl font-bold font-lilita tracking-wide">Lejárt a határidő!</h1><p className="mt-2 text-white/80">Sajnos lekésted a heti beosztás kérelem leadását. Keresd a felettesedet!</p></div></div>);
    }
    
    if (view === 'success') { return (<div className="w-full max-w-2xl mx-auto animate-fade-in text-white text-center"><div className="bg-slate-800/30 backdrop-blur-sm rounded-2xl shadow-lg p-8"><h1 className="text-3xl font-bold font-lilita tracking-wide">{hasExistingRequest ? 'Kérelmed módosítva!' : 'Köszi, megkaptuk!'}</h1><img src="https://media0.giphy.com/media/v1.Y2lkPTc5MGI3NjExYWlieWdyYXQ5ZHRlNGQza2U0Mmt1aWg4a3Jpa3hlMWNxNnQ5dmhtaCZlcD12MV9pbnRlcm5hbF9naWZfYnlfaWQmY3Q9Zw/9S1ziKfZ2JxQz21rbt/giphy.gif" alt="See you soon" className="mx-auto my-6 rounded-lg w-full max-w-xs" /><button onClick={handleNewRequest} disabled={isDeadlinePassed} className="mt-8 px-6 py-3 bg-orange-600 font-bold rounded-full shadow-lg transform hover:scale-105 disabled:bg-slate-500 disabled:cursor-not-allowed">Kérelem módosítása</button></div></div>); }
    if (view === 'summary') { return (<div className="w-full max-w-2xl mx-auto animate-fade-in space-y-6 text-white"><div className="bg-slate-800/30 backdrop-blur-sm rounded-2xl shadow-lg p-6"><button onClick={() => setView('form')} className="flex items-center gap-2 mb-4 font-semibold hover:text-orange-300"><ArrowLeftIcon className="w-5 h-5"/>Vissza</button><h1 className="text-3xl font-bold font-lilita text-center mb-6">{hasExistingRequest ? 'Módosítás' : 'Összegzés'}</h1>{sortedSelectedDays.length > 0 && (<><div className="text-center mb-4"><div className="flex justify-center flex-wrap gap-x-4 gap-y-1 mt-2 text-sm">{summary.munkanap > 0 && <span>Munkanap: <span className="font-bold">{summary.munkanap}</span></span>}{summary.szabadság > 0 && <span>Szabadság: <span className="font-bold">{summary.szabadság}</span></span>}</div></div><div className="space-y-3">{sortedSelectedDays.map(day => (<div key={day.date.toISOString()} className="flex justify-between items-center p-3 bg-slate-900/30 rounded-lg"><div><p className="font-bold">{day.date.toLocaleDateString('hu-HU', { weekday: 'long', day: 'numeric' })}</p><p className="text-sm text-white/70 capitalize">{day.type}</p></div><p className="font-bold text-lg">{day.type === 'munkanap' ? (day.isFlex ? 'FLEX' : `${day.from} - ${day.to}`) : 'Egész nap'}</p></div>))}</div></>)}{message.trim() && (<div className="mt-6"><p className="font-semibold mb-1">Üzenet:</p><p className="w-full bg-slate-900/30 p-3 rounded-lg whitespace-pre-wrap">{message}</p></div>)}<button onClick={handleSubmit} disabled={isSubmitting || (sortedSelectedDays.length === 0 && !message.trim())} className="w-full mt-6 flex items-center justify-center gap-2 px-4 py-3 bg-orange-600 font-bold rounded-full shadow-lg disabled:bg-orange-400"><SendIcon className="w-5 h-5" /><span>{isSubmitting ? 'Küldés...' : 'Véglegesítés'}</span></button></div></div>) }
    
    return (<div className="w-full max-w-2xl mx-auto animate-fade-in"><div className="bg-slate-800/30 backdrop-blur-sm rounded-2xl shadow-lg p-6 space-y-6">{deadline && (<div className="text-white text-center"><h2 className="text-xl font-bold font-lilita mb-2">Leadási határidő</h2><div className="flex justify-center gap-4 sm:gap-8">{Object.entries(timeLeft).map(([key, value]) => (<div key={key} className="flex flex-col items-center"><span className="font-lilita text-5xl text-amber-300">{String(value).padStart(2, '0')}</span><span className="text-sm uppercase tracking-widest">{key === 'days' ? 'Nap' : key === 'hours' ? 'Óra' : key === 'minutes' ? 'Perc' : 'Mp'}</span></div>))}</div></div>)}<div className="bg-slate-900/30 p-4 rounded-lg"><div className="text-center font-semibold text-white mb-4">{nextWeekDates[0].toLocaleDateString('hu-HU', {month: 'long', day: 'numeric'})} - {nextWeekDates[6].toLocaleDateString('hu-HU', {month: 'long', day: 'numeric'})}</div><div className="flex flex-wrap justify-center gap-2">{nextWeekDates.map(date => { const ds=date.toISOString().split('T')[0], s=!!selectedDays[ds]; return (<button key={ds} onClick={()=>toggleDaySelection(date)} className={`p-2 h-16 w-16 flex flex-col items-center justify-center rounded-lg font-semibold ${s ? 'bg-orange-500 ring-2 ring-orange-300' : 'bg-slate-700/50 hover:bg-slate-600/50'}`}><span className="text-xs text-white/70 capitalize">{date.toLocaleString('hu-HU',{weekday:'short'})}</span><span className="text-2xl">{date.getDate()}</span></button>)})}</div><p className="text-sm text-white/70 text-center mt-3">A nem kijelölt napok pihenőnapnak minősülnek.</p></div>{sortedSelectedDays.length > 0 && (<div className="space-y-3 max-h-60 overflow-y-auto pr-2">{sortedSelectedDays.map(day => { const ds=day.date.toISOString().split('T')[0], e=validationErrors[ds]; return (<div key={ds} className={`bg-slate-900/30 p-3 rounded-lg ${e ? 'ring-2 ring-red-500' : ''}`}><div className="flex flex-col sm:flex-row items-center justify-between gap-3 text-white"><div className="font-bold">{day.date.toLocaleDateString('hu-HU',{weekday:'short',day:'numeric'})}.</div><div className="flex items-center gap-2 sm:gap-4 flex-wrap justify-center"><select value={day.type} onChange={e=>handleDayDetailChange(ds,'type',e.target.value)} className="bg-slate-700 border border-slate-600 rounded-md px-2 py-1"><option value="munkanap">Munkanap</option><option value="szabadság">Szabadság</option></select>{day.type==='munkanap'?(<><div className="flex flex-col items-center gap-2"><div className={`flex items-center gap-1 ${day.isFlex?'opacity-50':''}`}><TimePicker value={day.from} onChange={v=>handleDayDetailChange(ds,'from',v)} disabled={day.isFlex}/><span>-</span><TimePicker value={day.to} onChange={v=>handleDayDetailChange(ds,'to',v)} disabled={day.isFlex}/></div><div className={`flex items-center gap-2 ${day.isFlex?'opacity-50':''}`}><button type="button" onClick={()=>handleShiftSelect(ds, '07:00', '16:00')} disabled={day.isFlex} className="px-3 py-1 text-xs bg-sky-600 text-white rounded-full font-semibold hover:bg-sky-500 disabled:bg-slate-500">Délelőtt</button><button type="button" onClick={()=>handleShiftSelect(ds, '16:00', '00:00')} disabled={day.isFlex} className="px-3 py-1 text-xs bg-indigo-600 text-white rounded-full font-semibold hover:bg-indigo-500 disabled:bg-slate-500">Délután</button></div></div><label className="flex items-center gap-2 text-sm self-center"><input type="checkbox" checked={day.isFlex} onChange={e=>handleDayDetailChange(ds,'isFlex',e.target.checked)} className="h-4 w-4 rounded bg-slate-600 accent-orange-500"/>FLEX</label></>):(<div className="text-sm text-white/70 min-w-[13rem] h-[38px] flex items-center justify-center">Egész napos</div>)}</div></div>{e&&(<div className="flex items-center justify-center gap-2 text-red-400 font-semibold text-sm pt-2"><WarningIcon className="w-5 h-5"/><span>{e}</span></div>)}</div>);})}</div>)}<div><label htmlFor="request-message" className="block text-white font-semibold mb-1">Üzenet</label><textarea id="request-message" value={message} onChange={e=>setMessage(e.target.value)} placeholder="Különleges kérés, megjegyzés..." className="w-full bg-slate-700 p-3 rounded-lg" rows={3}/></div>{(sortedSelectedDays.length > 0 || message.trim() !== '') && (<button onClick={()=>setView('summary')} disabled={Object.keys(validationErrors).length > 0} className="w-full mt-4 flex items-center justify-center gap-2 px-4 py-3 bg-orange-600 font-bold rounded-full shadow-lg disabled:bg-slate-500 animate-fade-in">Tovább</button>)}</div></div>);
};

export default WorkTimeRequestPage;