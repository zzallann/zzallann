import React, { useState, useEffect } from 'react';
import type { NotificationType } from '../contexts/NotificationContext';
import CheckCircleIcon from './icons/CheckCircleIcon';
import WarningIcon from './icons/WarningIcon';
import InfoIcon from './icons/InfoIcon';

interface NotificationProps {
  message: string;
  type: NotificationType;
  onClose: () => void;
}

const notificationStyles = {
  success: {
    bg: 'bg-green-500',
    icon: <CheckCircleIcon className="w-6 h-6 text-white" />,
  },
  error: {
    bg: 'bg-red-500',
    icon: <WarningIcon className="w-6 h-6 text-white" />,
  },
  info: {
    bg: 'bg-blue-500',
    icon: <InfoIcon className="w-6 h-6 text-white" />,
  },
};

const Notification: React.FC<NotificationProps> = ({ message, type, onClose }) => {
  const [isExiting, setIsExiting] = useState(false);
  const styles = notificationStyles[type] || notificationStyles.info;

  useEffect(() => {
    const timer = setTimeout(() => {
      setIsExiting(true);
      // The onClose function is called by the provider, but we handle animation here.
    }, 3600); // Start fade-out animation before removal

    return () => clearTimeout(timer);
  }, []);

  const animationClass = isExiting ? 'animate-fade-out-right' : 'animate-fade-in-right';

  return (
    <div
      className={`flex items-center gap-3 p-3 rounded-lg shadow-2xl text-white ${styles.bg} ${animationClass}`}
    >
      <div className="flex-shrink-0">{styles.icon}</div>
      <p className="flex-1 font-semibold">{message}</p>
      <button onClick={onClose} className="p-1 rounded-full hover:bg-black/20">
        <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
          <path strokeLinecap="round" strokeLinejoin="round" d="M6 18L18 6M6 6l12 12" />
        </svg>
      </button>
    </div>
  );
};

export default Notification;
