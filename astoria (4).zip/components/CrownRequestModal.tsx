import React, { useState } from 'react';
import type { User } from '../types';
import { authService } from '../services/authService';
import { messageService } from '../services/messageService';
import { useNotification } from '../contexts/NotificationContext';
import SendIcon from './icons/SendIcon';

interface CrownRequestModalProps {
    isOpen: boolean;
    onClose: () => void;
    user: User;
    onUserUpdate: (user: User) => void;
}

const formatCrowns = (points: number): string => {
    const roundedUp = Math.ceil(points * 100) / 100;
    return roundedUp.toLocaleString('hu-HU', {
        minimumFractionDigits: 2,
        maximumFractionDigits: 2,
    });
};

const CrownRequestModal: React.FC<CrownRequestModalProps> = ({ isOpen, onClose, user, onUserUpdate }) => {
    const [amount, setAmount] = useState('');
    const [isConfirming, setIsConfirming] = useState(false);
    const [isLoading, setIsLoading] = useState(false);
    const { addNotification } = useNotification();

    const handleAmountChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        const value = e.target.value;
        if (/^\d*$/.test(value)) { // only allow digits
            let numValue = parseInt(value, 10);
            if (numValue > 10000) {
                numValue = 10000;
            }
            setAmount(numValue ? String(numValue) : '');
        }
    };

    const handleNext = () => {
        if (!amount || parseInt(amount, 10) <= 0) {
            addNotification('Adj meg egy érvényes összeget.', 'error');
            return;
        }
        setIsConfirming(true);
    };

    const handleConfirm = async () => {
        const requestedAmount = parseInt(amount, 10);
        if (!requestedAmount) return;

        setIsLoading(true);
        try {
            const updatedUser: User = {
                ...user,
                points: user.points + requestedAmount,
                pointsHistory: [
                    { reason: 'Igényelt korona', points: requestedAmount, date: Date.now() },
                    ...(user.pointsHistory || [])
                ],
            };
            
            authService.updateUser(updatedUser);
            onUserUpdate(updatedUser);

            await messageService.sendCrownRequestNotification(user.id, requestedAmount);

            addNotification(`${formatCrowns(requestedAmount)} korona jóváírva!`, 'success');
            handleClose();
        } catch (err) {
            addNotification('Hiba történt az igénylés során.', 'error');
        } finally {
            setIsLoading(false);
        }
    };
    
    const handleClose = () => {
        setAmount('');
        setIsConfirming(false);
        setIsLoading(false);
        onClose();
    };

    if (!isOpen) return null;

    return (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex justify-center items-center z-50 animate-fade-in" onClick={handleClose}>
            <div className="bg-slate-800 w-full max-w-sm rounded-2xl shadow-2xl p-6 text-white" onClick={e => e.stopPropagation()}>
                <h3 className="text-2xl font-bold font-lilita mb-4 text-center">Korona igénylés</h3>
                
                {isConfirming ? (
                    <div className="text-center">
                        <p className="mb-6">Biztosan igényelni szeretnél <span className="font-bold text-amber-400">{parseInt(amount, 10).toLocaleString('hu-HU')}</span> koronát?</p>
                        <div className="flex justify-center gap-4">
                             <button onClick={handleClose} disabled={isLoading} className="px-6 py-2 bg-slate-600 font-semibold rounded-full">Mégse</button>
                             <button onClick={handleConfirm} disabled={isLoading} className="px-6 py-2 bg-green-600 font-bold rounded-full">{isLoading ? 'Folyamatban...' : 'Igen, igénylem'}</button>
                        </div>
                    </div>
                ) : (
                    <div className="space-y-4">
                        <div>
                            <label htmlFor="crown-amount" className="block text-white font-semibold mb-1">Igényelt összeg (max 10,000)</label>
                            <input
                                type="text"
                                pattern="\d*"
                                id="crown-amount"
                                value={amount}
                                onChange={handleAmountChange}
                                placeholder="Pl. 5000"
                                className="w-full px-4 py-2 bg-slate-700 text-white border-2 border-transparent rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500"
                                autoFocus
                            />
                        </div>
                        <button
                            onClick={handleNext}
                            className="w-full flex items-center justify-center gap-2 px-4 py-3 bg-orange-600 font-bold rounded-full text-lg shadow-lg transform hover:scale-105"
                        >
                            <SendIcon className="w-5 h-5" />
                            <span>Tovább</span>
                        </button>
                    </div>
                )}
            </div>
        </div>
    );
};

export default CrownRequestModal;
