import React, { useState, useRef, useEffect } from 'react';
import { useNotification } from '../contexts/NotificationContext';
import ImageIcon from './icons/ImageIcon';

interface ProfileImageEditorModalProps {
    isOpen: boolean;
    onClose: () => void;
    onSave: (imageUrl: string) => Promise<void>;
    imageSrc: string | null;
}

const CROP_AREA_SIZE = 256;

const ProfileImageEditorModal: React.FC<ProfileImageEditorModalProps> = ({ isOpen, onClose, onSave, imageSrc: initialImageSrc }) => {
    const [imageSrc, setImageSrc] = useState<string | null>(initialImageSrc);
    const [zoom, setZoom] = useState(1);
    const [baseZoom, setBaseZoom] = useState(1);
    const [pan, setPan] = useState({ x: 0, y: 0 });
    const [isDragging, setIsDragging] = useState(false);
    const [dragStart, setDragStart] = useState({ x: 0, y: 0 });
    const [isSaving, setIsSaving] = useState(false);

    const imageRef = useRef<HTMLImageElement>(null);
    const fileInputRef = useRef<HTMLInputElement>(null);
    const pinchStartDistanceRef = useRef(0);
    const pinchStartZoomRef = useRef(1);
    const { addNotification } = useNotification();

    useEffect(() => {
        if (isOpen) {
            setImageSrc(initialImageSrc);
        }
    }, [isOpen, initialImageSrc]);

    const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        const file = e.target.files?.[0];
        if (file) {
            const reader = new FileReader();
            reader.onload = () => {
                setImageSrc(reader.result as string);
                setZoom(1);
                setPan({ x: 0, y: 0 });
            };
            reader.readAsDataURL(file);
        }
    };

    const handleImageLoad = (e: React.SyntheticEvent<HTMLImageElement>) => {
        const img = e.currentTarget;
        const scaleToFill = Math.max(CROP_AREA_SIZE / img.naturalWidth, CROP_AREA_SIZE / img.naturalHeight);
        setBaseZoom(scaleToFill);
        setZoom(1);
        setPan({ x: 0, y: 0 });
    };

    const handleWheel = (e: React.WheelEvent) => {
        e.preventDefault();
        setZoom(prevZoom => Math.max(1, Math.min(4, prevZoom - e.deltaY * 0.001)));
    };

    const handleMouseDown = (e: React.MouseEvent) => {
        e.preventDefault();
        setIsDragging(true);
        setDragStart({ x: e.clientX - pan.x, y: e.clientY - pan.y });
    };

    const handleMouseMove = (e: React.MouseEvent) => {
        if (!isDragging || !imageRef.current) return;
        
        const newX = e.clientX - dragStart.x;
        const newY = e.clientY - dragStart.y;
        
        const finalScale = baseZoom * zoom;
        const scaledWidth = imageRef.current.naturalWidth * finalScale;
        const scaledHeight = imageRef.current.naturalHeight * finalScale;

        const maxPanX = Math.max(0, (scaledWidth - CROP_AREA_SIZE) / 2);
        const maxPanY = Math.max(0, (scaledHeight - CROP_AREA_SIZE) / 2);

        setPan({
            x: Math.max(-maxPanX, Math.min(maxPanX, newX)),
            y: Math.max(-maxPanY, Math.min(maxPanY, newY)),
        });
    };

    const handleMouseUp = () => setIsDragging(false);

    const getTouchDistance = (touches: React.TouchList) => {
        const touch1 = touches[0];
        const touch2 = touches[1];
        return Math.sqrt(
            Math.pow(touch2.clientX - touch1.clientX, 2) +
            Math.pow(touch2.clientY - touch1.clientY, 2)
        );
    };

    const handleTouchStart = (e: React.TouchEvent) => {
        e.preventDefault();
        if (e.touches.length === 1) {
            setIsDragging(true);
            setDragStart({ x: e.touches[0].clientX - pan.x, y: e.touches[0].clientY - pan.y });
        } else if (e.touches.length === 2) {
            setIsDragging(false);
            pinchStartDistanceRef.current = getTouchDistance(e.touches);
            pinchStartZoomRef.current = zoom;
        }
    };

    const handleTouchMove = (e: React.TouchEvent) => {
        e.preventDefault();
        if (e.touches.length === 1 && isDragging && imageRef.current) {
            const newX = e.touches[0].clientX - dragStart.x;
            const newY = e.touches[0].clientY - dragStart.y;
            
            const finalScale = baseZoom * zoom;
            const scaledWidth = imageRef.current.naturalWidth * finalScale;
            const scaledHeight = imageRef.current.naturalHeight * finalScale;

            const maxPanX = Math.max(0, (scaledWidth - CROP_AREA_SIZE) / 2);
            const maxPanY = Math.max(0, (scaledHeight - CROP_AREA_SIZE) / 2);

            setPan({
                x: Math.max(-maxPanX, Math.min(maxPanX, newX)),
                y: Math.max(-maxPanY, Math.min(maxPanY, newY)),
            });
        } else if (e.touches.length === 2) {
            const newDistance = getTouchDistance(e.touches);
            const ratio = newDistance / pinchStartDistanceRef.current;
            const newZoom = pinchStartZoomRef.current * ratio;
            setZoom(Math.max(1, Math.min(4, newZoom)));
        }
    };

    const handleTouchEnd = () => {
        setIsDragging(false);
    };


    const handleSave = async () => {
        if (!imageSrc || !imageRef.current) return;

        setIsSaving(true);
        const canvas = document.createElement('canvas');
        canvas.width = CROP_AREA_SIZE;
        canvas.height = CROP_AREA_SIZE;
        const ctx = canvas.getContext('2d');
        if (!ctx) {
            addNotification('Hiba a kép feldolgozásakor.', 'error');
            setIsSaving(false);
            return;
        }

        const img = imageRef.current;
        const finalScale = baseZoom * zoom;

        const sourceCropSize = CROP_AREA_SIZE / finalScale;

        const sx = (img.naturalWidth / 2) - (sourceCropSize / 2) - (pan.x / finalScale);
        const sy = (img.naturalHeight / 2) - (sourceCropSize / 2) - (pan.y / finalScale);
        
        ctx.drawImage(
            img,
            sx,
            sy,
            sourceCropSize,
            sourceCropSize,
            0,
            0,
            CROP_AREA_SIZE,
            CROP_AREA_SIZE
        );

        const dataUrl = canvas.toDataURL('image/png');
        await onSave(dataUrl);
        setIsSaving(false);
    };

    if (!isOpen) return null;

    return (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex justify-center items-center z-50 animate-fade-in" onClick={onClose}>
            <div className="bg-slate-800 w-full max-w-sm rounded-2xl shadow-2xl p-6 text-white flex flex-col" onClick={e => e.stopPropagation()}>
                <h3 className="text-2xl font-bold font-lilita mb-4 text-center">Profilkép Szerkesztése</h3>

                {imageSrc ? (
                    <div className="space-y-4">
                        <div
                            className="w-64 h-64 mx-auto rounded-full overflow-hidden bg-slate-900 cursor-grab relative shadow-inner touch-none"
                            onMouseDown={handleMouseDown}
                            onMouseMove={handleMouseMove}
                            onMouseUp={handleMouseUp}
                            onMouseLeave={handleMouseUp}
                            onWheel={handleWheel}
                            onTouchStart={handleTouchStart}
                            onTouchMove={handleTouchMove}
                            onTouchEnd={handleTouchEnd}
                        >
                            <img
                                ref={imageRef}
                                src={imageSrc}
                                alt="Feltöltött kép"
                                className="absolute top-1/2 left-1/2"
                                onLoad={handleImageLoad}
                                style={{
                                    transform: `translate(calc(-50% + ${pan.x}px), calc(-50% + ${pan.y}px)) scale(${baseZoom * zoom})`,
                                    transition: isDragging ? 'none' : 'transform 0.1s ease-out',
                                    maxWidth: 'none',
                                    cursor: isDragging ? 'grabbing' : 'grab'
                                }}
                            />
                        </div>

                        <div>
                            <label className="block text-sm font-semibold mb-1 text-center">Nagyítás</label>
                            <input
                                type="range"
                                min="1"
                                max="4"
                                step="0.01"
                                value={zoom}
                                onChange={e => setZoom(parseFloat(e.target.value))}
                                className="w-full h-2 bg-slate-700 rounded-lg appearance-none cursor-pointer accent-orange-500"
                            />
                        </div>
                        
                        <div className="flex justify-center gap-4 pt-4 border-t border-slate-700">
                            <button onClick={() => fileInputRef.current?.click()} className="px-4 py-2 bg-slate-600 font-semibold rounded-full">Másik kép</button>
                            <button onClick={handleSave} disabled={isSaving} className="px-4 py-2 bg-green-600 font-bold rounded-full disabled:bg-slate-500">
                                {isSaving ? 'Mentés...' : 'Mentés'}
                            </button>
                        </div>
                    </div>
                ) : (
                    <div className="text-center space-y-4">
                         <p>Válassz egy képet a profilodhoz.</p>
                        <button onClick={() => fileInputRef.current?.click()} className="w-full flex items-center justify-center gap-2 px-4 py-3 bg-orange-600 font-bold rounded-full text-lg shadow-lg transform hover:scale-105">
                            <ImageIcon className="w-6 h-6"/>
                            <span>Kép feltöltése</span>
                        </button>
                    </div>
                )}
                 <input type="file" accept="image/*" ref={fileInputRef} onChange={handleFileChange} className="hidden" />
            </div>
        </div>
    );
};

export default ProfileImageEditorModal;