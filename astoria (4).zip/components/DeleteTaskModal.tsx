import React from 'react';
import type { AssignedTask } from '../types';

interface DeleteTaskModalProps {
  task: AssignedTask;
  assigneeName: string;
  onClose: () => void;
  onConfirmDelete: () => void;
  onExtendDeadline: () => void;
}

const DeleteTaskModal: React.FC<DeleteTaskModalProps> = ({ task, assigneeName, onClose, onConfirmDelete, onExtendDeadline }) => {
  return (
    <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex justify-center items-center z-50 animate-fade-in" onClick={onClose}>
      <div className="bg-slate-800 w-full max-w-sm rounded-2xl shadow-2xl p-6 text-white text-center" onClick={e => e.stopPropagation()}>
        <h3 className="text-2xl font-bold font-lilita mb-4">Feladat kezelése</h3>
        <p className="text-white/80 mb-6">
          Biztos törlöd <span className="font-bold text-orange-400">{assigneeName}</span> feladatát?
          <br/>
          <span className="text-sm italic">"{task.description}"</span>
        </p>
        <div className="flex flex-col gap-3">
          <button
            onClick={onConfirmDelete}
            className="w-full px-4 py-3 bg-red-600 text-white font-bold rounded-full shadow-lg transform hover:scale-105 transition-transform duration-200"
          >
            Igen, törlöm
          </button>
           <button
            onClick={onExtendDeadline}
            className="w-full px-4 py-3 bg-blue-600 text-white font-bold rounded-full shadow-lg transform hover:scale-105 transition-transform duration-200"
          >
            Nem, csak hosszabbítom az idejét
          </button>
          <button
            onClick={onClose}
            className="w-full px-4 py-2 bg-slate-600 text-white font-semibold rounded-full shadow-lg transform hover:scale-105 transition-transform duration-200"
          >
            Mégse
          </button>
        </div>
      </div>
    </div>
  );
};

export default DeleteTaskModal;
