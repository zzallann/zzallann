import React, { useState, useEffect } from 'react';
import ArrowLeftIcon from './icons/ArrowLeftIcon';
import { authService } from '../services/authService';
import type { User } from '../types';

interface ForgotPasswordProps {
  onBackToLogin: () => void;
}

const ForgotPassword: React.FC<ForgotPasswordProps> = ({ onBackToLogin }) => {
  const [proMaxUsers, setProMaxUsers] = useState<User[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    try {
      const allUsers = authService.getAllUsers();
      const proMax = allUsers.filter(u => u.status === 'pro_max');
      setProMaxUsers(proMax);
    } catch (error) {
      console.error("Failed to load users", error);
    } finally {
      setIsLoading(false);
    }
  }, []);

  return (
    <div className="w-full max-w-sm bg-[var(--component-bg)] backdrop-blur-sm p-8 rounded-2xl shadow-lg animate-fade-in relative text-center text-[var(--text-primary)]">
        <button onClick={onBackToLogin} className="absolute top-4 left-4 p-2 rounded-full hover:bg-[var(--component-bg-hover)] transition-colors">
            <ArrowLeftIcon className="w-6 h-6 text-[var(--text-primary)]"/>
        </button>
      <h2 className="text-3xl font-bold text-center mb-6 font-lilita">Elfelejtett Jelszó</h2>
      <p className="mb-4 text-[var(--text-secondary)]">
        Elfelejtetted a jelszavad? Keresd fel az egyik 'Pro Max' státuszú kollégádat, aki segíthet neked új jelszót beállítani. Az új jelszavaddal bejelentkezve a 'Beállítások' menüpont alatt tudsz majd egyedi jelszót megadni.
      </p>
      
      <div className="bg-[var(--input-bg)] bg-opacity-40 p-4 rounded-lg mt-6">
        <h3 className="font-bold text-lg mb-2 text-orange-400">Pro Max Felhasználók</h3>
        {isLoading ? (
          <p>Felhasználók betöltése...</p>
        ) : proMaxUsers.length > 0 ? (
          <ul className="space-y-1">
            {proMaxUsers.map(user => (
              <li key={user.id} className="font-semibold text-lg">{user.name}</li>
            ))}
          </ul>
        ) : (
          <p className="text-[var(--text-tertiary)]">Jelenleg nincsenek Pro Max státuszú felhasználók.</p>
        )}
      </div>
      
       <button onClick={onBackToLogin} className="mt-8 font-bold hover:underline">Vissza a bejelentkezéshez</button>
    </div>
  );
};

export default ForgotPassword;