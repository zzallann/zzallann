import React from 'react';
import { useTheme } from '../contexts/ThemeContext';
import PaletteIcon from './icons/PaletteIcon';

const ThemeToggleButton: React.FC<{ className?: string }> = ({ className }) => {
  const { theme, setTheme } = useTheme();

  const handleClick = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (theme === 'blue') {
      setTheme('pink');
    } else if (theme === 'pink') {
      setTheme('green');
    } else if (theme === 'green') {
      setTheme('horizon');
    } else if (theme === 'horizon') {
      setTheme('christmas');
    } else {
      setTheme('blue');
    }
  };

  return (
    <button
      onClick={handleClick}
      className={`p-2 rounded-full text-[var(--text-primary)] bg-[var(--component-bg)] hover:bg-[var(--component-bg-hover)] transition-colors ${className}`}
      aria-label="Toggle theme"
    >
      <PaletteIcon className="w-6 h-6" />
    </button>
  );
};
export default ThemeToggleButton;