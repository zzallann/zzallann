import React from 'react';
import type { Post, User, Poll } from '../types';
import PostCreator from './PostCreator';
import PostCard from './PostCard';

interface FeedProps {
  user: User;
  posts: Post[];
  isLoading: boolean;
  error: string;
  onCreatePost: (
      content: string | null, 
      gifUrl: string | null, 
      imageFile: File | null, 
      videoFile: File | null,
      poll: Poll | null
  ) => Promise<void>;
  onToggleReaction: (postId: string, reaction: string) => void;
  onVoteOnPoll: (postId: string, optionIndex: number) => void;
  onDeletePost?: (post: Post) => void;
  onViewPost: (post: Post) => void;
}

const Feed: React.FC<FeedProps> = ({ user, posts, isLoading, error, onCreatePost, onToggleReaction, onVoteOnPoll, onDeletePost, onViewPost }) => {
  return (
    <>
      <PostCreator user={user} onCreatePost={onCreatePost} />
      
      {isLoading && <p className="text-[var(--text-primary)] text-center mt-8">Bejegyzések betöltése...</p>}
      
      {error && <p className="text-orange-300 text-center bg-orange-800/50 p-3 rounded-lg mt-4">{error}</p>}
      
      {!isLoading && posts.length === 0 && !error && (
        <div className="bg-[var(--component-bg)] backdrop-blur-sm p-8 rounded-2xl text-center">
            <p className="text-[var(--text-secondary)]">Még nincsenek bejegyzések. Legyél te az első!</p>
        </div>
      )}

      <div className="w-full space-y-6">
        {posts.map(post => (
          <PostCard 
            key={post.id} 
            post={post} 
            currentUser={user}
            onToggleReaction={onToggleReaction} 
            onVoteOnPoll={onVoteOnPoll}
            onDeletePost={onDeletePost}
            onViewPost={onViewPost}
          />
        ))}
      </div>
    </>
  );
};

export default Feed;
