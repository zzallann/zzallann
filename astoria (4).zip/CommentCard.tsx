import CommentCard from './components/CommentCard';

export default CommentCard;
