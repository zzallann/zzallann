import PostCard from './components/PostCard';

export default PostCard;
