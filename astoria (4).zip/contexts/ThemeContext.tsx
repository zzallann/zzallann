import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';

// FIX: Export the Theme type to allow it to be imported by other modules.
export type Theme = 'blue' | 'pink' | 'green' | 'horizon' | 'christmas' | 'dark9';
interface ThemeContextType {
  theme: Theme;
  setTheme: (theme: Theme) => void;
}

const ThemeContext = createContext<ThemeContextType | undefined>(undefined);

export const ThemeProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [theme, setTheme] = useState<Theme>(() => {
    if (typeof window === 'undefined') {
        return 'horizon'; // Default for SSR
    }
    const storedTheme = localStorage.getItem('astoria-theme') as Theme | null;
    return storedTheme || 'horizon';
  });

  useEffect(() => {
    const root = window.document.documentElement;
    root.dataset.theme = theme;
    localStorage.setItem('astoria-theme', theme);
  }, [theme]);

  return (
    <ThemeContext.Provider value={{ theme, setTheme }}>
      {children}
    </ThemeContext.Provider>
  );
};

export const useTheme = (): ThemeContextType => {
  const context = useContext(ThemeContext);
  if (!context) {
    throw new Error('useTheme must be used within a ThemeProvider');
  }
  return context;
};